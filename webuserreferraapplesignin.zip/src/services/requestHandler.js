// // import { del, post, get } from "./HttpProvider";
// // import featureConstants from "./features-constants";

// // const SERVICE_URLS = {
// //   sign_up: "/auth/signup",
// //   login: "/auth/send-otp",
// //   logout: "/auth/logout",
// //   free_user: "/referrals/users/free",
// //   points_history: "/referrals/points/get",
// //   coupon_history: "/referrals/coupons/all",
// //   redeem_request: "/referrals/points/redeem",
// //   redeem_history: "/referrals/redeem/history",
// //   prem_user: "/referrals/users/details",
// //   view_results: "/referrals/get/counts",
// //   view_links: "/referrals/apps/links",
// //   my_rewards: "/referrals/reward",
// //   my_rewards_discounts: "/referrals/discounts",
// //   rewards_coupon: "/referrals/coupon/add",

// //   premium_user: "/referrals/users/paid",
// //   discount: "/referrals/discount/all",
// //   free_all_user: "/referrals/users/free/all",
// //   all_prem_users: "/referrals/users/premium/all",
// //   marketers_users: "/referrals/users/marketers/all",
// //   single_user_details: "/referrals/user/single/details",
// //   payment_request: "/referrals/users/payment/requests",
// //   update_redeem_history: "/referrals/users/payment/requests",
// //   trial_users: "/referrals/users/trial",
// //   get_links: "/referrals/apps/links",
// //   referred_user: "/referrals/details/get",
// //   referred_user_details: "/referrals/users/details"
// // };

// // const signUp = (data) =>
// //   post(SERVICE_URLS.sign_up, data, { feature: featureConstants.login });

// // const login = (data) =>
// //   post(SERVICE_URLS.login, data, { feature: featureConstants.login });

// // const logout = (data) =>
// //   del(SERVICE_URLS.logout, data, { feature: featureConstants.login });

// // const redeemRequest = (data) =>
// //   post(SERVICE_URLS.redeem_request, data, { feature: featureConstants.login });

// // const premiumUser = (data) =>
// //   post(SERVICE_URLS.prem_user, data, { feature: featureConstants.login });

// // const viewResults = (data) =>
// //   post(SERVICE_URLS.view_results, data, { feature: featureConstants.login });

// // const rewardsCoupon = (data) =>
// //   post(SERVICE_URLS.rewards_coupon, data, { feature: featureConstants.login });

// // const myRewards = (data) =>
// //   post(SERVICE_URLS.my_rewards, data, { feature: featureConstants.login });

// // const viewLinks = () =>
// //   get(
// //     SERVICE_URLS.view_links,
// //     {},
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const myRewardsDiscount = () =>
// //   get(
// //     SERVICE_URLS.my_rewards_discounts,
// //     {},
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const freeUsers = (params) =>
// //   get(
// //     SERVICE_URLS.free_user,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const pointsHistory = (params) =>
// //   get(
// //     SERVICE_URLS.points_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const redeemHistory = (params) =>
// //   get(
// //     SERVICE_URLS.redeem_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const couponHistory = (params) =>
// //   get(
// //     SERVICE_URLS.coupon_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const apiServices = {
// //   signUp,
// //   login,
// //   logout,
// //   freeUsers,
// //   pointsHistory,
// //   couponHistory,
// //   redeemRequest,
// //   redeemHistory,
// //   premiumUser,
// //   viewResults,
// //   viewLinks,
// //   myRewards,
// //   rewardsCoupon,
// //   myRewardsDiscount,
// // };

// // export default apiServices;








// // import { del, post, get } from "./HttpProvider";
// // import featureConstants from "./features-constants";

// // const SERVICE_URLS = {
// //   sign_up: "/auth/signup",
// //   login: "/auth/send-otp",
// //   logout: "/auth/logout",
// //   free_user: "/referrals/users/free",
// //   points_history: "/referrals/points/get",
// //   coupon_history: "/referrals/coupons/all",
// //   redeem_request: "/referrals/points/redeem",
// //   redeem_history: "/referrals/redeem/history",
// //   prem_user: "/referrals/users/details",
// //   view_results: "/referrals/get/counts",
// //   view_links: "/referrals/apps/links",
// //   my_rewards: "/referrals/reward",
// //   my_rewards_discounts: "/referrals/discounts",
// //   rewards_coupon: "/referrals/coupon/add",

// //   premium_user: "/referrals/users/paid",
// //   discount: "/referrals/discount/all",
// //   free_all_user: "/referrals/users/free/all",
// //   all_prem_users: "/referrals/users/premium/all",
// //   marketers_users: "/referrals/users/marketers/all",
// //   single_user_details: "/referrals/user/single/details",
// //   payment_request: "/referrals/users/payment/requests",
// //   update_redeem_history: "/referrals/users/payment/requests",
// //   trial_users: "/referrals/users/trial",
// //   get_links: "/referrals/apps/links",
// //   referred_user: "/referrals/details/get",
// //   referred_user_details: "/referrals/users/details",
// // };

// // const signUp = (data) =>
// //   post(SERVICE_URLS.sign_up, data, { feature: featureConstants.login });

// // const login = (data) =>
// //   post(SERVICE_URLS.login, data, { feature: featureConstants.login });

// // const logout = (data) =>
// //   del(SERVICE_URLS.logout, data, { feature: featureConstants.login });

// // const redeemRequest = (data) =>
// //   post(SERVICE_URLS.redeem_request, data, { feature: featureConstants.login });

// // const premiumUser = (data) =>
// //   post(SERVICE_URLS.prem_user, data, { feature: featureConstants.login });

// // const viewResults = (data) =>
// //   post(SERVICE_URLS.view_results, data, { feature: featureConstants.login });

// // const rewardsCoupon = (data) =>
// //   post(SERVICE_URLS.rewards_coupon, data, { feature: featureConstants.login });

// // const myRewards = (data) =>
// //   post(SERVICE_URLS.my_rewards, data, { feature: featureConstants.login });

// // const viewLinks = () =>
// //   get(
// //     SERVICE_URLS.view_links,
// //     {},
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const myRewardsDiscount = () =>
// //   get(
// //     SERVICE_URLS.my_rewards_discounts,
// //     {},
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const freeUsers = (params) =>
// //   get(
// //     SERVICE_URLS.free_user,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // // POST /referrals/users/free/all
// // const freeAllUsers = (data) =>
// //   post(SERVICE_URLS.free_all_user, data, { feature: featureConstants.login });

// // const pointsHistory = (params) =>
// //   get(
// //     SERVICE_URLS.points_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const redeemHistory = (params) =>
// //   get(
// //     SERVICE_URLS.redeem_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const couponHistory = (params) =>
// //   get(
// //     SERVICE_URLS.coupon_history,
// //     params,
// //     { feature: featureConstants.login },
// //     { detail: false }
// //   );

// // const apiServices = {
// //   signUp,
// //   login,
// //   logout,
// //   freeUsers,
// //   freeAllUsers,
// //   pointsHistory,
// //   couponHistory,
// //   redeemRequest,
// //   redeemHistory,
// //   premiumUser,
// //   viewResults,
// //   viewLinks,
// //   myRewards,
// //   rewardsCoupon,
// //   myRewardsDiscount,
// // };

// // export default apiServices;














// import { del, post, get } from "./HttpProvider";
// import featureConstants from "./features-constants";

// const SERVICE_URLS = {
//   sign_up: "/auth/signup",
//   login: "/auth/send-otp",
//   logout: "/auth/logout",
//   free_user: "/referrals/users/free",
//   points_history: "/referrals/points/get",
//   coupon_history: "/referrals/coupons/all",
//   redeem_request: "/referrals/points/redeem",
//   redeem_history: "/referrals/redeem/history",
//   prem_user: "/referrals/users/details",
//   view_results: "/referrals/get/counts",
//   view_links: "/referrals/apps/links",
//   my_rewards: "/referrals/reward",
//   my_rewards_discounts: "/referrals/discounts",
//   rewards_coupon: "/referrals/coupon/add",

//   premium_user: "/referrals/users/paid",        // GET
//   all_prem_users: "/referrals/users/premium/all", // POST
//   discount: "/referrals/discount/all",
//   free_all_user: "/referrals/users/free/all",
//   marketers_users: "/referrals/users/marketers/all",
//   single_user_details: "/referrals/user/single/details",
//   payment_request: "/referrals/users/payment/requests",
//   update_redeem_history: "/referrals/users/payment/requests",
//   trial_users: "/referrals/users/trial",
//   get_links: "/referrals/apps/links",
//   referred_user: "/referrals/details/get",
//   referred_user_details: "/referrals/users/details",
// };

// const signUp = (data) =>
//   post(SERVICE_URLS.sign_up, data, { feature: featureConstants.login });

// const login = (data) =>
//   post(SERVICE_URLS.login, data, { feature: featureConstants.login });

// const logout = (data) =>
//   del(SERVICE_URLS.logout, data, { feature: featureConstants.login });

// const redeemRequest = (data) =>
//   post(SERVICE_URLS.redeem_request, data, { feature: featureConstants.login });

// // old POST /referrals/users/details — kept for any other usage
// const premiumUserDetails = (data) =>
//   post(SERVICE_URLS.prem_user, data, { feature: featureConstants.login });

// // GET /referrals/users/paid  → { success, message, data: [...users] }
// const premiumUser = (params) =>
//   get(
//     SERVICE_URLS.premium_user,
//     params,
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// // POST /referrals/users/premium/all → { success, message, count, data: [...] }
// const allPremiumUsers = (data) =>
//   post(SERVICE_URLS.all_prem_users, data, { feature: featureConstants.login });

// const viewResults = (data) =>
//   post(SERVICE_URLS.view_results, data, { feature: featureConstants.login });

// const rewardsCoupon = (data) =>
//   post(SERVICE_URLS.rewards_coupon, data, { feature: featureConstants.login });

// const myRewards = (data) =>
//   post(SERVICE_URLS.my_rewards, data, { feature: featureConstants.login });

// const viewLinks = () =>
//   get(
//     SERVICE_URLS.view_links,
//     {},
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// const myRewardsDiscount = () =>
//   get(
//     SERVICE_URLS.my_rewards_discounts,
//     {},
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// const freeUsers = (params) =>
//   get(
//     SERVICE_URLS.free_user,
//     params,
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// // POST /referrals/users/free/all
// const freeAllUsers = (data) =>
//   post(SERVICE_URLS.free_all_user, data, { feature: featureConstants.login });

// const pointsHistory = (params) =>
//   get(
//     SERVICE_URLS.points_history,
//     params,
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// const redeemHistory = (params) =>
//   get(
//     SERVICE_URLS.redeem_history,
//     params,
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// const couponHistory = (params) =>
//   get(
//     SERVICE_URLS.coupon_history,
//     params,
//     { feature: featureConstants.login },
//     { detail: false }
//   );

// const apiServices = {
//   signUp,
//   login,
//   logout,
//   freeUsers,
//   freeAllUsers,
//   pointsHistory,
//   couponHistory,
//   redeemRequest,
//   redeemHistory,
//   premiumUser,
//   allPremiumUsers,
//   premiumUserDetails,
//   viewResults,
//   viewLinks,
//   myRewards,
//   rewardsCoupon,
//   myRewardsDiscount,
// };

// export default apiServices;

















import { del, post, get } from "./HttpProvider";
import featureConstants from "./features-constants";

const SERVICE_URLS = {
  sign_up: "/auth/signup",
  login: "/auth/send-otp",
  logout: "/auth/logout",
  free_user: "/referrals/users/free",
  points_history: "/referrals/points/get",
  coupon_history: "/referrals/coupons/all",
  redeem_request: "/referrals/points/redeem",
  redeem_history: "/referrals/redeem/history",
  prem_user: "/referrals/users/details",
  view_results: "/referrals/get/counts",
  view_links: "/referrals/apps/links",
  my_rewards: "/referrals/reward",
  my_rewards_discounts: "/referrals/discounts",
  rewards_coupon: "/referrals/coupon/add",

  premium_user: "/referrals/users/paid",
  all_prem_users: "/referrals/users/premium/all",
  discount: "/referrals/discount/all",
  free_all_user: "/referrals/users/free/all",
  marketers_users: "/referrals/users/marketers/all",
  single_user_details: "/referrals/user/single/details",
  payment_request: "/referrals/users/payment/requests",
  update_redeem_history: "/referrals/users/payment/requests",
  trial_users: "/referrals/users/trial",
  get_links: "/referrals/apps/links",
  referred_user: "/referrals/details/get",          // POST — summary counts
  referred_user_details: "/referrals/users/details", // POST — paginated users
};

const signUp = (data) =>
  post(SERVICE_URLS.sign_up, data, { feature: featureConstants.login });

const login = (data) =>
  post(SERVICE_URLS.login, data, { feature: featureConstants.login });

const logout = (data) =>
  del(SERVICE_URLS.logout, data, { feature: featureConstants.login });

const redeemRequest = (data) =>
  post(SERVICE_URLS.redeem_request, data, { feature: featureConstants.login });

const premiumUserDetails = (data) =>
  post(SERVICE_URLS.prem_user, data, { feature: featureConstants.login });

const premiumUser = (params) =>
  get(
    SERVICE_URLS.premium_user,
    params,
    { feature: featureConstants.login },
    { detail: false }
  );

const allPremiumUsers = (data) =>
  post(SERVICE_URLS.all_prem_users, data, { feature: featureConstants.login });

// POST /referrals/details/get → summary counts per category
const getReferredUser = (data) =>
  post(SERVICE_URLS.referred_user, data, { feature: featureConstants.login });

// POST /referrals/users/details → paginated trial/subscribed/cancelled users
const getReferredUserDetails = (data) =>
  post(SERVICE_URLS.referred_user_details, data, {
    feature: featureConstants.login,
  });

const viewResults = (data) =>
  post(SERVICE_URLS.view_results, data, { feature: featureConstants.login });

const rewardsCoupon = (data) =>
  post(SERVICE_URLS.rewards_coupon, data, { feature: featureConstants.login });

const myRewards = (data) =>
  post(SERVICE_URLS.my_rewards, data, { feature: featureConstants.login });

const viewLinks = () =>
  get(
    SERVICE_URLS.view_links,
    {},
    { feature: featureConstants.login },
    { detail: false }
  );

const myRewardsDiscount = () =>
  get(
    SERVICE_URLS.my_rewards_discounts,
    {},
    { feature: featureConstants.login },
    { detail: false }
  );

const freeUsers = (params) =>
  get(
    SERVICE_URLS.free_user,
    params,
    { feature: featureConstants.login },
    { detail: false }
  );

const freeAllUsers = (data) =>
  post(SERVICE_URLS.free_all_user, data, { feature: featureConstants.login });

const pointsHistory = (params) =>
  get(
    SERVICE_URLS.points_history,
    params,
    { feature: featureConstants.login },
    { detail: false }
  );

const redeemHistory = (params) =>
  get(
    SERVICE_URLS.redeem_history,
    params,
    { feature: featureConstants.login },
    { detail: false }
  );

const couponHistory = (params) =>
  get(
    SERVICE_URLS.coupon_history,
    params,
    { feature: featureConstants.login },
    { detail: false }
  );

const apiServices = {
  signUp,
  login,
  logout,
  freeUsers,
  freeAllUsers,
  pointsHistory,
  couponHistory,
  redeemRequest,
  redeemHistory,
  premiumUser,
  allPremiumUsers,
  premiumUserDetails,
  getReferredUser,
  getReferredUserDetails,
  viewResults,
  viewLinks,
  myRewards,
  rewardsCoupon,
  myRewardsDiscount,
};

export default apiServices;