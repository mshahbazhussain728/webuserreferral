// // // // // // // // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // // // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // // // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // // // // // // // //       try {
// // // // // // // // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // // // // //         console.error("Error fetching dashboard links:", err);
// // // // // // // // // // // // // // // //       }
// // // // // // // // // // // // // // // //     };

// // // // // // // // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // // // // // // // //   }, [dispatch]);

// // // // // // // // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // // // // // // // //   };

// // // // // // // // // // // // // // // //   const handleRedeemPoints = (type, points, loading) => {
// // // // // // // // // // // // // // // //     dispatch(
// // // // // // // // // // // // // // // //       updateModalType({
// // // // // // // // // // // // // // // //         type: ModalType.COUPON_POINTS,
// // // // // // // // // // // // // // // //         data: { actionType: "REDEEM_SUCCESS", type, points, loading },
// // // // // // // // // // // // // // // //       })
// // // // // // // // // // // // // // // //     );
// // // // // // // // // // // // // // // //   };

// // // // // // // // // // // // // // // //   const rewardsActions = [
// // // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // // // //       text: "Points History",
// // // // // // // // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // // //   ];

// // // // // // // // // // // // // // // //   const {
// // // // // // // // // // // // // // // //     register,
// // // // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // // // //     formState: { errors },
// // // // // // // // // // // // // // // //   } = useForm({
// // // // // // // // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // // // // // // // //   });

// // // // // // // // // // // // // // // //   const fields = GetCouponFormFields(register, loading);

// // // // // // // // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // // // // // // // //     let points;
// // // // // // // // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // // // // // // // //     } else {
// // // // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // // //     handleRedeemPoints(type, points, loading);
// // // // // // // // // // // // // // // //   };

// // // // // // // // // // // // // // // //   return {
// // // // // // // // // // // // // // // //     rewardsActions,
// // // // // // // // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // // // // // // // //     fields: fields,
// // // // // // // // // // // // // // // //     onSubmit,
// // // // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // // // //     errors,
// // // // // // // // // // // // // // // //     loading,
// // // // // // // // // // // // // // // //     myRewards,
// // // // // // // // // // // // // // // //   };
// // // // // // // // // // // // // // // // };


// // // // // // // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // // // // // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // // // // // // //       try {
// // // // // // // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // // // // // // //         }
// // // // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // // // //         console.error("Error fetching dashboard links:", err);
// // // // // // // // // // // // // // //       }
// // // // // // // // // // // // // // //     };

// // // // // // // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // // // // // // //   }, [dispatch]);

// // // // // // // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // // // // // // //   };

// // // // // // // // // // // // // // //   const rewardsActions = [
// // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // // //       text: "Points History",
// // // // // // // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // //     {
// // // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // // // // // // //     },
// // // // // // // // // // // // // // //   ];

// // // // // // // // // // // // // // //   const {
// // // // // // // // // // // // // // //     register,
// // // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // // //     formState: { errors },
// // // // // // // // // // // // // // //     reset,
// // // // // // // // // // // // // // //   } = useForm({
// // // // // // // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // // // // // // //   });

// // // // // // // // // // // // // // //   const fields = GetCouponFormFields(register, loading);

// // // // // // // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // // // // // // //     console.log("Form submitted with data:", data);

// // // // // // // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // // // // // // //       console.error("Rewards discount data not available");
// // // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // // // // // // // // // //           },
// // // // // // // // // // // // // // //         })
// // // // // // // // // // // // // // //       );
// // // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     if (!myRewards?.reward) {
// // // // // // // // // // // // // // //       console.error("User rewards data not available");
// // // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // // // // // // // // // //           },
// // // // // // // // // // // // // // //         })
// // // // // // // // // // // // // // //       );
// // // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // // // // // // //     let points;

// // // // // // // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // // // // // // //     } else if (type === "yearly") {
// // // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // // // // // // //     } else {
// // // // // // // // // // // // // // //       console.error("Invalid coupon type:", type);
// // // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // // //             message: "Please select a valid coupon type.",
// // // // // // // // // // // // // // //           },
// // // // // // // // // // // // // // //         })
// // // // // // // // // // // // // // //       );
// // // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // Check if user has enough points
// // // // // // // // // // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // // // // // // // // // //     if (currentPoints < points) {
// // // // // // // // // // // // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // // // // // // // // // //           },
// // // // // // // // // // // // // // //         })
// // // // // // // // // // // // // // //       );
// // // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // // //     }

// // // // // // // // // // // // // // //     // Start redemption process
// // // // // // // // // // // // // // //     setIsRedeeming(true);

// // // // // // // // // // // // // // //     try {
// // // // // // // // // // // // // // //       console.log("Calling redemption API...");
      
// // // // // // // // // // // // // // //       // REPLACE THIS URL WITH YOUR ACTUAL REDEMPTION API ENDPOINT
// // // // // // // // // // // // // // //       const response = await fetch("YOUR_REDEMPTION_API_ENDPOINT_HERE", {
// // // // // // // // // // // // // // //         method: "POST",
// // // // // // // // // // // // // // //         headers: {
// // // // // // // // // // // // // // //           "Content-Type": "application/json",
// // // // // // // // // // // // // // //           // Add authorization if needed
// // // // // // // // // // // // // // //           // "Authorization": `Bearer ${user.accessToken}`,
// // // // // // // // // // // // // // //         },
// // // // // // // // // // // // // // //         body: JSON.stringify({
// // // // // // // // // // // // // // //           couponType: type,
// // // // // // // // // // // // // // //           points: points,
// // // // // // // // // // // // // // //           userId: user?.id,
// // // // // // // // // // // // // // //           // Add any other fields your API needs
// // // // // // // // // // // // // // //         }),
// // // // // // // // // // // // // // //       });

// // // // // // // // // // // // // // //       const apiResponse = await response.json();
// // // // // // // // // // // // // // //       console.log("API Response:", apiResponse);

// // // // // // // // // // // // // // //       if (response.ok && apiResponse.success) {
// // // // // // // // // // // // // // //         // Success - show success modal with API response
// // // // // // // // // // // // // // //         dispatch(
// // // // // // // // // // // // // // //           updateModalType({
// // // // // // // // // // // // // // //             type: ModalType.COUPON_POINTS,
// // // // // // // // // // // // // // //             data: {
// // // // // // // // // // // // // // //               actionType: "REDEEM_SUCCESS",
// // // // // // // // // // // // // // //               couponType: type,
// // // // // // // // // // // // // // //               points: points,
// // // // // // // // // // // // // // //               apiResponse: apiResponse,
// // // // // // // // // // // // // // //               message: apiResponse.message || "Coupon redeemed successfully!",
// // // // // // // // // // // // // // //             },
// // // // // // // // // // // // // // //           })
// // // // // // // // // // // // // // //         );

// // // // // // // // // // // // // // //         // Close the Get Coupon modal
// // // // // // // // // // // // // // //         dispatch(updateModalType({ type: null }));

// // // // // // // // // // // // // // //         // Reset form
// // // // // // // // // // // // // // //         reset();

// // // // // // // // // // // // // // //         // Refresh rewards data to show updated points
// // // // // // // // // // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // // // // //       } else {
// // // // // // // // // // // // // // //         // API returned error
// // // // // // // // // // // // // // //         throw new Error(apiResponse.message || "Failed to redeem coupon");
// // // // // // // // // // // // // // //       }
// // // // // // // // // // // // // // //     } catch (error) {
// // // // // // // // // // // // // // //       console.error("Redemption error:", error);
      
// // // // // // // // // // // // // // //       // Show error modal
// // // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // // //             message: error.message || "Failed to redeem coupon. Please try again.",
// // // // // // // // // // // // // // //           },
// // // // // // // // // // // // // // //         })
// // // // // // // // // // // // // // //       );
// // // // // // // // // // // // // // //     } finally {
// // // // // // // // // // // // // // //       setIsRedeeming(false);
// // // // // // // // // // // // // // //     }
// // // // // // // // // // // // // // //   };

// // // // // // // // // // // // // // //   return {
// // // // // // // // // // // // // // //     rewardsActions,
// // // // // // // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // // // // // // //     fields: fields,
// // // // // // // // // // // // // // //     onSubmit,
// // // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // // //     errors,
// // // // // // // // // // // // // // //     loading: loading || isRedeeming,
// // // // // // // // // // // // // // //     myRewards,
// // // // // // // // // // // // // // //     isRedeeming,
// // // // // // // // // // // // // // //   };
// // // // // // // // // // // // // // // };




// // // // // // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // // // // // // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(0);
// // // // // // // // // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // // // // // //       try {
// // // // // // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // // //         console.error("Error fetching rewards discount:", err);
// // // // // // // // // // // // // //       }
// // // // // // // // // // // // // //     };

// // // // // // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // // // // // //   }, [dispatch]);

// // // // // // // // // // // // // //   // Fetch coupon history and calculate total points used
// // // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // // //     const fetchCouponHistoryTotal = async () => {
// // // // // // // // // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // // // // // // // // //       try {
// // // // // // // // // // // // // //         const response = await dispatch(
// // // // // // // // // // // // // //           readCouponHistory({
// // // // // // // // // // // // // //             params: {
// // // // // // // // // // // // // //               uid: user.user.id,
// // // // // // // // // // // // // //               page: 1,
// // // // // // // // // // // // // //               size: 1000, // Fetch all to calculate total
// // // // // // // // // // // // // //               order: "desc",
// // // // // // // // // // // // // //             },
// // // // // // // // // // // // // //           })
// // // // // // // // // // // // // //         );

// // // // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // // // //           // Calculate total points from all coupon history records
// // // // // // // // // // // // // //           const total = response.payload.data.reduce((sum, coupon) => {
// // // // // // // // // // // // // //             return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // // // // // //           }, 0);
          
// // // // // // // // // // // // // //           setTotalCouponPoints(total);
// // // // // // // // // // // // // //           console.log("💳 Total Coupon Points Calculated:", total);
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // // //         console.error("Error fetching coupon history:", err);
// // // // // // // // // // // // // //       }
// // // // // // // // // // // // // //     };

// // // // // // // // // // // // // //     fetchCouponHistoryTotal();
// // // // // // // // // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // // // // // //   };

// // // // // // // // // // // // // //   const rewardsActions = [
// // // // // // // // // // // // // //     {
// // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // //       text: "Points History",
// // // // // // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // // // // // //     },
// // // // // // // // // // // // // //     {
// // // // // // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // // // // // //     },
// // // // // // // // // // // // // //     {
// // // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // // // // // //     },
// // // // // // // // // // // // // //   ];

// // // // // // // // // // // // // //   const {
// // // // // // // // // // // // // //     register,
// // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // //     formState: { errors },
// // // // // // // // // // // // // //     reset,
// // // // // // // // // // // // // //   } = useForm({
// // // // // // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // // // // // //   });

// // // // // // // // // // // // // //   const fields = GetCouponFormFields(register, loading);

// // // // // // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // // // // // //     console.log("Form submitted with data:", data);

// // // // // // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // // // // // //       console.error("Rewards discount data not available");
// // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // // // // // // // // //           },
// // // // // // // // // // // // // //         })
// // // // // // // // // // // // // //       );
// // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     if (!myRewards?.reward) {
// // // // // // // // // // // // // //       console.error("User rewards data not available");
// // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // // // // // // // // //           },
// // // // // // // // // // // // // //         })
// // // // // // // // // // // // // //       );
// // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // // // // // //     let points;

// // // // // // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // // // // // //     } else if (type === "yearly") {
// // // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // // // // // //     } else {
// // // // // // // // // // // // // //       console.error("Invalid coupon type:", type);
// // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // //             message: "Please select a valid coupon type.",
// // // // // // // // // // // // // //           },
// // // // // // // // // // // // // //         })
// // // // // // // // // // // // // //       );
// // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Check if user has enough points
// // // // // // // // // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // // // // // // // // //     if (currentPoints < points) {
// // // // // // // // // // // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // // // // // // // // //           },
// // // // // // // // // // // // // //         })
// // // // // // // // // // // // // //       );
// // // // // // // // // // // // // //       return;
// // // // // // // // // // // // // //     }

// // // // // // // // // // // // // //     // Start redemption process
// // // // // // // // // // // // // //     setIsRedeeming(true);

// // // // // // // // // // // // // //     try {
// // // // // // // // // // // // // //       console.log("Calling redemption API...");
      
// // // // // // // // // // // // // //       // REPLACE THIS URL WITH YOUR ACTUAL REDEMPTION API ENDPOINT
// // // // // // // // // // // // // //       const response = await fetch("YOUR_REDEMPTION_API_ENDPOINT_HERE", {
// // // // // // // // // // // // // //         method: "POST",
// // // // // // // // // // // // // //         headers: {
// // // // // // // // // // // // // //           "Content-Type": "application/json",
// // // // // // // // // // // // // //           // Add authorization if needed
// // // // // // // // // // // // // //           // "Authorization": `Bearer ${user.accessToken}`,
// // // // // // // // // // // // // //         },
// // // // // // // // // // // // // //         body: JSON.stringify({
// // // // // // // // // // // // // //           couponType: type,
// // // // // // // // // // // // // //           points: points,
// // // // // // // // // // // // // //           userId: user?.id,
// // // // // // // // // // // // // //         }),
// // // // // // // // // // // // // //       });

// // // // // // // // // // // // // //       const apiResponse = await response.json();
// // // // // // // // // // // // // //       console.log("API Response:", apiResponse);

// // // // // // // // // // // // // //       if (response.ok && apiResponse.success) {
// // // // // // // // // // // // // //         // Success - show success modal
// // // // // // // // // // // // // //         dispatch(
// // // // // // // // // // // // // //           updateModalType({
// // // // // // // // // // // // // //             type: ModalType.COUPON_POINTS,
// // // // // // // // // // // // // //             data: {
// // // // // // // // // // // // // //               actionType: "REDEEM_SUCCESS",
// // // // // // // // // // // // // //               couponType: type,
// // // // // // // // // // // // // //               points: points,
// // // // // // // // // // // // // //               apiResponse: apiResponse,
// // // // // // // // // // // // // //               message: apiResponse.message || "Coupon redeemed successfully!",
// // // // // // // // // // // // // //             },
// // // // // // // // // // // // // //           })
// // // // // // // // // // // // // //         );

// // // // // // // // // // // // // //         // Close the Get Coupon modal
// // // // // // // // // // // // // //         dispatch(updateModalType({ type: null }));

// // // // // // // // // // // // // //         // Reset form
// // // // // // // // // // // // // //         reset();

// // // // // // // // // // // // // //         // Refresh rewards data
// // // // // // // // // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
        
// // // // // // // // // // // // // //         // Refresh coupon history total
// // // // // // // // // // // // // //         const historyResponse = await dispatch(
// // // // // // // // // // // // // //           readCouponHistory({
// // // // // // // // // // // // // //             params: {
// // // // // // // // // // // // // //               uid: user.user.id,
// // // // // // // // // // // // // //               page: 1,
// // // // // // // // // // // // // //               size: 1000,
// // // // // // // // // // // // // //               order: "desc",
// // // // // // // // // // // // // //             },
// // // // // // // // // // // // // //           })
// // // // // // // // // // // // // //         );

// // // // // // // // // // // // // //         if (historyResponse?.payload?.data) {
// // // // // // // // // // // // // //           const total = historyResponse.payload.data.reduce((sum, coupon) => {
// // // // // // // // // // // // // //             return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // // // // // //           }, 0);
// // // // // // // // // // // // // //           setTotalCouponPoints(total);
// // // // // // // // // // // // // //           console.log("💳 Updated Total Coupon Points:", total);
// // // // // // // // // // // // // //         }
// // // // // // // // // // // // // //       } else {
// // // // // // // // // // // // // //         throw new Error(apiResponse.message || "Failed to redeem coupon");
// // // // // // // // // // // // // //       }
// // // // // // // // // // // // // //     } catch (error) {
// // // // // // // // // // // // // //       console.error("Redemption error:", error);
      
// // // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // // //           data: {
// // // // // // // // // // // // // //             message: error.message || "Failed to redeem coupon. Please try again.",
// // // // // // // // // // // // // //           },
// // // // // // // // // // // // // //         })
// // // // // // // // // // // // // //       );
// // // // // // // // // // // // // //     } finally {
// // // // // // // // // // // // // //       setIsRedeeming(false);
// // // // // // // // // // // // // //     }
// // // // // // // // // // // // // //   };

// // // // // // // // // // // // // //   // Create updated myRewards object with correct coupon points
// // // // // // // // // // // // // //   const updatedMyRewards = myRewards ? {
// // // // // // // // // // // // // //     ...myRewards,
// // // // // // // // // // // // // //     reward: {
// // // // // // // // // // // // // //       ...myRewards.reward,
// // // // // // // // // // // // // //       coupons: totalCouponPoints, // Replace the placeholder value with actual total
// // // // // // // // // // // // // //     }
// // // // // // // // // // // // // //   } : null;

// // // // // // // // // // // // // //   return {
// // // // // // // // // // // // // //     rewardsActions,
// // // // // // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // // // // // //     fields: fields,
// // // // // // // // // // // // // //     onSubmit,
// // // // // // // // // // // // // //     control,
// // // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // // //     errors,
// // // // // // // // // // // // // //     loading: loading || isRedeeming,
// // // // // // // // // // // // // //     myRewards: updatedMyRewards, // Return updated myRewards with correct coupon total
// // // // // // // // // // // // // //     isRedeeming,
// // // // // // // // // // // // // //     totalCouponPoints,
// // // // // // // // // // // // // //   };
// // // // // // // // // // // // // // };


// // // // // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // // // // // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // // // // // // // // // //   const [isFetchingCoupons, setIsFetchingCoupons] = useState(false);
// // // // // // // // // // // // //   const { loading: myRewardsLoading } = useSelector((state) => state.myRewards);
// // // // // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // // // // //   // Fetch user rewards
// // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // //     if (user && !authLoading) {
// // // // // // // // // // // // //       fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // // //     }
// // // // // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // // // // //   // Log when myRewards updates
// // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // //     if (myRewards?.reward) {
// // // // // // // // // // // // //       console.log("🎯 MyRewards from DB:", {
// // // // // // // // // // // // //         active: myRewards.reward.active,
// // // // // // // // // // // // //         coupons: myRewards.reward.coupons,
// // // // // // // // // // // // //         redeemed: myRewards.reward.redeemed,
// // // // // // // // // // // // //         total: myRewards.reward.total,
// // // // // // // // // // // // //       });
// // // // // // // // // // // // //     }
// // // // // // // // // // // // //   }, [myRewards]);

// // // // // // // // // // // // //   // Fetch rewards discount configuration
// // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // // // // //       try {
// // // // // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // // // // //         }
// // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // //         console.error("Error fetching rewards discount:", err);
// // // // // // // // // // // // //       }
// // // // // // // // // // // // //     };

// // // // // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // // // // //   }, [dispatch]);

// // // // // // // // // // // // //   // Fetch ALL coupon history records to calculate accurate total
// // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // //     const fetchAllCouponHistory = async () => {
// // // // // // // // // // // // //       if (authLoading || !user?.user?.id || isFetchingCoupons) return;

// // // // // // // // // // // // //       setIsFetchingCoupons(true);

// // // // // // // // // // // // //       try {
// // // // // // // // // // // // //         console.log("📊 Starting to fetch ALL coupon history...");
// // // // // // // // // // // // //         console.log("👤 User ID:", user.user.id);
        
// // // // // // // // // // // // //         let allCoupons = [];
// // // // // // // // // // // // //         let currentPage = 1;
// // // // // // // // // // // // //         let hasMore = true;
// // // // // // // // // // // // //         const pageSize = 100;

// // // // // // // // // // // // //         while (hasMore) {
// // // // // // // // // // // // //           console.log(`📄 Fetching page ${currentPage}...`);
          
// // // // // // // // // // // // //           const response = await dispatch(
// // // // // // // // // // // // //             readCouponHistory({
// // // // // // // // // // // // //               params: {
// // // // // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // // // // //                 page: currentPage,
// // // // // // // // // // // // //                 size: pageSize,
// // // // // // // // // // // // //                 order: "desc",
// // // // // // // // // // // // //               },
// // // // // // // // // // // // //             })
// // // // // // // // // // // // //           );

// // // // // // // // // // // // //           console.log(`📨 Page ${currentPage} Response:`, response);

// // // // // // // // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // // // // // // // //             allCoupons = [...allCoupons, ...response.payload.data];
            
// // // // // // // // // // // // //             const pagination = response.payload.pagination;
// // // // // // // // // // // // //             console.log(`📊 Pagination info:`, pagination);
            
// // // // // // // // // // // // //             const totalPages = Math.ceil(pagination.total / pageSize);
            
// // // // // // // // // // // // //             console.log(`📄 Page ${currentPage}/${totalPages} - Records fetched this page: ${response.payload.data.length}, Total so far: ${allCoupons.length}`);
            
// // // // // // // // // // // // //             if (currentPage >= totalPages || response.payload.data.length === 0) {
// // // // // // // // // // // // //               hasMore = false;
// // // // // // // // // // // // //             } else {
// // // // // // // // // // // // //               currentPage++;
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //           } else {
// // // // // // // // // // // // //             console.log("❌ Invalid response structure");
// // // // // // // // // // // // //             hasMore = false;
// // // // // // // // // // // // //           }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         console.log("📊 ========== ALL COUPON RECORDS ==========");
// // // // // // // // // // // // //         console.log(`Total coupon records fetched: ${allCoupons.length}`);
        
// // // // // // // // // // // // //         // Log each coupon and calculate total
// // // // // // // // // // // // //         let calculatedTotal = 0;
// // // // // // // // // // // // //         allCoupons.forEach((coupon, index) => {
// // // // // // // // // // // // //           const points = parseInt(coupon.points, 10) || 0;
// // // // // // // // // // // // //           calculatedTotal += points;
// // // // // // // // // // // // //           console.log(`#${index + 1} | ID: ${coupon.id} | Type: ${coupon.type} | Points: ${points} | Running Total: ${calculatedTotal}`);
// // // // // // // // // // // // //         });
        
// // // // // // // // // // // // //         console.log("💳 ========== FINAL CALCULATION ==========");
// // // // // // // // // // // // //         console.log(`💳 Calculated Total: ${calculatedTotal}`);
// // // // // // // // // // // // //         console.log(`💳 Number of coupons: ${allCoupons.length}`);
// // // // // // // // // // // // //         console.log("💳 ========================================");
        
// // // // // // // // // // // // //         setTotalCouponPoints(calculatedTotal);
        
// // // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // // //         console.error("❌ Error fetching coupon history:", err);
// // // // // // // // // // // // //         setTotalCouponPoints(0);
// // // // // // // // // // // // //       } finally {
// // // // // // // // // // // // //         setIsFetchingCoupons(false);
// // // // // // // // // // // // //       }
// // // // // // // // // // // // //     };

// // // // // // // // // // // // //     fetchAllCouponHistory();
// // // // // // // // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // // // // //   };

// // // // // // // // // // // // //   const rewardsActions = [
// // // // // // // // // // // // //     {
// // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // //       text: "Points History",
// // // // // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // // // // //     },
// // // // // // // // // // // // //     {
// // // // // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // // // // //     },
// // // // // // // // // // // // //     {
// // // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // // // // //     },
// // // // // // // // // // // // //   ];

// // // // // // // // // // // // //   const {
// // // // // // // // // // // // //     register,
// // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // //     control,
// // // // // // // // // // // // //     formState: { errors },
// // // // // // // // // // // // //     reset,
// // // // // // // // // // // // //   } = useForm({
// // // // // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // // // // //   });

// // // // // // // // // // // // //   const fields = GetCouponFormFields(register, myRewardsLoading || isRedeeming);

// // // // // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // // // // //     console.log("📝 Form submitted with data:", data);

// // // // // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // // // // //       console.error("❌ Rewards discount data not available");
// // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // //           data: {
// // // // // // // // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // // // // // // // //           },
// // // // // // // // // // // // //         })
// // // // // // // // // // // // //       );
// // // // // // // // // // // // //       return;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     if (!myRewards?.reward) {
// // // // // // // // // // // // //       console.error("❌ User rewards data not available");
// // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // //           data: {
// // // // // // // // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // // // // // // // //           },
// // // // // // // // // // // // //         })
// // // // // // // // // // // // //       );
// // // // // // // // // // // // //       return;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // // // // //     let points;

// // // // // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // // // // //     } else if (type === "yearly") {
// // // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // // // // //     } else {
// // // // // // // // // // // // //       console.error("❌ Invalid coupon type:", type);
// // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // //           data: {
// // // // // // // // // // // // //             message: "Please select a valid coupon type.",
// // // // // // // // // // // // //           },
// // // // // // // // // // // // //         })
// // // // // // // // // // // // //       );
// // // // // // // // // // // // //       return;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // // // // // // // //     if (currentPoints < points) {
// // // // // // // // // // // // //       console.error(`❌ Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // //           data: {
// // // // // // // // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // // // // // // // //           },
// // // // // // // // // // // // //         })
// // // // // // // // // // // // //       );
// // // // // // // // // // // // //       return;
// // // // // // // // // // // // //     }

// // // // // // // // // // // // //     setIsRedeeming(true);

// // // // // // // // // // // // //     try {
// // // // // // // // // // // // //       console.log("📤 Calling redemption API...");
      
// // // // // // // // // // // // //       const response = await fetch("YOUR_REDEMPTION_API_ENDPOINT_HERE", {
// // // // // // // // // // // // //         method: "POST",
// // // // // // // // // // // // //         headers: {
// // // // // // // // // // // // //           "Content-Type": "application/json",
// // // // // // // // // // // // //         },
// // // // // // // // // // // // //         body: JSON.stringify({
// // // // // // // // // // // // //           couponType: type,
// // // // // // // // // // // // //           points: points,
// // // // // // // // // // // // //           userId: user?.user?.id,
// // // // // // // // // // // // //         }),
// // // // // // // // // // // // //       });

// // // // // // // // // // // // //       const apiResponse = await response.json();
// // // // // // // // // // // // //       console.log("📨 API Response:", apiResponse);

// // // // // // // // // // // // //       if (response.ok && apiResponse.success) {
// // // // // // // // // // // // //         console.log("✅ Coupon redemption successful");

// // // // // // // // // // // // //         dispatch(
// // // // // // // // // // // // //           updateModalType({
// // // // // // // // // // // // //             type: ModalType.COUPON_POINTS,
// // // // // // // // // // // // //             data: {
// // // // // // // // // // // // //               actionType: "REDEEM_SUCCESS",
// // // // // // // // // // // // //               couponType: type,
// // // // // // // // // // // // //               points: points,
// // // // // // // // // // // // //               apiResponse: apiResponse,
// // // // // // // // // // // // //               message: apiResponse.message || "Coupon redeemed successfully!",
// // // // // // // // // // // // //             },
// // // // // // // // // // // // //           })
// // // // // // // // // // // // //         );

// // // // // // // // // // // // //         dispatch(updateModalType({ type: null }));
// // // // // // // // // // // // //         reset();

// // // // // // // // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
        
// // // // // // // // // // // // //         // Recalculate total
// // // // // // // // // // // // //         let allCoupons = [];
// // // // // // // // // // // // //         let currentPage = 1;
// // // // // // // // // // // // //         let hasMore = true;
// // // // // // // // // // // // //         const pageSize = 100;

// // // // // // // // // // // // //         while (hasMore) {
// // // // // // // // // // // // //           const historyResponse = await dispatch(
// // // // // // // // // // // // //             readCouponHistory({
// // // // // // // // // // // // //               params: {
// // // // // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // // // // //                 page: currentPage,
// // // // // // // // // // // // //                 size: pageSize,
// // // // // // // // // // // // //                 order: "desc",
// // // // // // // // // // // // //               },
// // // // // // // // // // // // //             })
// // // // // // // // // // // // //           );

// // // // // // // // // // // // //           if (historyResponse?.payload?.data && Array.isArray(historyResponse.payload.data)) {
// // // // // // // // // // // // //             allCoupons = [...allCoupons, ...historyResponse.payload.data];
            
// // // // // // // // // // // // //             const pagination = historyResponse.payload.pagination;
// // // // // // // // // // // // //             const totalPages = Math.ceil(pagination.total / pageSize);
            
// // // // // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // // // // //               hasMore = false;
// // // // // // // // // // // // //             } else {
// // // // // // // // // // // // //               currentPage++;
// // // // // // // // // // // // //             }
// // // // // // // // // // // // //           } else {
// // // // // // // // // // // // //             hasMore = false;
// // // // // // // // // // // // //           }
// // // // // // // // // // // // //         }

// // // // // // // // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // // // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // // // // //         }, 0);
        
// // // // // // // // // // // // //         setTotalCouponPoints(total);
// // // // // // // // // // // // //         console.log("💳 Updated Total Coupon Points:", total);
// // // // // // // // // // // // //       } else {
// // // // // // // // // // // // //         throw new Error(apiResponse.message || "Failed to redeem coupon");
// // // // // // // // // // // // //       }
// // // // // // // // // // // // //     } catch (error) {
// // // // // // // // // // // // //       console.error("❌ Redemption error:", error);
      
// // // // // // // // // // // // //       dispatch(
// // // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // // //           data: {
// // // // // // // // // // // // //             message: error.message || "Failed to redeem coupon. Please try again.",
// // // // // // // // // // // // //           },
// // // // // // // // // // // // //         })
// // // // // // // // // // // // //       );
// // // // // // // // // // // // //     } finally {
// // // // // // // // // // // // //       setIsRedeeming(false);
// // // // // // // // // // // // //     }
// // // // // // // // // // // // //   };

// // // // // // // // // // // // //   // CRITICAL: Force use calculated total, ignore DB value
// // // // // // // // // // // // //   const updatedMyRewards = myRewards && totalCouponPoints !== null ? {
// // // // // // // // // // // // //     ...myRewards,
// // // // // // // // // // // // //     reward: {
// // // // // // // // // // // // //       ...myRewards.reward,
// // // // // // // // // // // // //       coupons: totalCouponPoints, // ALWAYS use calculated total
// // // // // // // // // // // // //     }
// // // // // // // // // // // // //   } : myRewards;

// // // // // // // // // // // // //   // Enhanced debug logging
// // // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // // //     if (myRewards && totalCouponPoints !== null) {
// // // // // // // // // // // // //       console.log("🔍 ========== COMPARISON ==========");
// // // // // // // // // // // // //       console.log("🔍 DB coupons value:", myRewards?.reward?.coupons);
// // // // // // // // // // // // //       console.log("🔍 Calculated total:", totalCouponPoints);
// // // // // // // // // // // // //       console.log("🔍 Difference:", myRewards?.reward?.coupons - totalCouponPoints);
// // // // // // // // // // // // //       console.log("🔍 Final displayed:", updatedMyRewards?.reward?.coupons);
// // // // // // // // // // // // //       console.log("🔍 ==================================");
// // // // // // // // // // // // //     }
// // // // // // // // // // // // //   }, [myRewards, totalCouponPoints]);

// // // // // // // // // // // // //   return {
// // // // // // // // // // // // //     rewardsActions,
// // // // // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // // // // //     fields,
// // // // // // // // // // // // //     onSubmit,
// // // // // // // // // // // // //     control,
// // // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // // //     errors,
// // // // // // // // // // // // //     loading: myRewardsLoading || isRedeeming || isFetchingCoupons,
// // // // // // // // // // // // //     myRewards: updatedMyRewards,
// // // // // // // // // // // // //     myRewardsLoading,
// // // // // // // // // // // // //     isRedeeming,
// // // // // // // // // // // // //     totalCouponPoints,
// // // // // // // // // // // // //   };
// // // // // // // // // // // // // };




// // // // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // // // // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // // // // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // // // //       try {
// // // // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // // // //         }
// // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // //         console.error("Error fetching dashboard links:", err);
// // // // // // // // // // // //       }
// // // // // // // // // // // //     };

// // // // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // // // //   }, [dispatch]);

// // // // // // // // // // // //   // NEW: Fetch all coupon history and calculate total
// // // // // // // // // // // //   useEffect(() => {
// // // // // // // // // // // //     const calculateTotalCouponPoints = async () => {
// // // // // // // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // // // // // // //       try {
// // // // // // // // // // // //         let allCoupons = [];
// // // // // // // // // // // //         let currentPage = 1;
// // // // // // // // // // // //         let hasMore = true;

// // // // // // // // // // // //         // Fetch all pages of coupon history
// // // // // // // // // // // //         while (hasMore) {
// // // // // // // // // // // //           const response = await dispatch(
// // // // // // // // // // // //             readCouponHistory({
// // // // // // // // // // // //               params: {
// // // // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // // // //                 page: currentPage,
// // // // // // // // // // // //                 size: 100,
// // // // // // // // // // // //                 order: "desc",
// // // // // // // // // // // //               },
// // // // // // // // // // // //             })
// // // // // // // // // // // //           );

// // // // // // // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // // // // // // //             allCoupons = [...allCoupons, ...response.payload.data];
            
// // // // // // // // // // // //             const pagination = response.payload.pagination;
// // // // // // // // // // // //             const totalPages = Math.ceil(pagination.total / 100);
            
// // // // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // // // //               hasMore = false;
// // // // // // // // // // // //             } else {
// // // // // // // // // // // //               currentPage++;
// // // // // // // // // // // //             }
// // // // // // // // // // // //           } else {
// // // // // // // // // // // //             hasMore = false;
// // // // // // // // // // // //           }
// // // // // // // // // // // //         }

// // // // // // // // // // // //         // Calculate total points
// // // // // // // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // // // //         }, 0);
        
// // // // // // // // // // // //         setTotalCouponPoints(total);
// // // // // // // // // // // //       } catch (err) {
// // // // // // // // // // // //         console.error("Error calculating total coupon points:", err);
// // // // // // // // // // // //         setTotalCouponPoints(0);
// // // // // // // // // // // //       }
// // // // // // // // // // // //     };

// // // // // // // // // // // //     calculateTotalCouponPoints();
// // // // // // // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // // // //   };

// // // // // // // // // // // //   const rewardsActions = [
// // // // // // // // // // // //     {
// // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // //       text: "Points History",
// // // // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // // // //     },
// // // // // // // // // // // //     {
// // // // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // // // //     },
// // // // // // // // // // // //     {
// // // // // // // // // // // //       icon: PointIcon,
// // // // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // // // //     },
// // // // // // // // // // // //   ];

// // // // // // // // // // // //   const {
// // // // // // // // // // // //     register,
// // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // //     control,
// // // // // // // // // // // //     formState: { errors },
// // // // // // // // // // // //     reset,
// // // // // // // // // // // //   } = useForm({
// // // // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // // // //   });

// // // // // // // // // // // //   const fields = GetCouponFormFields(register, loading);

// // // // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // // // //     console.log("Form submitted with data:", data);

// // // // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // // // //       console.error("Rewards discount data not available");
// // // // // // // // // // // //       dispatch(
// // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // //           data: {
// // // // // // // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // // // // // // //           },
// // // // // // // // // // // //         })
// // // // // // // // // // // //       );
// // // // // // // // // // // //       return;
// // // // // // // // // // // //     }

// // // // // // // // // // // //     if (!myRewards?.reward) {
// // // // // // // // // // // //       console.error("User rewards data not available");
// // // // // // // // // // // //       dispatch(
// // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // //           data: {
// // // // // // // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // // // // // // //           },
// // // // // // // // // // // //         })
// // // // // // // // // // // //       );
// // // // // // // // // // // //       return;
// // // // // // // // // // // //     }

// // // // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // // // //     let points;

// // // // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // // // //     } else if (type === "yearly") {
// // // // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // // // //     } else {
// // // // // // // // // // // //       console.error("Invalid coupon type:", type);
// // // // // // // // // // // //       dispatch(
// // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // //           data: {
// // // // // // // // // // // //             message: "Please select a valid coupon type.",
// // // // // // // // // // // //           },
// // // // // // // // // // // //         })
// // // // // // // // // // // //       );
// // // // // // // // // // // //       return;
// // // // // // // // // // // //     }

// // // // // // // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // // // // // // //     if (currentPoints < points) {
// // // // // // // // // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // // // // // // //       dispatch(
// // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // //           data: {
// // // // // // // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // // // // // // //           },
// // // // // // // // // // // //         })
// // // // // // // // // // // //       );
// // // // // // // // // // // //       return;
// // // // // // // // // // // //     }

// // // // // // // // // // // //     setIsRedeeming(true);

// // // // // // // // // // // //     try {
// // // // // // // // // // // //       console.log("Calling redemption API...");
      
// // // // // // // // // // // //       const response = await fetch("YOUR_REDEMPTION_API_ENDPOINT_HERE", {
// // // // // // // // // // // //         method: "POST",
// // // // // // // // // // // //         headers: {
// // // // // // // // // // // //           "Content-Type": "application/json",
// // // // // // // // // // // //         },
// // // // // // // // // // // //         body: JSON.stringify({
// // // // // // // // // // // //           couponType: type,
// // // // // // // // // // // //           points: points,
// // // // // // // // // // // //           userId: user?.user?.id,
// // // // // // // // // // // //         }),
// // // // // // // // // // // //       });

// // // // // // // // // // // //       const apiResponse = await response.json();
// // // // // // // // // // // //       console.log("API Response:", apiResponse);

// // // // // // // // // // // //       if (response.ok && apiResponse.success) {
// // // // // // // // // // // //         console.log("Coupon redemption successful");

// // // // // // // // // // // //         dispatch(
// // // // // // // // // // // //           updateModalType({
// // // // // // // // // // // //             type: ModalType.COUPON_POINTS,
// // // // // // // // // // // //             data: {
// // // // // // // // // // // //               actionType: "REDEEM_SUCCESS",
// // // // // // // // // // // //               couponType: type,
// // // // // // // // // // // //               points: points,
// // // // // // // // // // // //               apiResponse: apiResponse,
// // // // // // // // // // // //               message: apiResponse.message || "Coupon redeemed successfully!",
// // // // // // // // // // // //             },
// // // // // // // // // // // //           })
// // // // // // // // // // // //         );

// // // // // // // // // // // //         dispatch(updateModalType({ type: null }));
// // // // // // // // // // // //         reset();

// // // // // // // // // // // //         // Refresh rewards
// // // // // // // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
        
// // // // // // // // // // // //         // NEW: Recalculate total coupon points after redemption
// // // // // // // // // // // //         let allCoupons = [];
// // // // // // // // // // // //         let currentPage = 1;
// // // // // // // // // // // //         let hasMore = true;

// // // // // // // // // // // //         while (hasMore) {
// // // // // // // // // // // //           const historyResponse = await dispatch(
// // // // // // // // // // // //             readCouponHistory({
// // // // // // // // // // // //               params: {
// // // // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // // // //                 page: currentPage,
// // // // // // // // // // // //                 size: 100,
// // // // // // // // // // // //                 order: "desc",
// // // // // // // // // // // //               },
// // // // // // // // // // // //             })
// // // // // // // // // // // //           );

// // // // // // // // // // // //           if (historyResponse?.payload?.data && Array.isArray(historyResponse.payload.data)) {
// // // // // // // // // // // //             allCoupons = [...allCoupons, ...historyResponse.payload.data];
            
// // // // // // // // // // // //             const pagination = historyResponse.payload.pagination;
// // // // // // // // // // // //             const totalPages = Math.ceil(pagination.total / 100);
            
// // // // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // // // //               hasMore = false;
// // // // // // // // // // // //             } else {
// // // // // // // // // // // //               currentPage++;
// // // // // // // // // // // //             }
// // // // // // // // // // // //           } else {
// // // // // // // // // // // //             hasMore = false;
// // // // // // // // // // // //           }
// // // // // // // // // // // //         }

// // // // // // // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // // // //         }, 0);
        
// // // // // // // // // // // //         setTotalCouponPoints(total);
// // // // // // // // // // // //       } else {
// // // // // // // // // // // //         throw new Error(apiResponse.message || "Failed to redeem coupon");
// // // // // // // // // // // //       }
// // // // // // // // // // // //     } catch (error) {
// // // // // // // // // // // //       console.error("Redemption error:", error);
      
// // // // // // // // // // // //       dispatch(
// // // // // // // // // // // //         updateModalType({
// // // // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // // // //           data: {
// // // // // // // // // // // //             message: error.message || "Failed to redeem coupon. Please try again.",
// // // // // // // // // // // //           },
// // // // // // // // // // // //         })
// // // // // // // // // // // //       );
// // // // // // // // // // // //     } finally {
// // // // // // // // // // // //       setIsRedeeming(false);
// // // // // // // // // // // //     }
// // // // // // // // // // // //   };

// // // // // // // // // // // //   // NEW: Replace DB value with calculated total
// // // // // // // // // // // //   const updatedMyRewards = myRewards && totalCouponPoints !== null ? {
// // // // // // // // // // // //     ...myRewards,
// // // // // // // // // // // //     reward: {
// // // // // // // // // // // //       ...myRewards.reward,
// // // // // // // // // // // //       coupons: totalCouponPoints,
// // // // // // // // // // // //     }
// // // // // // // // // // // //   } : myRewards;

// // // // // // // // // // // //   return {
// // // // // // // // // // // //     rewardsActions,
// // // // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // // // //     fields: fields,
// // // // // // // // // // // //     onSubmit,
// // // // // // // // // // // //     control,
// // // // // // // // // // // //     handleSubmit,
// // // // // // // // // // // //     errors,
// // // // // // // // // // // //     loading: loading || isRedeeming,
// // // // // // // // // // // //     myRewards: updatedMyRewards, // Return updated myRewards with real total
// // // // // // // // // // // //     isRedeeming,
// // // // // // // // // // // //   };
// // // // // // // // // // // // };



// // // // // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // // // // import { useForm } from "react-hook-form";
// // // // // // // // // // import { useEffect, useState } from "react";
// // // // // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // // // // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // // // // export const useMyRewards = () => {
// // // // // // // // // //   const dispatch = useDispatch();
// // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // // // // // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // // // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // // // // //       try {
// // // // // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // // // // //         if (response?.payload?.data) {
// // // // // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // // // // //         }
// // // // // // // // // //       } catch (err) {
// // // // // // // // // //         console.error("Error fetching dashboard links:", err);
// // // // // // // // // //       }
// // // // // // // // // //     };

// // // // // // // // // //     fetchMyRewardsDiscount();
// // // // // // // // // //   }, [dispatch]);

// // // // // // // // // //   // Calculate total coupon points
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     const calculateTotalCouponPoints = async () => {
// // // // // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // // // // //       try {
// // // // // // // // // //         let allCoupons = [];
// // // // // // // // // //         let currentPage = 1;
// // // // // // // // // //         let hasMore = true;

// // // // // // // // // //         while (hasMore) {
// // // // // // // // // //           const response = await dispatch(
// // // // // // // // // //             readCouponHistory({
// // // // // // // // // //               params: {
// // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // //                 page: currentPage,
// // // // // // // // // //                 size: 100,
// // // // // // // // // //                 order: "desc",
// // // // // // // // // //               },
// // // // // // // // // //             })
// // // // // // // // // //           );

// // // // // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // // // // //             allCoupons = [...allCoupons, ...response.payload.data];
            
// // // // // // // // // //             const pagination = response.payload.pagination;
// // // // // // // // // //             const totalPages = Math.ceil(pagination.total / 100);
            
// // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // //               hasMore = false;
// // // // // // // // // //             } else {
// // // // // // // // // //               currentPage++;
// // // // // // // // // //             }
// // // // // // // // // //           } else {
// // // // // // // // // //             hasMore = false;
// // // // // // // // // //           }
// // // // // // // // // //         }

// // // // // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // //         }, 0);
        
// // // // // // // // // //         setTotalCouponPoints(total);
// // // // // // // // // //       } catch (err) {
// // // // // // // // // //         console.error("Error calculating total coupon points:", err);
// // // // // // // // // //         setTotalCouponPoints(0);
// // // // // // // // // //       }
// // // // // // // // // //     };

// // // // // // // // // //     calculateTotalCouponPoints();
// // // // // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // // // // //   // Calculate total redeemed points
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     const calculateTotalRedeemedPoints = async () => {
// // // // // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // // // // //       try {
// // // // // // // // // //         let allRedeems = [];
// // // // // // // // // //         let currentPage = 1;
// // // // // // // // // //         let hasMore = true;

// // // // // // // // // //         while (hasMore) {
// // // // // // // // // //           const response = await dispatch(
// // // // // // // // // //             readRedeemHistory({
// // // // // // // // // //               params: {
// // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // //                 page: currentPage,
// // // // // // // // // //                 size: 100,
// // // // // // // // // //                 sort: "createdAt",
// // // // // // // // // //                 order: "desc",
// // // // // // // // // //               },
// // // // // // // // // //             })
// // // // // // // // // //           );

// // // // // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // // // // //             allRedeems = [...allRedeems, ...response.payload.data];
            
// // // // // // // // // //             const pagination = response.payload.pagination;
// // // // // // // // // //             const totalPages = Math.ceil(pagination.total / 100);
            
// // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // //               hasMore = false;
// // // // // // // // // //             } else {
// // // // // // // // // //               currentPage++;
// // // // // // // // // //             }
// // // // // // // // // //           } else {
// // // // // // // // // //             hasMore = false;
// // // // // // // // // //           }
// // // // // // // // // //         }

// // // // // // // // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // // // // // // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // // // // // // // //         }, 0);
        
// // // // // // // // // //         setTotalRedeemedPoints(total);
// // // // // // // // // //       } catch (err) {
// // // // // // // // // //         console.error("Error calculating total redeemed points:", err);
// // // // // // // // // //         setTotalRedeemedPoints(0);
// // // // // // // // // //       }
// // // // // // // // // //     };

// // // // // // // // // //     calculateTotalRedeemedPoints();
// // // // // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // // // // //   const handleGetCouponModal = () => {
// // // // // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // // // // //   };

// // // // // // // // // //   const rewardsActions = [
// // // // // // // // // //     {
// // // // // // // // // //       icon: PointIcon,
// // // // // // // // // //       text: "Points History",
// // // // // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // // // // //     },
// // // // // // // // // //     {
// // // // // // // // // //       icon: GetCouponIcon,
// // // // // // // // // //       text: "Get a coupon",
// // // // // // // // // //       onClick: handleGetCouponModal,
// // // // // // // // // //     },
// // // // // // // // // //     {
// // // // // // // // // //       icon: PointIcon,
// // // // // // // // // //       text: "Request Redeem",
// // // // // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // // // // //     },
// // // // // // // // // //   ];

// // // // // // // // // //   const {
// // // // // // // // // //     register,
// // // // // // // // // //     handleSubmit,
// // // // // // // // // //     control,
// // // // // // // // // //     formState: { errors },
// // // // // // // // // //     reset,
// // // // // // // // // //   } = useForm({
// // // // // // // // // //     resolver: yupResolver(schema),
// // // // // // // // // //   });

// // // // // // // // // //   const fields = GetCouponFormFields(register, loading);

// // // // // // // // // //   const onSubmit = async (data) => {
// // // // // // // // // //     console.log("Form submitted with data:", data);

// // // // // // // // // //     if (!myRewardsDiscount) {
// // // // // // // // // //       console.error("Rewards discount data not available");
// // // // // // // // // //       dispatch(
// // // // // // // // // //         updateModalType({
// // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // //           data: {
// // // // // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // // // // //           },
// // // // // // // // // //         })
// // // // // // // // // //       );
// // // // // // // // // //       return;
// // // // // // // // // //     }

// // // // // // // // // //     if (!myRewards?.reward) {
// // // // // // // // // //       console.error("User rewards data not available");
// // // // // // // // // //       dispatch(
// // // // // // // // // //         updateModalType({
// // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // //           data: {
// // // // // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // // // // //           },
// // // // // // // // // //         })
// // // // // // // // // //       );
// // // // // // // // // //       return;
// // // // // // // // // //     }

// // // // // // // // // //     const type = data?.couponType;
// // // // // // // // // //     let points;

// // // // // // // // // //     if (type === "monthly") {
// // // // // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // // // // //     } else if (type === "yearly") {
// // // // // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // // // // //     } else {
// // // // // // // // // //       console.error("Invalid coupon type:", type);
// // // // // // // // // //       dispatch(
// // // // // // // // // //         updateModalType({
// // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // //           data: {
// // // // // // // // // //             message: "Please select a valid coupon type.",
// // // // // // // // // //           },
// // // // // // // // // //         })
// // // // // // // // // //       );
// // // // // // // // // //       return;
// // // // // // // // // //     }

// // // // // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // // // // //     if (currentPoints < points) {
// // // // // // // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // // // // //       dispatch(
// // // // // // // // // //         updateModalType({
// // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // //           data: {
// // // // // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // // // // //           },
// // // // // // // // // //         })
// // // // // // // // // //       );
// // // // // // // // // //       return;
// // // // // // // // // //     }

// // // // // // // // // //     setIsRedeeming(true);

// // // // // // // // // //     try {
// // // // // // // // // //       console.log("Calling redemption API...");
      
// // // // // // // // // //       const response = await fetch("YOUR_REDEMPTION_API_ENDPOINT_HERE", {
// // // // // // // // // //         method: "POST",
// // // // // // // // // //         headers: {
// // // // // // // // // //           "Content-Type": "application/json",
// // // // // // // // // //         },
// // // // // // // // // //         body: JSON.stringify({
// // // // // // // // // //           couponType: type,
// // // // // // // // // //           points: points,
// // // // // // // // // //           userId: user?.user?.id,
// // // // // // // // // //         }),
// // // // // // // // // //       });

// // // // // // // // // //       const apiResponse = await response.json();
// // // // // // // // // //       console.log("API Response:", apiResponse);

// // // // // // // // // //       if (response.ok && apiResponse.success) {
// // // // // // // // // //         console.log("Coupon redemption successful");

// // // // // // // // // //         dispatch(
// // // // // // // // // //           updateModalType({
// // // // // // // // // //             type: ModalType.COUPON_POINTS,
// // // // // // // // // //             data: {
// // // // // // // // // //               actionType: "REDEEM_SUCCESS",
// // // // // // // // // //               couponType: type,
// // // // // // // // // //               points: points,
// // // // // // // // // //               apiResponse: apiResponse,
// // // // // // // // // //               message: apiResponse.message || "Coupon redeemed successfully!",
// // // // // // // // // //             },
// // // // // // // // // //           })
// // // // // // // // // //         );

// // // // // // // // // //         dispatch(updateModalType({ type: null }));
// // // // // // // // // //         reset();

// // // // // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
        
// // // // // // // // // //         // Recalculate coupon points
// // // // // // // // // //         let allCoupons = [];
// // // // // // // // // //         let currentPage = 1;
// // // // // // // // // //         let hasMore = true;

// // // // // // // // // //         while (hasMore) {
// // // // // // // // // //           const historyResponse = await dispatch(
// // // // // // // // // //             readCouponHistory({
// // // // // // // // // //               params: {
// // // // // // // // // //                 uid: user.user.id,
// // // // // // // // // //                 page: currentPage,
// // // // // // // // // //                 size: 100,
// // // // // // // // // //                 order: "desc",
// // // // // // // // // //               },
// // // // // // // // // //             })
// // // // // // // // // //           );

// // // // // // // // // //           if (historyResponse?.payload?.data && Array.isArray(historyResponse.payload.data)) {
// // // // // // // // // //             allCoupons = [...allCoupons, ...historyResponse.payload.data];
            
// // // // // // // // // //             const pagination = historyResponse.payload.pagination;
// // // // // // // // // //             const totalPages = Math.ceil(pagination.total / 100);
            
// // // // // // // // // //             if (currentPage >= totalPages) {
// // // // // // // // // //               hasMore = false;
// // // // // // // // // //             } else {
// // // // // // // // // //               currentPage++;
// // // // // // // // // //             }
// // // // // // // // // //           } else {
// // // // // // // // // //             hasMore = false;
// // // // // // // // // //           }
// // // // // // // // // //         }

// // // // // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // // // // //         }, 0);
        
// // // // // // // // // //         setTotalCouponPoints(total);
// // // // // // // // // //       } else {
// // // // // // // // // //         throw new Error(apiResponse.message || "Failed to redeem coupon");
// // // // // // // // // //       }
// // // // // // // // // //     } catch (error) {
// // // // // // // // // //       console.error("Redemption error:", error);
      
// // // // // // // // // //       dispatch(
// // // // // // // // // //         updateModalType({
// // // // // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // // // // //           data: {
// // // // // // // // // //             message: error.message || "Failed to redeem coupon. Please try again.",
// // // // // // // // // //           },
// // // // // // // // // //         })
// // // // // // // // // //       );
// // // // // // // // // //     } finally {
// // // // // // // // // //       setIsRedeeming(false);
// // // // // // // // // //     }
// // // // // // // // // //   };

// // // // // // // // // //   // Replace DB values with calculated totals
// // // // // // // // // //   const updatedMyRewards = myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null ? {
// // // // // // // // // //     ...myRewards,
// // // // // // // // // //     reward: {
// // // // // // // // // //       ...myRewards.reward,
// // // // // // // // // //       coupons: totalCouponPoints,
// // // // // // // // // //       redeemed: totalRedeemedPoints,
// // // // // // // // // //     }
// // // // // // // // // //   } : myRewards;

// // // // // // // // // //   return {
// // // // // // // // // //     rewardsActions,
// // // // // // // // // //     handleGetCouponModal,
// // // // // // // // // //     fields: fields,
// // // // // // // // // //     onSubmit,
// // // // // // // // // //     control,
// // // // // // // // // //     handleSubmit,
// // // // // // // // // //     errors,
// // // // // // // // // //     loading: loading || isRedeeming,
// // // // // // // // // //     myRewards: updatedMyRewards,
// // // // // // // // // //     isRedeeming,
// // // // // // // // // //   };
// // // // // // // // // // };

// // // // // // // import { ModalType } from "../../types/ui";
// // // // // // // import { useForm } from "react-hook-form";
// // // // // // // import { useEffect, useState } from "react";
// // // // // // // import { useNavigate } from "react-router-dom";
// // // // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // // // export const useMyRewards = () => {
// // // // // // //   const dispatch = useDispatch();
// // // // // // //   const navigate = useNavigate();
// // // // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // // // // //   const schema = generateGetCouponValidationSchema();

// // // // // // //   useEffect(() => {
// // // // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // // // //   }, [dispatch, authLoading, user]);

// // // // // // //   useEffect(() => {
// // // // // // //     const fetchMyRewardsDiscount = async () => {
// // // // // // //       try {
// // // // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // // // //         if (response?.payload?.data) {
// // // // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // // // //         }
// // // // // // //       } catch (err) {
// // // // // // //         console.error("Error fetching rewards discount:", err);
// // // // // // //       }
// // // // // // //     };

// // // // // // //     fetchMyRewardsDiscount();
// // // // // // //   }, [dispatch]);

// // // // // // //   // Calculate total coupon points
// // // // // // //   useEffect(() => {
// // // // // // //     const calculateTotalCouponPoints = async () => {
// // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // //       try {
// // // // // // //         let allCoupons = [];
// // // // // // //         let currentPage = 1;
// // // // // // //         let hasMore = true;

// // // // // // //         while (hasMore) {
// // // // // // //           const response = await dispatch(
// // // // // // //             readCouponHistory({
// // // // // // //               params: {
// // // // // // //                 uid: user.user.id,
// // // // // // //                 page: currentPage,
// // // // // // //                 size: 100,
// // // // // // //                 order: "desc",
// // // // // // //               },
// // // // // // //             })
// // // // // // //           );

// // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // //             allCoupons = [...allCoupons, ...response.payload.data];

// // // // // // //             const pagination = response.payload.pagination;
// // // // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // // // //             if (currentPage >= totalPages) {
// // // // // // //               hasMore = false;
// // // // // // //             } else {
// // // // // // //               currentPage++;
// // // // // // //             }
// // // // // // //           } else {
// // // // // // //             hasMore = false;
// // // // // // //           }
// // // // // // //         }

// // // // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // // // //         }, 0);

// // // // // // //         setTotalCouponPoints(total);
// // // // // // //       } catch (err) {
// // // // // // //         console.error("Error calculating total coupon points:", err);
// // // // // // //         setTotalCouponPoints(0);
// // // // // // //       }
// // // // // // //     };

// // // // // // //     calculateTotalCouponPoints();
// // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // //   // Calculate total redeemed points
// // // // // // //   useEffect(() => {
// // // // // // //     const calculateTotalRedeemedPoints = async () => {
// // // // // // //       if (authLoading || !user?.user?.id) return;

// // // // // // //       try {
// // // // // // //         let allRedeems = [];
// // // // // // //         let currentPage = 1;
// // // // // // //         let hasMore = true;

// // // // // // //         while (hasMore) {
// // // // // // //           const response = await dispatch(
// // // // // // //             readRedeemHistory({
// // // // // // //               params: {
// // // // // // //                 uid: user.user.id,
// // // // // // //                 page: currentPage,
// // // // // // //                 size: 100,
// // // // // // //                 sort: "createdAt",
// // // // // // //                 order: "desc",
// // // // // // //               },
// // // // // // //             })
// // // // // // //           );

// // // // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // // // //             allRedeems = [...allRedeems, ...response.payload.data];

// // // // // // //             const pagination = response.payload.pagination;
// // // // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // // // //             if (currentPage >= totalPages) {
// // // // // // //               hasMore = false;
// // // // // // //             } else {
// // // // // // //               currentPage++;
// // // // // // //             }
// // // // // // //           } else {
// // // // // // //             hasMore = false;
// // // // // // //           }
// // // // // // //         }

// // // // // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // // // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // // // // //         }, 0);

// // // // // // //         setTotalRedeemedPoints(total);
// // // // // // //       } catch (err) {
// // // // // // //         console.error("Error calculating total redeemed points:", err);
// // // // // // //         setTotalRedeemedPoints(0);
// // // // // // //       }
// // // // // // //     };

// // // // // // //     calculateTotalRedeemedPoints();
// // // // // // //   }, [dispatch, user, authLoading]);

// // // // // // //   const handleGetCouponModal = () => {
// // // // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // // // //   };

// // // // // // //   const rewardsActions = [
// // // // // // //     {
// // // // // // //       icon: PointIcon,
// // // // // // //       text: "Points History",
// // // // // // //       onClick: () => navigate("/point-history"),
// // // // // // //     },
// // // // // // //     {
// // // // // // //       icon: GetCouponIcon,
// // // // // // //       text: "Get a coupon",
// // // // // // //       onClick: handleGetCouponModal,
// // // // // // //     },
// // // // // // //     {
// // // // // // //       icon: PointIcon,
// // // // // // //       text: "Request Redeem",
// // // // // // //       onClick: () => navigate("/request-redeem"),
// // // // // // //     },
// // // // // // //   ];

// // // // // // //   const {
// // // // // // //     register,
// // // // // // //     handleSubmit,
// // // // // // //     control,
// // // // // // //     formState: { errors },
// // // // // // //     reset,
// // // // // // //   } = useForm({
// // // // // // //     resolver: yupResolver(schema),
// // // // // // //   });

// // // // // // //   const fields = GetCouponFormFields(register, isRedeeming);

// // // // // // //   const onSubmit = async (data) => {
// // // // // // //     console.log("Form submitted with data:", data);

// // // // // // //     // Validation checks
// // // // // // //     if (!myRewardsDiscount) {
// // // // // // //       console.error("Rewards discount data not available");
// // // // // // //       dispatch(
// // // // // // //         updateModalType({
// // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // //           data: {
// // // // // // //             message: "Unable to load coupon information. Please try again.",
// // // // // // //           },
// // // // // // //         })
// // // // // // //       );
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     if (!myRewards?.reward) {
// // // // // // //       console.error("User rewards data not available");
// // // // // // //       dispatch(
// // // // // // //         updateModalType({
// // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // //           data: {
// // // // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // // // //           },
// // // // // // //         })
// // // // // // //       );
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     // Get coupon type and corresponding points
// // // // // // //     const type = data?.couponType;
// // // // // // //     let points;

// // // // // // //     if (type === "monthly") {
// // // // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // // // //     } else if (type === "yearly") {
// // // // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // // // //     } else {
// // // // // // //       console.error("Invalid coupon type:", type);
// // // // // // //       dispatch(
// // // // // // //         updateModalType({
// // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // //           data: {
// // // // // // //             message: "Please select a valid coupon type.",
// // // // // // //           },
// // // // // // //         })
// // // // // // //       );
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     // Verify user has enough points
// // // // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // // // //     if (currentPoints < points) {
// // // // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // // // //       dispatch(
// // // // // // //         updateModalType({
// // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // //           data: {
// // // // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // // // //           },
// // // // // // //         })
// // // // // // //       );
// // // // // // //       return;
// // // // // // //     }

// // // // // // //     setIsRedeeming(true);

// // // // // // //     try {
// // // // // // //       console.log("Calling coupon generation API...");
      
// // // // // // //       // Prepare request data
// // // // // // //       const requestData = {
// // // // // // //         type: type,
// // // // // // //         points: points.toString(),
// // // // // // //         userId: user?.user?.id.toString(),
// // // // // // //       };
      
// // // // // // //       console.log("Request payload:", requestData);

// // // // // // //       // API Call to generate coupon
// // // // // // //       const response = await fetch(
// // // // // // //         "https://referralapis.appistan.co/api/referrals/coupon/add",
// // // // // // //         {
// // // // // // //           method: "POST",
// // // // // // //           headers: {
// // // // // // //             "Content-Type": "application/json",
// // // // // // //           },
// // // // // // //           body: JSON.stringify(requestData),
// // // // // // //         }
// // // // // // //       );

// // // // // // //       console.log("Response status:", response.status);
// // // // // // //       const apiResponse = await response.json();
// // // // // // //       console.log("API Response:", apiResponse);

// // // // // // //       if ((response.ok || response.status === 201) && apiResponse.success) {
// // // // // // //         console.log("Coupon generation successful");

// // // // // // //         // Extract coupon data from response
// // // // // // //         const couponData = apiResponse.data?.coupon;
// // // // // // //         const couponCode = couponData?.coupon;

// // // // // // //         if (!couponCode) {
// // // // // // //           throw new Error("Coupon code not returned from API");
// // // // // // //         }

// // // // // // //         console.log("Generated coupon code:", couponCode);
// // // // // // //         console.log("Coupon data:", couponData);

// // // // // // //         // Reset form
// // // // // // //         reset();

// // // // // // //         // Refresh rewards data
// // // // // // //         await fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });

// // // // // // //         // Prepare success modal data
// // // // // // //         const successModalData = {
// // // // // // //           title: "🎉 Success!",
// // // // // // //           message: apiResponse.message || "Coupon generated and added successfully",
// // // // // // //           couponCode: couponCode,
// // // // // // //           coupon: couponCode,
// // // // // // //           couponType: type,
// // // // // // //           expiryDate: couponData?.expiryDate,
// // // // // // //           points: points,
// // // // // // //           actionType: "COUPON_SUCCESS",
// // // // // // //         };

// // // // // // //         console.log("Showing success modal with data:", successModalData);

// // // // // // //         // Close the form modal first
// // // // // // //         dispatch(updateModalType({ type: null }));

// // // // // // //         // Then show success message after a short delay
// // // // // // //         setTimeout(() => {
// // // // // // //           // Try multiple modal types until one works
// // // // // // //           const modalTypes = [
// // // // // // //             ModalType.SUCCESS_MODAL,
// // // // // // //             ModalType.COUPON_POINTS,
// // // // // // //             ModalType.REDEEM_SUCCESS,
// // // // // // //             "SUCCESS_MODAL",
// // // // // // //             "COUPON_SUCCESS",
// // // // // // //           ];

// // // // // // //           // Use the first one that exists
// // // // // // //           let modalTypeToUse = null;
// // // // // // //           for (const mt of modalTypes) {
// // // // // // //             if (mt && typeof mt === "string") {
// // // // // // //               modalTypeToUse = mt;
// // // // // // //               break;
// // // // // // //             }
// // // // // // //           }

// // // // // // //           console.log("Using modal type:", modalTypeToUse);

// // // // // // //           dispatch(
// // // // // // //             updateModalType({
// // // // // // //               type: modalTypeToUse || ModalType.SUCCESS_MODAL,
// // // // // // //               data: successModalData,
// // // // // // //             })
// // // // // // //           );
// // // // // // //         }, 300);

// // // // // // //       } else {
// // // // // // //         throw new Error(
// // // // // // //           apiResponse.message || "Failed to generate coupon. Please try again."
// // // // // // //         );
// // // // // // //       }
// // // // // // //     } catch (error) {
// // // // // // //       console.error("Coupon generation error:", error);

// // // // // // //       dispatch(
// // // // // // //         updateModalType({
// // // // // // //           type: ModalType.ERROR_MODAL,
// // // // // // //           data: {
// // // // // // //             message: error.message || "Failed to generate coupon. Please try again.",
// // // // // // //           },
// // // // // // //         })
// // // // // // //       );
// // // // // // //     } finally {
// // // // // // //       setIsRedeeming(false);
// // // // // // //     }
// // // // // // //   };

// // // // // // //   // Replace DB values with calculated totals
// // // // // // //   const updatedMyRewards =
// // // // // // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // // // // // //       ? {
// // // // // // //           ...myRewards,
// // // // // // //           reward: {
// // // // // // //             ...myRewards.reward,
// // // // // // //             coupons: totalCouponPoints,
// // // // // // //             redeemed: totalRedeemedPoints,
// // // // // // //           },
// // // // // // //         }
// // // // // // //       : myRewards;

// // // // // // //   return {
// // // // // // //     rewardsActions,
// // // // // // //     handleGetCouponModal,
// // // // // // //     fields: fields,
// // // // // // //     onSubmit,
// // // // // // //     control,
// // // // // // //     handleSubmit,
// // // // // // //     errors,
// // // // // // //     loading: loading || isRedeeming,
// // // // // // //     myRewards: updatedMyRewards,
// // // // // // //     isRedeeming,
// // // // // // //   };
// // // // // // // };





// // // // // import { ModalType } from "../../types/ui";
// // // // // import { useForm } from "react-hook-form";
// // // // // import { useEffect, useState } from "react";
// // // // // import { useNavigate } from "react-router-dom";
// // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // import { readMyRewardsDiscount } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // export const useMyRewards = () => {
// // // // //   const dispatch = useDispatch();
// // // // //   const navigate = useNavigate();
// // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// // // // //   const [selectedCouponType, setSelectedCouponType] = useState(null);

// // // // //   const schema = generateGetCouponValidationSchema();

// // // // //   useEffect(() => {
// // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // //   }, [dispatch, authLoading, user]);

// // // // //   useEffect(() => {
// // // // //     const fetchMyRewardsDiscount = async () => {
// // // // //       try {
// // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // //         if (response?.payload?.data) {
// // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // //         }
// // // // //       } catch (err) {
// // // // //         console.error("Error fetching rewards discount:", err);
// // // // //       }
// // // // //     };

// // // // //     fetchMyRewardsDiscount();
// // // // //   }, [dispatch]);

// // // // //   // Calculate total coupon points
// // // // //   useEffect(() => {
// // // // //     const calculateTotalCouponPoints = async () => {
// // // // //       if (authLoading || !user?.user?.id) return;

// // // // //       try {
// // // // //         let allCoupons = [];
// // // // //         let currentPage = 1;
// // // // //         let hasMore = true;

// // // // //         while (hasMore) {
// // // // //           const response = await dispatch(
// // // // //             readCouponHistory({
// // // // //               params: {
// // // // //                 uid: user.user.id,
// // // // //                 page: currentPage,
// // // // //                 size: 100,
// // // // //                 order: "desc",
// // // // //               },
// // // // //             })
// // // // //           );

// // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // //             allCoupons = [...allCoupons, ...response.payload.data];

// // // // //             const pagination = response.payload.pagination;
// // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // //             if (currentPage >= totalPages) {
// // // // //               hasMore = false;
// // // // //             } else {
// // // // //               currentPage++;
// // // // //             }
// // // // //           } else {
// // // // //             hasMore = false;
// // // // //           }
// // // // //         }

// // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // //         }, 0);

// // // // //         setTotalCouponPoints(total);
// // // // //       } catch (err) {
// // // // //         console.error("Error calculating total coupon points:", err);
// // // // //         setTotalCouponPoints(0);
// // // // //       }
// // // // //     };

// // // // //     calculateTotalCouponPoints();
// // // // //   }, [dispatch, user, authLoading]);

// // // // //   // Calculate total redeemed points
// // // // //   useEffect(() => {
// // // // //     const calculateTotalRedeemedPoints = async () => {
// // // // //       if (authLoading || !user?.user?.id) return;

// // // // //       try {
// // // // //         let allRedeems = [];
// // // // //         let currentPage = 1;
// // // // //         let hasMore = true;

// // // // //         while (hasMore) {
// // // // //           const response = await dispatch(
// // // // //             readRedeemHistory({
// // // // //               params: {
// // // // //                 uid: user.user.id,
// // // // //                 page: currentPage,
// // // // //                 size: 100,
// // // // //                 sort: "createdAt",
// // // // //                 order: "desc",
// // // // //               },
// // // // //             })
// // // // //           );

// // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // //             allRedeems = [...allRedeems, ...response.payload.data];

// // // // //             const pagination = response.payload.pagination;
// // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // //             if (currentPage >= totalPages) {
// // // // //               hasMore = false;
// // // // //             } else {
// // // // //               currentPage++;
// // // // //             }
// // // // //           } else {
// // // // //             hasMore = false;
// // // // //           }
// // // // //         }

// // // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // // //         }, 0);

// // // // //         setTotalRedeemedPoints(total);
// // // // //       } catch (err) {
// // // // //         console.error("Error calculating total redeemed points:", err);
// // // // //         setTotalRedeemedPoints(0);
// // // // //       }
// // // // //     };

// // // // //     calculateTotalRedeemedPoints();
// // // // //   }, [dispatch, user, authLoading]);

// // // // //   const handleGetCouponModal = () => {
// // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // //   };

// // // // //   const rewardsActions = [
// // // // //     {
// // // // //       icon: PointIcon,
// // // // //       text: "Points History",
// // // // //       onClick: () => navigate("/point-history"),
// // // // //     },
// // // // //     {
// // // // //       icon: GetCouponIcon,
// // // // //       text: "Get a coupon",
// // // // //       onClick: handleGetCouponModal,
// // // // //     },
// // // // //     {
// // // // //       icon: PointIcon,
// // // // //       text: "Request Redeem",
// // // // //       onClick: () => navigate("/request-redeem"),
// // // // //     },
// // // // //   ];

// // // // //   const {
// // // // //     register,
// // // // //     handleSubmit,
// // // // //     control,
// // // // //     formState: { errors },
// // // // //     reset,
// // // // //     watch,
// // // // //   } = useForm({
// // // // //     resolver: yupResolver(schema),
// // // // //   });

// // // // //   const couponTypeValue = watch("couponType");

// // // // //   // Show confirmation modal when coupon type changes
// // // // //   useEffect(() => {
// // // // //     if (couponTypeValue) {
// // // // //       setSelectedCouponType(couponTypeValue);
      
// // // // //       // Show confirmation modal
// // // // //       let points = 0;
// // // // //       if (couponTypeValue === "monthly") {
// // // // //         points = myRewardsDiscount?.referralPointsForMonthlySubscription || 0;
// // // // //       } else if (couponTypeValue === "yearly") {
// // // // //         points = myRewardsDiscount?.referralPointsForYearlySubscription || 0;
// // // // //       }

// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.COUPON_CONFIRMATION,
// // // // //           data: {
// // // // //             couponType: couponTypeValue,
// // // // //             points: points,
// // // // //             message: "Anyone can use this coupon to get a free subscription",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //     }
// // // // //   }, [couponTypeValue, myRewardsDiscount, dispatch]);

// // // // //   const fields = GetCouponFormFields(register, isRedeeming);

// // // // //   const onSubmit = async (data) => {
// // // // //     console.log("Form submitted with data:", data);

// // // // //     // Validation checks
// // // // //     if (!myRewardsDiscount) {
// // // // //       console.error("Rewards discount data not available");
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Unable to load coupon information. Please try again.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     if (!myRewards?.reward) {
// // // // //       console.error("User rewards data not available");
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     // Get coupon type and corresponding points
// // // // //     const type = data?.couponType;
// // // // //     let points;

// // // // //     if (type === "monthly") {
// // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // //     } else if (type === "yearly") {
// // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // //     } else {
// // // // //       console.error("Invalid coupon type:", type);
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Please select a valid coupon type.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     // Verify user has enough points
// // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // //     if (currentPoints < points) {
// // // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     setIsRedeeming(true);

// // // // //     try {
// // // // //       console.log("Calling coupon generation API...");
      
// // // // //       // Prepare request data
// // // // //       const requestData = {
// // // // //         type: type,
// // // // //         points: points.toString(),
// // // // //         userId: user?.user?.id.toString(),
// // // // //       };
      
// // // // //       console.log("Request payload:", requestData);

// // // // //       // API Call to generate coupon
// // // // //       const response = await fetch(
// // // // //         "https://referralapis.appistan.co/api/referrals/coupon/add",
// // // // //         {
// // // // //           method: "POST",
// // // // //           headers: {
// // // // //             "Content-Type": "application/json",
// // // // //           },
// // // // //           body: JSON.stringify(requestData),
// // // // //         }
// // // // //       );

// // // // //       console.log("Response status:", response.status);
// // // // //       const apiResponse = await response.json();
// // // // //       console.log("API Response:", apiResponse);

// // // // //       if ((response.ok || response.status === 201) && apiResponse.success) {
// // // // //         console.log("Coupon generation successful");

// // // // //         // Extract coupon data from response
// // // // //         const couponData = apiResponse.data?.coupon;
// // // // //         const couponCode = couponData?.coupon;

// // // // //         if (!couponCode) {
// // // // //           throw new Error("Coupon code not returned from API");
// // // // //         }

// // // // //         console.log("Generated coupon code:", couponCode);
// // // // //         console.log("Coupon data:", couponData);

// // // // //         // Reset form
// // // // //         reset();
// // // // //         setSelectedCouponType(null);

// // // // //         // Close the form modal first
// // // // //         dispatch(updateModalType({ type: null }));

// // // // //         // Then show success message using COUPON_POINTS modal
// // // // //         // (which is mapped to RedeemPointsModal in your modal manager)
// // // // //         setTimeout(() => {
// // // // //           console.log("Showing COUPON_POINTS success modal...");
          
// // // // //           // Prepare data for the modal
// // // // //           const successData = {
// // // // //             message: apiResponse.message || "Coupon generated and added successfully",
// // // // //             couponCode: couponCode,
// // // // //             coupon: couponCode,
// // // // //             couponType: type,
// // // // //             expiryDate: couponData?.expiryDate,
// // // // //             points: points,
// // // // //             status: couponData?.status,
// // // // //             actionType: "COUPON_SUCCESS",
// // // // //           };

// // // // //           console.log("Success modal data:", successData);

// // // // //           dispatch(
// // // // //             updateModalType({
// // // // //               type: ModalType.COUPON_POINTS,  // This maps to RedeemPointsModal
// // // // //               data: successData,
// // // // //             })
// // // // //           );
// // // // //         }, 300);

// // // // //       } else {
// // // // //         throw new Error(
// // // // //           apiResponse.message || "Failed to generate coupon. Please try again."
// // // // //         );
// // // // //       }
// // // // //     } catch (error) {
// // // // //       console.error("Coupon generation error:", error);

// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: error.message || "Failed to generate coupon. Please try again.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //     } finally {
// // // // //       setIsRedeeming(false);
// // // // //     }
// // // // //   };

// // // // //   // Replace DB values with calculated totals
// // // // //   const updatedMyRewards =
// // // // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // // // //       ? {
// // // // //           ...myRewards,
// // // // //           reward: {
// // // // //             ...myRewards.reward,
// // // // //             coupons: totalCouponPoints,
// // // // //             redeemed: totalRedeemedPoints,
// // // // //           },
// // // // //         }
// // // // //       : myRewards;

// // // // //   return {
// // // // //     rewardsActions,
// // // // //     handleGetCouponModal,
// // // // //     fields: fields,
// // // // //     onSubmit,
// // // // //     control,
// // // // //     handleSubmit,
// // // // //     errors,
// // // // //     loading: loading || isRedeeming,
// // // // //     myRewards: updatedMyRewards,
// // // // //     isRedeeming,
// // // // //   };
// // // // // };



// // // // // import { ModalType } from "../../types/ui";
// // // // // import { useForm } from "react-hook-form";
// // // // // import { useEffect, useState } from "react";
// // // // // import { useNavigate } from "react-router-dom";
// // // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // // import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// // // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // // export const useMyRewards = () => {
// // // // //   const dispatch = useDispatch();
// // // // //   const navigate = useNavigate();
// // // // //   const [myRewards, setMyRewards] = useState(null);
// // // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // // //   const { loading } = useSelector((state) => state.myRewards);
// // // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// // // // //   const [selectedCouponType, setSelectedCouponType] = useState(null);

// // // // //   const schema = generateGetCouponValidationSchema();

// // // // //   useEffect(() => {
// // // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // // //   }, [dispatch, authLoading, user]);

// // // // //   useEffect(() => {
// // // // //     const fetchMyRewardsDiscount = async () => {
// // // // //       try {
// // // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // // //         if (response?.payload?.data) {
// // // // //           setMyRewardsDiscount(response?.payload?.data);
// // // // //         }
// // // // //       } catch (err) {
// // // // //         console.error("Error fetching rewards discount:", err);
// // // // //       }
// // // // //     };

// // // // //     fetchMyRewardsDiscount();
// // // // //   }, [dispatch]);

// // // // //   useEffect(() => {
// // // // //     const calculateTotalCouponPoints = async () => {
// // // // //       if (authLoading || !user?.user?.id) return;

// // // // //       try {
// // // // //         let allCoupons = [];
// // // // //         let currentPage = 1;
// // // // //         let hasMore = true;

// // // // //         while (hasMore) {
// // // // //           const response = await dispatch(
// // // // //             readCouponHistory({
// // // // //               params: {
// // // // //                 uid: user.user.id,
// // // // //                 page: currentPage,
// // // // //                 size: 100,
// // // // //                 order: "desc",
// // // // //               },
// // // // //             })
// // // // //           );

// // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // //             allCoupons = [...allCoupons, ...response.payload.data];

// // // // //             const pagination = response.payload.pagination;
// // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // //             if (currentPage >= totalPages) {
// // // // //               hasMore = false;
// // // // //             } else {
// // // // //               currentPage++;
// // // // //             }
// // // // //           } else {
// // // // //             hasMore = false;
// // // // //           }
// // // // //         }

// // // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // // //         }, 0);

// // // // //         setTotalCouponPoints(total);
// // // // //       } catch (err) {
// // // // //         console.error("Error calculating total coupon points:", err);
// // // // //         setTotalCouponPoints(0);
// // // // //       }
// // // // //     };

// // // // //     calculateTotalCouponPoints();
// // // // //   }, [dispatch, user, authLoading]);

// // // // //   useEffect(() => {
// // // // //     const calculateTotalRedeemedPoints = async () => {
// // // // //       if (authLoading || !user?.user?.id) return;

// // // // //       try {
// // // // //         let allRedeems = [];
// // // // //         let currentPage = 1;
// // // // //         let hasMore = true;

// // // // //         while (hasMore) {
// // // // //           const response = await dispatch(
// // // // //             readRedeemHistory({
// // // // //               params: {
// // // // //                 uid: user.user.id,
// // // // //                 page: currentPage,
// // // // //                 size: 100,
// // // // //                 sort: "createdAt",
// // // // //                 order: "desc",
// // // // //               },
// // // // //             })
// // // // //           );

// // // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // // //             allRedeems = [...allRedeems, ...response.payload.data];

// // // // //             const pagination = response.payload.pagination;
// // // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // // //             if (currentPage >= totalPages) {
// // // // //               hasMore = false;
// // // // //             } else {
// // // // //               currentPage++;
// // // // //             }
// // // // //           } else {
// // // // //             hasMore = false;
// // // // //           }
// // // // //         }

// // // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // // //         }, 0);

// // // // //         setTotalRedeemedPoints(total);
// // // // //       } catch (err) {
// // // // //         console.error("Error calculating total redeemed points:", err);
// // // // //         setTotalRedeemedPoints(0);
// // // // //       }
// // // // //     };

// // // // //     calculateTotalRedeemedPoints();
// // // // //   }, [dispatch, user, authLoading]);

// // // // //   const handleGetCouponModal = () => {
// // // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // // //   };

// // // // //   const rewardsActions = [
// // // // //     {
// // // // //       icon: PointIcon,
// // // // //       text: "Points History",
// // // // //       onClick: () => navigate("/point-history"),
// // // // //     },
// // // // //     {
// // // // //       icon: GetCouponIcon,
// // // // //       text: "Get a coupon",
// // // // //       onClick: handleGetCouponModal,
// // // // //     },
// // // // //     {
// // // // //       icon: PointIcon,
// // // // //       text: "Request Redeem",
// // // // //       onClick: () => navigate("/request-redeem"),
// // // // //     },
// // // // //   ];

// // // // //   const {
// // // // //     register,
// // // // //     handleSubmit,
// // // // //     control,
// // // // //     formState: { errors },
// // // // //     reset,
// // // // //     watch,
// // // // //   } = useForm({
// // // // //     resolver: yupResolver(schema),
// // // // //   });

// // // // //   const couponTypeValue = watch("couponType");

// // // // //   useEffect(() => {
// // // // //     if (couponTypeValue) {
// // // // //       setSelectedCouponType(couponTypeValue);
      
// // // // //       let points = 0;
// // // // //       if (couponTypeValue === "monthly") {
// // // // //         points = myRewardsDiscount?.referralPointsForMonthlySubscription || 0;
// // // // //       } else if (couponTypeValue === "yearly") {
// // // // //         points = myRewardsDiscount?.referralPointsForYearlySubscription || 0;
// // // // //       }

// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.COUPON_CONFIRMATION,
// // // // //           data: {
// // // // //             couponType: couponTypeValue,
// // // // //             points: points,
// // // // //             message: "Anyone can use this coupon to get a free subscription",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //     }
// // // // //   }, [couponTypeValue, myRewardsDiscount, dispatch]);

// // // // //   const fields = GetCouponFormFields(register, isRedeeming);

// // // // //   const onSubmit = async (data) => {
// // // // //     console.log("Form submitted with data:", data);

// // // // //     if (!myRewardsDiscount) {
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Unable to load coupon information. Please try again.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     if (!myRewards?.reward) {
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     const type = data?.couponType;
// // // // //     let points;

// // // // //     if (type === "monthly") {
// // // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // // //     } else if (type === "yearly") {
// // // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // // //     } else {
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: "Please select a valid coupon type.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // // //     if (currentPoints < points) {
// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //       return;
// // // // //     }

// // // // //     setIsRedeeming(true);

// // // // //     try {
// // // // //       console.log("Calling createCoupon thunk...");
      
// // // // //       const requestData = {
// // // // //         type: type,
// // // // //         points: points,
// // // // //         userId: user?.user?.id,
// // // // //       };
      
// // // // //       console.log("Request payload:", requestData);

// // // // //       // Call your existing createCoupon thunk from request handler
// // // // //       const response = await dispatch(
// // // // //         createCoupon({
// // // // //           data: requestData,
// // // // //           setError: () => {},
// // // // //         })
// // // // //       );

// // // // //       console.log("Coupon response:", response);

// // // // //       if (response?.payload?.data) {
// // // // //         console.log("Coupon generation successful");

// // // // //         const couponData = response?.payload?.data?.coupon;
// // // // //         const couponCode = couponData?.coupon;

// // // // //         if (!couponCode) {
// // // // //           throw new Error("Coupon code not returned");
// // // // //         }

// // // // //         console.log("Generated coupon code:", couponCode);

// // // // //         reset();
// // // // //         setSelectedCouponType(null);

// // // // //         dispatch(updateModalType({ type: null }));

// // // // //         setTimeout(() => {
// // // // //           console.log("Showing success modal...");
          
// // // // //           const successData = {
// // // // //             message: response?.payload?.message || "Coupon generated and added successfully",
// // // // //             couponCode: couponCode,
// // // // //             coupon: couponCode,
// // // // //             couponType: type,
// // // // //             expiryDate: couponData?.expiryDate,
// // // // //             points: points,
// // // // //             status: couponData?.status,
// // // // //             actionType: "COUPON_SUCCESS",
// // // // //           };

// // // // //           console.log("Success modal data:", successData);

// // // // //           dispatch(
// // // // //             updateModalType({
// // // // //               type: ModalType.COUPON_POINTS,
// // // // //               data: successData,
// // // // //             })
// // // // //           );
// // // // //         }, 300);

// // // // //       } else {
// // // // //         const errorMessage = response?.payload?.message || "Failed to generate coupon. Please try again.";
// // // // //         throw new Error(errorMessage);
// // // // //       }
// // // // //     } catch (error) {
// // // // //       console.error("Error:", error);

// // // // //       dispatch(
// // // // //         updateModalType({
// // // // //           type: ModalType.ERROR_MODAL,
// // // // //           data: {
// // // // //             message: error.message || "Failed to generate coupon. Please try again.",
// // // // //           },
// // // // //         })
// // // // //       );
// // // // //     } finally {
// // // // //       setIsRedeeming(false);
// // // // //     }
// // // // //   };

// // // // //   const updatedMyRewards =
// // // // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // // // //       ? {
// // // // //           ...myRewards,
// // // // //           reward: {
// // // // //             ...myRewards.reward,
// // // // //             coupons: totalCouponPoints,
// // // // //             redeemed: totalRedeemedPoints,
// // // // //           },
// // // // //         }
// // // // //       : myRewards;

// // // // //   return {
// // // // //     rewardsActions,
// // // // //     handleGetCouponModal,
// // // // //     fields: fields,
// // // // //     onSubmit,
// // // // //     control,
// // // // //     handleSubmit,
// // // // //     errors,
// // // // //     loading: loading || isRedeeming,
// // // // //     myRewards: updatedMyRewards,
// // // // //     isRedeeming,
// // // // //   };
// // // // // };\








// // // // import { ModalType } from "../../types/ui";
// // // // import { useForm } from "react-hook-form";
// // // // import { useEffect, useState } from "react";
// // // // import { useNavigate } from "react-router-dom";
// // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // import { useDispatch, useSelector } from "react-redux";
// // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // export const useMyRewards = () => {
// // // //   const dispatch = useDispatch();
// // // //   const navigate = useNavigate();
// // // //   const [myRewards, setMyRewards] = useState(null);
// // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // //   const { loading } = useSelector((state) => state.myRewards);
// // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // //   const schema = generateGetCouponValidationSchema();

// // // //   useEffect(() => {
// // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // //   }, [dispatch, authLoading, user]);

// // // //   useEffect(() => {
// // // //     const fetchMyRewardsDiscount = async () => {
// // // //       try {
// // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // //         if (response?.payload?.data) {
// // // //           setMyRewardsDiscount(response?.payload?.data);
// // // //         }
// // // //       } catch (err) {
// // // //         console.error("Error fetching rewards discount:", err);
// // // //       }
// // // //     };

// // // //     fetchMyRewardsDiscount();
// // // //   }, [dispatch]);

// // // //   // Calculate total coupon points
// // // //   useEffect(() => {
// // // //     const calculateTotalCouponPoints = async () => {
// // // //       if (authLoading || !user?.user?.id) return;

// // // //       try {
// // // //         let allCoupons = [];
// // // //         let currentPage = 1;
// // // //         let hasMore = true;

// // // //         while (hasMore) {
// // // //           const response = await dispatch(
// // // //             readCouponHistory({
// // // //               params: {
// // // //                 uid: user.user.id,
// // // //                 page: currentPage,
// // // //                 size: 100,
// // // //                 order: "desc",
// // // //               },
// // // //             })
// // // //           );

// // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // //             allCoupons = [...allCoupons, ...response.payload.data];

// // // //             const pagination = response.payload.pagination;
// // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // //             if (currentPage >= totalPages) {
// // // //               hasMore = false;
// // // //             } else {
// // // //               currentPage++;
// // // //             }
// // // //           } else {
// // // //             hasMore = false;
// // // //           }
// // // //         }

// // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // //         }, 0);

// // // //         setTotalCouponPoints(total);
// // // //       } catch (err) {
// // // //         console.error("Error calculating total coupon points:", err);
// // // //         setTotalCouponPoints(0);
// // // //       }
// // // //     };

// // // //     calculateTotalCouponPoints();
// // // //   }, [dispatch, user, authLoading]);

// // // //   // Calculate total redeemed points
// // // //   useEffect(() => {
// // // //     const calculateTotalRedeemedPoints = async () => {
// // // //       if (authLoading || !user?.user?.id) return;

// // // //       try {
// // // //         let allRedeems = [];
// // // //         let currentPage = 1;
// // // //         let hasMore = true;

// // // //         while (hasMore) {
// // // //           const response = await dispatch(
// // // //             readRedeemHistory({
// // // //               params: {
// // // //                 uid: user.user.id,
// // // //                 page: currentPage,
// // // //                 size: 100,
// // // //                 sort: "createdAt",
// // // //                 order: "desc",
// // // //               },
// // // //             })
// // // //           );

// // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // //             allRedeems = [...allRedeems, ...response.payload.data];

// // // //             const pagination = response.payload.pagination;
// // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // //             if (currentPage >= totalPages) {
// // // //               hasMore = false;
// // // //             } else {
// // // //               currentPage++;
// // // //             }
// // // //           } else {
// // // //             hasMore = false;
// // // //           }
// // // //         }

// // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // //         }, 0);

// // // //         setTotalRedeemedPoints(total);
// // // //       } catch (err) {
// // // //         console.error("Error calculating total redeemed points:", err);
// // // //         setTotalRedeemedPoints(0);
// // // //       }
// // // //     };

// // // //     calculateTotalRedeemedPoints();
// // // //   }, [dispatch, user, authLoading]);

// // // //   const handleGetCouponModal = () => {
// // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // //   };

// // // //   const rewardsActions = [
// // // //     {
// // // //       icon: PointIcon,
// // // //       text: "Points History",
// // // //       onClick: () => navigate("/point-history"),
// // // //     },
// // // //     {
// // // //       icon: GetCouponIcon,
// // // //       text: "Get a coupon",
// // // //       onClick: handleGetCouponModal,
// // // //     },
// // // //     {
// // // //       icon: PointIcon,
// // // //       text: "Request Redeem",
// // // //       onClick: () => navigate("/request-redeem"),
// // // //     },
// // // //   ];

// // // //   const {
// // // //     register,
// // // //     handleSubmit,
// // // //     control,
// // // //     formState: { errors },
// // // //     reset,
// // // //   } = useForm({
// // // //     resolver: yupResolver(schema),
// // // //   });

// // // //   const fields = GetCouponFormFields(register, isRedeeming);

// // // //   const onSubmit = async (data) => {
// // // //     console.log("Form submitted with data:", data);

// // // //     // Validation checks
// // // //     if (!myRewardsDiscount) {
// // // //       console.error("Rewards discount data not available");
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Unable to load coupon information. Please try again.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     if (!myRewards?.reward) {
// // // //       console.error("User rewards data not available");
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     // Get coupon type and corresponding points
// // // //     const type = data?.couponType;
// // // //     let points;

// // // //     if (type === "monthly") {
// // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // //     } else if (type === "yearly") {
// // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // //     } else {
// // // //       console.error("Invalid coupon type:", type);
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Please select a valid coupon type.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     // Verify user has enough points
// // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // //     if (currentPoints < points) {
// // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     setIsRedeeming(true);

// // // //     try {
// // // //       console.log("Calling createCoupon thunk...");
      
// // // //       // Prepare request data
// // // //       const requestData = {
// // // //         type: type,
// // // //         points: points,
// // // //         userId: user?.user?.id,
// // // //       };
      
// // // //       console.log("Request payload:", requestData);

// // // //       // Call your existing createCoupon thunk
// // // //       const response = await dispatch(
// // // //         createCoupon({
// // // //           data: requestData,
// // // //           setError: () => {},
// // // //         })
// // // //       );

// // // //       console.log("Coupon thunk response:", response);

// // // //       if (response?.payload?.data) {
// // // //         console.log("Coupon generation successful");

// // // //         // Extract coupon data from response
// // // //         const couponData = response?.payload?.data?.coupon;
// // // //         const couponCode = couponData?.coupon;

// // // //         if (!couponCode) {
// // // //           throw new Error("Coupon code not returned from API");
// // // //         }

// // // //         console.log("Generated coupon code:", couponCode);
// // // //         console.log("Coupon data:", couponData);

// // // //         // Reset form
// // // //         reset();

// // // //         // Close the form modal - use NONE instead of null
// // // //         dispatch(updateModalType({ type: ModalType.NONE }));

// // // //         // Show success message using REDEEM_SUCCESS modal
// // // //         setTimeout(() => {
// // // //           console.log("Showing success message with REDEEM_SUCCESS modal...");
          
// // // //           dispatch(
// // // //             updateModalType({
// // // //               type: ModalType.REDEEM_SUCCESS,
// // // //               data: {
// // // //                 actionType: "COUPON_SUCCESS",
// // // //                 title: "Coupon Generated!",
// // // //                 message: "Coupon generated and added successfully",
// // // //                 couponCode: couponCode,
// // // //                 coupon: couponCode,
// // // //                 couponType: type,
// // // //                 expiryDate: couponData?.expiryDate,
// // // //                 points: points,
// // // //                 status: couponData?.status,
// // // //               },
// // // //             })
// // // //           );
// // // //         }, 200);

// // // //         // Refresh rewards data in the background
// // // //         setTimeout(() => {
// // // //           fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // //         }, 2000);

// // // //       } else {
// // // //         const errorMessage = response?.payload?.message || "Failed to generate coupon. Please try again.";
// // // //         throw new Error(errorMessage);
// // // //       }
// // // //     } catch (error) {
// // // //       console.error("Coupon generation error:", error);

// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: error.message || "Failed to generate coupon. Please try again.",
// // // //           },
// // // //         })
// // // //       );
// // // //     } finally {
// // // //       setIsRedeeming(false);
// // // //     }
// // // //   };

// // // //   // Replace DB values with calculated totals
// // // //   const updatedMyRewards =
// // // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // // //       ? {
// // // //           ...myRewards,
// // // //           reward: {
// // // //             ...myRewards.reward,
// // // //             coupons: totalCouponPoints,
// // // //             redeemed: totalRedeemedPoints,
// // // //           },
// // // //         }
// // // //       : myRewards;

// // // //   return {
// // // //     rewardsActions,
// // // //     handleGetCouponModal,
// // // //     fields: fields,
// // // //     onSubmit,
// // // //     control,
// // // //     handleSubmit,
// // // //     errors,
// // // //     loading: loading || isRedeeming,
// // // //     myRewards: updatedMyRewards,
// // // //     isRedeeming,
// // // //   };
// // // // };














// // // // import { ModalType } from "../../types/ui";
// // // // import { useForm } from "react-hook-form";
// // // // import { useEffect, useState } from "react";
// // // // import { useNavigate } from "react-router-dom";
// // // // import { yupResolver } from "@hookform/resolvers/yup";
// // // // import { useDispatch, useSelector } from "react-redux";
// // // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // // import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// // // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // // export const useMyRewards = () => {
// // // //   const dispatch = useDispatch();
// // // //   const navigate = useNavigate();
// // // //   const [myRewards, setMyRewards] = useState(null);
// // // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // // //   const { loading } = useSelector((state) => state.myRewards);
// // // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // // //   const schema = generateGetCouponValidationSchema();

// // // //   useEffect(() => {
// // // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // //   }, [dispatch, authLoading, user]);

// // // //   useEffect(() => {
// // // //     const fetchMyRewardsDiscount = async () => {
// // // //       try {
// // // //         const response = await dispatch(readMyRewardsDiscount({}));
// // // //         if (response?.payload?.data) {
// // // //           setMyRewardsDiscount(response?.payload?.data);
// // // //         }
// // // //       } catch (err) {
// // // //         console.error("Error fetching rewards discount:", err);
// // // //       }
// // // //     };

// // // //     fetchMyRewardsDiscount();
// // // //   }, [dispatch]);

// // // //   // Calculate total coupon points
// // // //   useEffect(() => {
// // // //     const calculateTotalCouponPoints = async () => {
// // // //       if (authLoading || !user?.user?.id) return;

// // // //       try {
// // // //         let allCoupons = [];
// // // //         let currentPage = 1;
// // // //         let hasMore = true;

// // // //         while (hasMore) {
// // // //           const response = await dispatch(
// // // //             readCouponHistory({
// // // //               params: {
// // // //                 uid: user.user.id,
// // // //                 page: currentPage,
// // // //                 size: 100,
// // // //                 order: "desc",
// // // //               },
// // // //             })
// // // //           );

// // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // //             allCoupons = [...allCoupons, ...response.payload.data];

// // // //             const pagination = response.payload.pagination;
// // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // //             if (currentPage >= totalPages) {
// // // //               hasMore = false;
// // // //             } else {
// // // //               currentPage++;
// // // //             }
// // // //           } else {
// // // //             hasMore = false;
// // // //           }
// // // //         }

// // // //         const total = allCoupons.reduce((sum, coupon) => {
// // // //           return sum + (parseInt(coupon.points, 10) || 0);
// // // //         }, 0);

// // // //         setTotalCouponPoints(total);
// // // //       } catch (err) {
// // // //         console.error("Error calculating total coupon points:", err);
// // // //         setTotalCouponPoints(0);
// // // //       }
// // // //     };

// // // //     calculateTotalCouponPoints();
// // // //   }, [dispatch, user, authLoading]);

// // // //   // Calculate total redeemed points
// // // //   useEffect(() => {
// // // //     const calculateTotalRedeemedPoints = async () => {
// // // //       if (authLoading || !user?.user?.id) return;

// // // //       try {
// // // //         let allRedeems = [];
// // // //         let currentPage = 1;
// // // //         let hasMore = true;

// // // //         while (hasMore) {
// // // //           const response = await dispatch(
// // // //             readRedeemHistory({
// // // //               params: {
// // // //                 uid: user.user.id,
// // // //                 page: currentPage,
// // // //                 size: 100,
// // // //                 sort: "createdAt",
// // // //                 order: "desc",
// // // //               },
// // // //             })
// // // //           );

// // // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // // //             allRedeems = [...allRedeems, ...response.payload.data];

// // // //             const pagination = response.payload.pagination;
// // // //             const totalPages = Math.ceil(pagination.total / 100);

// // // //             if (currentPage >= totalPages) {
// // // //               hasMore = false;
// // // //             } else {
// // // //               currentPage++;
// // // //             }
// // // //           } else {
// // // //             hasMore = false;
// // // //           }
// // // //         }

// // // //         const total = allRedeems.reduce((sum, redeem) => {
// // // //           return sum + (parseInt(redeem.points, 10) || 0);
// // // //         }, 0);

// // // //         setTotalRedeemedPoints(total);
// // // //       } catch (err) {
// // // //         console.error("Error calculating total redeemed points:", err);
// // // //         setTotalRedeemedPoints(0);
// // // //       }
// // // //     };

// // // //     calculateTotalRedeemedPoints();
// // // //   }, [dispatch, user, authLoading]);

// // // //   const handleGetCouponModal = () => {
// // // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // // //   };

// // // //   const rewardsActions = [
// // // //     {
// // // //       icon: PointIcon,
// // // //       text: "Points History",
// // // //       onClick: () => navigate("/point-history"),
// // // //     },
// // // //     {
// // // //       icon: GetCouponIcon,
// // // //       text: "Get a coupon",
// // // //       onClick: handleGetCouponModal,
// // // //     },
// // // //     {
// // // //       icon: PointIcon,
// // // //       text: "Request Redeem",
// // // //       onClick: () => navigate("/request-redeem"),
// // // //     },
// // // //   ];

// // // //   const {
// // // //     register,
// // // //     handleSubmit,
// // // //     control,
// // // //     formState: { errors },
// // // //     reset,
// // // //   } = useForm({
// // // //     resolver: yupResolver(schema),
// // // //   });

// // // //   const fields = GetCouponFormFields(register, isRedeeming);

// // // //   const onSubmit = async (data) => {
// // // //     console.log("Form submitted with data:", data);

// // // //     if (!myRewardsDiscount) {
// // // //       console.error("Rewards discount data not available");
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Unable to load coupon information. Please try again.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     if (!myRewards?.reward) {
// // // //       console.error("User rewards data not available");
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Unable to load your rewards. Please refresh the page.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     const type = data?.couponType;
// // // //     let points;

// // // //     if (type === "monthly") {
// // // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // // //     } else if (type === "yearly") {
// // // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // // //     } else {
// // // //       console.error("Invalid coupon type:", type);
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: "Please select a valid coupon type.",
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     const currentPoints = myRewards?.reward?.active || 0;
// // // //     if (currentPoints < points) {
// // // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // // //           },
// // // //         })
// // // //       );
// // // //       return;
// // // //     }

// // // //     setIsRedeeming(true);

// // // //     try {
// // // //       console.log("Calling createCoupon thunk...");

// // // //       const requestData = {
// // // //         type: type,
// // // //         points: points,
// // // //         userId: user?.user?.id,
// // // //       };

// // // //       console.log("Request payload:", requestData);

// // // //       const response = await dispatch(
// // // //         createCoupon({
// // // //           data: requestData,
// // // //           setError: () => {},
// // // //         })
// // // //       );

// // // //       console.log("Coupon thunk response:", response);

// // // //       if (response?.payload?.data) {
// // // //         console.log("Coupon generation successful");

// // // //         const couponData = response?.payload?.data?.coupon;
// // // //         const couponCode = couponData?.coupon;

// // // //         if (!couponCode) {
// // // //           throw new Error("Coupon code not returned from API");
// // // //         }

// // // //         console.log("Generated coupon code:", couponCode);
// // // //         console.log("Coupon data:", couponData);

// // // //         reset();

// // // //         dispatch(updateModalType({ type: ModalType.NONE }));

// // // //         setTimeout(() => {
// // // //           console.log("Showing success message with REDEEM_SUCCESS modal...");

// // // //           dispatch(
// // // //             updateModalType({
// // // //               type: ModalType.REDEEM_SUCCESS,
// // // //               data: {
// // // //                 actionType: "COUPON_SUCCESS",
// // // //                 title: "Coupon Generated!",
// // // //                 message: "Coupon generated and added successfully",
// // // //                 couponCode: couponCode,
// // // //                 coupon: couponCode,
// // // //                 couponType: type,
// // // //                 expiryDate: couponData?.expiryDate,
// // // //                 points: points,
// // // //                 status: couponData?.status,
// // // //               },
// // // //             })
// // // //           );
// // // //         }, 200);

// // // //         // Refresh rewards data in the background
// // // //         setTimeout(() => {
// // // //           fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // // //         }, 2000);

// // // //       } else {
// // // //         const errorMessage =
// // // //           response?.payload?.message || "Failed to generate coupon. Please try again.";
// // // //         throw new Error(errorMessage);
// // // //       }
// // // //     } catch (error) {
// // // //       console.error("Coupon generation error:", error);

// // // //       dispatch(
// // // //         updateModalType({
// // // //           type: ModalType.ERROR_MODAL,
// // // //           data: {
// // // //             message: error.message || "Failed to generate coupon. Please try again.",
// // // //           },
// // // //         })
// // // //       );
// // // //     } finally {
// // // //       setIsRedeeming(false);
// // // //     }
// // // //   };

// // // //   // ✅ Total Points Earned = active (balance) + redeemed + coupon points
// // // //   // This avoids the DB overflow bug (2147483647) on the `total` field
// // // //   const activePoints = myRewards?.reward?.active || 0;
// // // //   const calculatedTotalEarned =
// // // //     totalCouponPoints !== null && totalRedeemedPoints !== null
// // // //       ? activePoints + totalRedeemedPoints + totalCouponPoints
// // // //       : null;

// // // //   // Replace DB values with calculated totals
// // // //   const updatedMyRewards =
// // // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // // //       ? {
// // // //           ...myRewards,
// // // //           reward: {
// // // //             ...myRewards.reward,
// // // //             total: calculatedTotalEarned,   // ✅ active + redeemed + coupons (no new API needed)
// // // //             coupons: totalCouponPoints,
// // // //             redeemed: totalRedeemedPoints,
// // // //           },
// // // //         }
// // // //       : myRewards;

// // // //   return {
// // // //     rewardsActions,
// // // //     handleGetCouponModal,
// // // //     fields: fields,
// // // //     onSubmit,
// // // //     control,
// // // //     handleSubmit,
// // // //     errors,
// // // //     loading: loading || isRedeeming,
// // // //     myRewards: updatedMyRewards,
// // // //     isRedeeming,
// // // //   };
// // // // };




// // // import { ModalType } from "../../types/ui";
// // // import { useForm } from "react-hook-form";
// // // import { useEffect, useState, useCallback } from "react";
// // // import { useNavigate } from "react-router-dom";
// // // import { yupResolver } from "@hookform/resolvers/yup";
// // // import { useDispatch, useSelector } from "react-redux";
// // // import { fetchMyRewardsUtil } from "../../utils/utility";
// // // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // // import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// // // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // // export const useMyRewards = () => {
// // //   const dispatch = useDispatch();
// // //   const navigate = useNavigate();
// // //   const [myRewards, setMyRewards] = useState(null);
// // //   const [isRedeeming, setIsRedeeming] = useState(false);
// // //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// // //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// // //   const { loading } = useSelector((state) => state.myRewards);
// // //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // //   const schema = generateGetCouponValidationSchema();

// // //   useEffect(() => {
// // //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // //   }, [dispatch, authLoading, user]);

// // //   useEffect(() => {
// // //     const fetchMyRewardsDiscount = async () => {
// // //       try {
// // //         const response = await dispatch(readMyRewardsDiscount({}));
// // //         if (response?.payload?.data) {
// // //           setMyRewardsDiscount(response?.payload?.data);
// // //         }
// // //       } catch (err) {
// // //         console.error("Error fetching rewards discount:", err);
// // //       }
// // //     };
// // //     fetchMyRewardsDiscount();
// // //   }, [dispatch]);

// // //   // ✅ Extracted to useCallback so it can be called on mount AND after coupon creation
// // //   const calculateTotalCouponPoints = useCallback(async () => {
// // //     if (authLoading || !user?.user?.id) return;

// // //     try {
// // //       let allCoupons = [];
// // //       let currentPage = 1;
// // //       let hasMore = true;

// // //       while (hasMore) {
// // //         const response = await dispatch(
// // //           readCouponHistory({
// // //             params: {
// // //               uid: user.user.id,
// // //               page: currentPage,
// // //               size: 100,
// // //               order: "desc",
// // //             },
// // //           })
// // //         );

// // //         if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // //           allCoupons = [...allCoupons, ...response.payload.data];
// // //           const pagination = response.payload.pagination;
// // //           const totalPages = Math.ceil(pagination.total / 100);
// // //           if (currentPage >= totalPages) {
// // //             hasMore = false;
// // //           } else {
// // //             currentPage++;
// // //           }
// // //         } else {
// // //           hasMore = false;
// // //         }
// // //       }

// // //       const total = allCoupons.reduce((sum, coupon) => {
// // //         return sum + (parseInt(coupon.points, 10) || 0);
// // //       }, 0);

// // //       setTotalCouponPoints(total);
// // //     } catch (err) {
// // //       console.error("Error calculating total coupon points:", err);
// // //       setTotalCouponPoints(0);
// // //     }
// // //   }, [dispatch, user, authLoading]);

// // //   // Calculate total coupon points on mount
// // //   useEffect(() => {
// // //     calculateTotalCouponPoints();
// // //   }, [calculateTotalCouponPoints]);

// // //   // Calculate total redeemed points
// // //   useEffect(() => {
// // //     const calculateTotalRedeemedPoints = async () => {
// // //       if (authLoading || !user?.user?.id) return;

// // //       try {
// // //         let allRedeems = [];
// // //         let currentPage = 1;
// // //         let hasMore = true;

// // //         while (hasMore) {
// // //           const response = await dispatch(
// // //             readRedeemHistory({
// // //               params: {
// // //                 uid: user.user.id,
// // //                 page: currentPage,
// // //                 size: 100,
// // //                 sort: "createdAt",
// // //                 order: "desc",
// // //               },
// // //             })
// // //           );

// // //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// // //             allRedeems = [...allRedeems, ...response.payload.data];
// // //             const pagination = response.payload.pagination;
// // //             const totalPages = Math.ceil(pagination.total / 100);
// // //             if (currentPage >= totalPages) {
// // //               hasMore = false;
// // //             } else {
// // //               currentPage++;
// // //             }
// // //           } else {
// // //             hasMore = false;
// // //           }
// // //         }

// // //         const total = allRedeems.reduce((sum, redeem) => {
// // //           return sum + (parseInt(redeem.points, 10) || 0);
// // //         }, 0);

// // //         setTotalRedeemedPoints(total);
// // //       } catch (err) {
// // //         console.error("Error calculating total redeemed points:", err);
// // //         setTotalRedeemedPoints(0);
// // //       }
// // //     };

// // //     calculateTotalRedeemedPoints();
// // //   }, [dispatch, user, authLoading]);

// // //   const handleGetCouponModal = () => {
// // //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// // //   };

// // //   const rewardsActions = [
// // //     {
// // //       icon: PointIcon,
// // //       text: "Points History",
// // //       onClick: () => navigate("/point-history"),
// // //     },
// // //     {
// // //       icon: GetCouponIcon,
// // //       text: "Get a coupon",
// // //       onClick: handleGetCouponModal,
// // //     },
// // //     {
// // //       icon: PointIcon,
// // //       text: "Request Redeem",
// // //       onClick: () => navigate("/request-redeem"),
// // //     },
// // //   ];

// // //   const {
// // //     register,
// // //     handleSubmit,
// // //     control,
// // //     formState: { errors },
// // //     reset,
// // //   } = useForm({
// // //     resolver: yupResolver(schema),
// // //   });

// // //   const fields = GetCouponFormFields(register, isRedeeming);

// // //   const onSubmit = async (data) => {
// // //     console.log("Form submitted with data:", data);

// // //     if (!myRewardsDiscount) {
// // //       console.error("Rewards discount data not available");
// // //       dispatch(
// // //         updateModalType({
// // //           type: ModalType.ERROR_MODAL,
// // //           data: {
// // //             message: "Unable to load coupon information. Please try again.",
// // //           },
// // //         })
// // //       );
// // //       return;
// // //     }

// // //     if (!myRewards?.reward) {
// // //       console.error("User rewards data not available");
// // //       dispatch(
// // //         updateModalType({
// // //           type: ModalType.ERROR_MODAL,
// // //           data: {
// // //             message: "Unable to load your rewards. Please refresh the page.",
// // //           },
// // //         })
// // //       );
// // //       return;
// // //     }

// // //     const type = data?.couponType;
// // //     let points;

// // //     if (type === "monthly") {
// // //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// // //     } else if (type === "yearly") {
// // //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// // //     } else {
// // //       console.error("Invalid coupon type:", type);
// // //       dispatch(
// // //         updateModalType({
// // //           type: ModalType.ERROR_MODAL,
// // //           data: {
// // //             message: "Please select a valid coupon type.",
// // //           },
// // //         })
// // //       );
// // //       return;
// // //     }

// // //     const currentPoints = myRewards?.reward?.active || 0;
// // //     if (currentPoints < points) {
// // //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// // //       dispatch(
// // //         updateModalType({
// // //           type: ModalType.ERROR_MODAL,
// // //           data: {
// // //             message: `You need ${points} points but only have ${currentPoints} points.`,
// // //           },
// // //         })
// // //       );
// // //       return;
// // //     }

// // //     setIsRedeeming(true);

// // //     try {
// // //       console.log("Calling createCoupon thunk...");

// // //       const requestData = {
// // //         type: type,
// // //         points: points,
// // //         userId: user?.user?.id,
// // //       };

// // //       console.log("Request payload:", requestData);

// // //       const response = await dispatch(
// // //         createCoupon({
// // //           data: requestData,
// // //           setError: () => {},
// // //         })
// // //       );

// // //       console.log("Coupon thunk response:", response);

// // //       if (response?.payload?.data) {
// // //         console.log("Coupon generation successful");

// // //         const couponData = response?.payload?.data?.coupon;
// // //         const couponCode = couponData?.coupon;

// // //         if (!couponCode) {
// // //           throw new Error("Coupon code not returned from API");
// // //         }

// // //         console.log("Generated coupon code:", couponCode);
// // //         console.log("Coupon data:", couponData);

// // //         reset();

// // //         dispatch(updateModalType({ type: ModalType.NONE }));

// // //         setTimeout(() => {
// // //           console.log("Showing success message with REDEEM_SUCCESS modal...");
// // //           dispatch(
// // //             updateModalType({
// // //               type: ModalType.REDEEM_SUCCESS,
// // //               data: {
// // //                 actionType: "COUPON_SUCCESS",
// // //                 title: "Coupon Generated!",
// // //                 message: "Coupon generated and added successfully",
// // //                 couponCode: couponCode,
// // //                 coupon: couponCode,
// // //                 couponType: type,
// // //                 expiryDate: couponData?.expiryDate,
// // //                 points: points,
// // //                 status: couponData?.status,
// // //               },
// // //             })
// // //           );
// // //         }, 200);

// // //         // ✅ Re-fetch rewards balance AND coupon history immediately — no page refresh needed
// // //         fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// // //         calculateTotalCouponPoints();

// // //       } else {
// // //         const errorMessage =
// // //           response?.payload?.message || "Failed to generate coupon. Please try again.";
// // //         throw new Error(errorMessage);
// // //       }
// // //     } catch (error) {
// // //       console.error("Coupon generation error:", error);
// // //       dispatch(
// // //         updateModalType({
// // //           type: ModalType.ERROR_MODAL,
// // //           data: {
// // //             message: error.message || "Failed to generate coupon. Please try again.",
// // //           },
// // //         })
// // //       );
// // //     } finally {
// // //       setIsRedeeming(false);
// // //     }
// // //   };

// // //   const activePoints = myRewards?.reward?.active || 0;
// // //   const calculatedTotalEarned =
// // //     totalCouponPoints !== null && totalRedeemedPoints !== null
// // //       ? activePoints + totalRedeemedPoints + totalCouponPoints
// // //       : null;

// // //   const updatedMyRewards =
// // //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// // //       ? {
// // //           ...myRewards,
// // //           reward: {
// // //             ...myRewards.reward,
// // //             total: calculatedTotalEarned,
// // //             coupons: totalCouponPoints,
// // //             redeemed: totalRedeemedPoints,
// // //           },
// // //         }
// // //       : myRewards;

// // //   return {
// // //     rewardsActions,
// // //     handleGetCouponModal,
// // //     fields: fields,
// // //     onSubmit,
// // //     control,
// // //     handleSubmit,
// // //     errors,
// // //     loading: loading || isRedeeming,
// // //     myRewards: updatedMyRewards,
// // //     isRedeeming,
// // //   };
// // // };


// // import { ModalType } from "../../types/ui";
// // import { useForm } from "react-hook-form";
// // import { useEffect, useState, useCallback } from "react";
// // import { useNavigate } from "react-router-dom";
// // import { yupResolver } from "@hookform/resolvers/yup";
// // import { useDispatch, useSelector } from "react-redux";
// // import { fetchMyRewardsUtil } from "../../utils/utility";
// // import { PointIcon } from "../../assets/svgs/components/point-icon";
// // import { updateModalType } from "../../api/slices/globalSlice/global";
// // import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// // import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// // import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// // import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// // import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// // import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// // export const useMyRewards = () => {
// //   const dispatch = useDispatch();
// //   const navigate = useNavigate();
// //   const [myRewards, setMyRewards] = useState(null);
// //   const [isRedeeming, setIsRedeeming] = useState(false);
// //   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
// //   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
// //   const { loading } = useSelector((state) => state.myRewards);
// //   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);
// //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// //   const schema = generateGetCouponValidationSchema();

// //   useEffect(() => {
// //     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// //   }, [dispatch, authLoading, user]);

// //   useEffect(() => {
// //     const fetchMyRewardsDiscount = async () => {
// //       try {
// //         const response = await dispatch(readMyRewardsDiscount({}));
// //         if (response?.payload?.data) {
// //           setMyRewardsDiscount(response?.payload?.data);
// //         }
// //       } catch (err) {
// //         console.error("Error fetching rewards discount:", err);
// //       }
// //     };
// //     fetchMyRewardsDiscount();
// //   }, [dispatch]);

// //   // Extracted to useCallback so it can be called on mount AND after coupon creation
// //   const calculateTotalCouponPoints = useCallback(async () => {
// //     if (authLoading || !user?.user?.id) return;

// //     try {
// //       let allCoupons = [];
// //       let currentPage = 1;
// //       let hasMore = true;

// //       while (hasMore) {
// //         const response = await dispatch(
// //           readCouponHistory({
// //             params: {
// //               uid: user.user.id,
// //               page: currentPage,
// //               size: 100,
// //               order: "desc",
// //             },
// //           })
// //         );

// //         if (response?.payload?.data && Array.isArray(response.payload.data)) {
// //           allCoupons = [...allCoupons, ...response.payload.data];
// //           const pagination = response.payload.pagination;
// //           const totalPages = Math.ceil(pagination.total / 100);
// //           if (currentPage >= totalPages) {
// //             hasMore = false;
// //           } else {
// //             currentPage++;
// //           }
// //         } else {
// //           hasMore = false;
// //         }
// //       }

// //       const total = allCoupons.reduce((sum, coupon) => {
// //         return sum + (parseInt(coupon.points, 10) || 0);
// //       }, 0);

// //       setTotalCouponPoints(total);
// //     } catch (err) {
// //       console.error("Error calculating total coupon points:", err);
// //       setTotalCouponPoints(0);
// //     }
// //   }, [dispatch, user, authLoading]);

// //   // Calculate total coupon points on mount
// //   useEffect(() => {
// //     calculateTotalCouponPoints();
// //   }, [calculateTotalCouponPoints]);

// //   // Calculate total redeemed points on mount
// //   useEffect(() => {
// //     const calculateTotalRedeemedPoints = async () => {
// //       if (authLoading || !user?.user?.id) return;

// //       try {
// //         let allRedeems = [];
// //         let currentPage = 1;
// //         let hasMore = true;

// //         while (hasMore) {
// //           const response = await dispatch(
// //             readRedeemHistory({
// //               params: {
// //                 uid: user.user.id,
// //                 page: currentPage,
// //                 size: 100,
// //                 sort: "createdAt",
// //                 order: "desc",
// //               },
// //             })
// //           );

// //           if (response?.payload?.data && Array.isArray(response.payload.data)) {
// //             allRedeems = [...allRedeems, ...response.payload.data];
// //             const pagination = response.payload.pagination;
// //             const totalPages = Math.ceil(pagination.total / 100);
// //             if (currentPage >= totalPages) {
// //               hasMore = false;
// //             } else {
// //               currentPage++;
// //             }
// //           } else {
// //             hasMore = false;
// //           }
// //         }

// //         const total = allRedeems.reduce((sum, redeem) => {
// //           return sum + (parseInt(redeem.points, 10) || 0);
// //         }, 0);

// //         setTotalRedeemedPoints(total);
// //       } catch (err) {
// //         console.error("Error calculating total redeemed points:", err);
// //         setTotalRedeemedPoints(0);
// //       }
// //     };

// //     calculateTotalRedeemedPoints();
// //   }, [dispatch, user, authLoading]);

// //   const handleGetCouponModal = () => {
// //     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
// //   };

// //   const rewardsActions = [
// //     {
// //       icon: PointIcon,
// //       text: "Points History",
// //       onClick: () => navigate("/point-history"),
// //     },
// //     {
// //       icon: GetCouponIcon,
// //       text: "Get a coupon",
// //       onClick: handleGetCouponModal,
// //     },
// //     {
// //       icon: PointIcon,
// //       text: "Request Redeem",
// //       onClick: () => navigate("/request-redeem"),
// //     },
// //   ];

// //   const {
// //     register,
// //     handleSubmit,
// //     control,
// //     formState: { errors },
// //     reset,
// //   } = useForm({
// //     resolver: yupResolver(schema),
// //   });

// //   const fields = GetCouponFormFields(register, isRedeeming);

// //   const onSubmit = async (data) => {
// //     console.log("Form submitted with data:", data);

// //     if (!myRewardsDiscount) {
// //       console.error("Rewards discount data not available");
// //       dispatch(
// //         updateModalType({
// //           type: ModalType.ERROR_MODAL,
// //           data: {
// //             message: "Unable to load coupon information. Please try again.",
// //           },
// //         })
// //       );
// //       return;
// //     }

// //     if (!myRewards?.reward) {
// //       console.error("User rewards data not available");
// //       dispatch(
// //         updateModalType({
// //           type: ModalType.ERROR_MODAL,
// //           data: {
// //             message: "Unable to load your rewards. Please refresh the page.",
// //           },
// //         })
// //       );
// //       return;
// //     }

// //     const type = data?.couponType;
// //     let points;

// //     if (type === "monthly") {
// //       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
// //     } else if (type === "yearly") {
// //       points = myRewardsDiscount?.referralPointsForYearlySubscription;
// //     } else {
// //       console.error("Invalid coupon type:", type);
// //       dispatch(
// //         updateModalType({
// //           type: ModalType.ERROR_MODAL,
// //           data: {
// //             message: "Please select a valid coupon type.",
// //           },
// //         })
// //       );
// //       return;
// //     }

// //     const currentPoints = myRewards?.reward?.active || 0;
// //     if (currentPoints < points) {
// //       console.error(`Not enough points. Need: ${points}, Have: ${currentPoints}`);
// //       dispatch(
// //         updateModalType({
// //           type: ModalType.ERROR_MODAL,
// //           data: {
// //             message: `You need ${points} points but only have ${currentPoints} points.`,
// //           },
// //         })
// //       );
// //       return;
// //     }

// //     setIsRedeeming(true);

// //     try {
// //       console.log("Calling createCoupon thunk...");

// //       const requestData = {
// //         type: type,
// //         points: points,
// //         userId: user?.user?.id,
// //       };

// //       console.log("Request payload:", requestData);

// //       const response = await dispatch(
// //         createCoupon({
// //           data: requestData,
// //           setError: () => {},
// //         })
// //       );

// //       console.log("Coupon thunk response:", response);

// //       if (response?.payload?.data) {
// //         console.log("Coupon generation successful");

// //         const couponData = response?.payload?.data?.coupon;
// //         const couponCode = couponData?.coupon;

// //         if (!couponCode) {
// //           throw new Error("Coupon code not returned from API");
// //         }

// //         reset();
// //         dispatch(updateModalType({ type: ModalType.NONE }));

// //         setTimeout(() => {
// //           dispatch(
// //             updateModalType({
// //               type: ModalType.REDEEM_SUCCESS,
// //               data: {
// //                 actionType: "COUPON_SUCCESS",
// //                 title: "Coupon Generated!",
// //                 message: "Coupon generated and added successfully",
// //                 couponCode: couponCode,
// //                 coupon: couponCode,
// //                 couponType: type,
// //                 expiryDate: couponData?.expiryDate,
// //                 points: points,
// //                 status: couponData?.status,
// //               },
// //             })
// //           );
// //         }, 200);

// //         // ✅ Optimistically update UI instantly — no waiting for API response
// //         // This makes Points Used for Coupons and Rewards Balance update immediately
// //         setTotalCouponPoints((prev) => (prev ?? 0) + points);
// //         setMyRewards((prev) =>
// //           prev
// //             ? {
// //                 ...prev,
// //                 reward: {
// //                   ...prev.reward,
// //                   active: (prev.reward?.active ?? 0) - points,
// //                   coupons: (prev.reward?.coupons ?? 0) + points,
// //                 },
// //               }
// //             : prev
// //         );

// //         // Then confirm with real API values in the background
// //         fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards });
// //         calculateTotalCouponPoints();

// //       } else {
// //         const errorMessage =
// //           response?.payload?.message || "Failed to generate coupon. Please try again.";
// //         throw new Error(errorMessage);
// //       }
// //     } catch (error) {
// //       console.error("Coupon generation error:", error);
// //       dispatch(
// //         updateModalType({
// //           type: ModalType.ERROR_MODAL,
// //           data: {
// //             message: error.message || "Failed to generate coupon. Please try again.",
// //           },
// //         })
// //       );
// //     } finally {
// //       setIsRedeeming(false);
// //     }
// //   };

// //   const activePoints = myRewards?.reward?.active || 0;
// //   const calculatedTotalEarned =
// //     totalCouponPoints !== null && totalRedeemedPoints !== null
// //       ? activePoints + totalRedeemedPoints + totalCouponPoints
// //       : null;

// //   const updatedMyRewards =
// //     myRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
// //       ? {
// //           ...myRewards,
// //           reward: {
// //             ...myRewards.reward,
// //             total: calculatedTotalEarned,
// //             coupons: totalCouponPoints,
// //             redeemed: totalRedeemedPoints,
// //           },
// //         }
// //       : myRewards;

// //   return {
// //     rewardsActions,
// //     handleGetCouponModal,
// //     fields: fields,
// //     onSubmit,
// //     control,
// //     handleSubmit,
// //     errors,
// //     loading: loading || isRedeeming,
// //     myRewards: updatedMyRewards,
// //     isRedeeming,
// //   };
// // };




// import { ModalType } from "../../types/ui";
// import { useForm } from "react-hook-form";
// import { useEffect, useState, useCallback } from "react";
// import { useNavigate } from "react-router-dom";
// import { yupResolver } from "@hookform/resolvers/yup";
// import { useDispatch, useSelector } from "react-redux";
// import { fetchMyRewardsUtil } from "../../utils/utility";
// import { PointIcon } from "../../assets/svgs/components/point-icon";
// import { updateModalType } from "../../api/slices/globalSlice/global";
// import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
// import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
// import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
// import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
// import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
// import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

// export const useMyRewards = () => {
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const [isRedeeming, setIsRedeeming] = useState(false);
//   const [totalCouponPoints, setTotalCouponPoints] = useState(null);
//   const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
//   const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);

//   const { loading, myRewards: reduxMyRewards } = useSelector((state) => state.myRewards);
//   const { user, loading: authLoading } = useSelector((state) => state.auth);

//   const schema = generateGetCouponValidationSchema();

//   // ✅ Read directly from Redux store — updates instantly when slice updates
//   useEffect(() => {
//     if (authLoading || !user?.user?.id) return;
//     fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards: () => {} });
//   }, [dispatch, authLoading, user]);

//   useEffect(() => {
//     const fetchMyRewardsDiscount = async () => {
//       try {
//         const response = await dispatch(readMyRewardsDiscount({}));
//         if (response?.payload?.data) {
//           setMyRewardsDiscount(response?.payload?.data);
//         }
//       } catch (err) {
//         console.error("Error fetching rewards discount:", err);
//       }
//     };
//     fetchMyRewardsDiscount();
//   }, [dispatch]);

//   const calculateTotalCouponPoints = useCallback(async () => {
//     if (authLoading || !user?.user?.id) return;

//     try {
//       let allCoupons = [];
//       let currentPage = 1;
//       let hasMore = true;

//       while (hasMore) {
//         const response = await dispatch(
//           readCouponHistory({
//             params: {
//               uid: user.user.id,
//               page: currentPage,
//               size: 100,
//               order: "desc",
//             },
//           })
//         );

//         if (response?.payload?.data && Array.isArray(response.payload.data)) {
//           allCoupons = [...allCoupons, ...response.payload.data];
//           const pagination = response.payload.pagination;
//           const totalPages = Math.ceil(pagination.total / 100);
//           if (currentPage >= totalPages) {
//             hasMore = false;
//           } else {
//             currentPage++;
//           }
//         } else {
//           hasMore = false;
//         }
//       }

//       const total = allCoupons.reduce((sum, coupon) => {
//         return sum + (parseInt(coupon.points, 10) || 0);
//       }, 0);

//       setTotalCouponPoints(total);
//     } catch (err) {
//       console.error("Error calculating total coupon points:", err);
//       setTotalCouponPoints(0);
//     }
//   }, [dispatch, user, authLoading]);

//   useEffect(() => {
//     calculateTotalCouponPoints();
//   }, [calculateTotalCouponPoints]);

//   useEffect(() => {
//     const calculateTotalRedeemedPoints = async () => {
//       if (authLoading || !user?.user?.id) return;

//       try {
//         let allRedeems = [];
//         let currentPage = 1;
//         let hasMore = true;

//         while (hasMore) {
//           const response = await dispatch(
//             readRedeemHistory({
//               params: {
//                 uid: user.user.id,
//                 page: currentPage,
//                 size: 100,
//                 sort: "createdAt",
//                 order: "desc",
//               },
//             })
//           );

//           if (response?.payload?.data && Array.isArray(response.payload.data)) {
//             allRedeems = [...allRedeems, ...response.payload.data];
//             const pagination = response.payload.pagination;
//             const totalPages = Math.ceil(pagination.total / 100);
//             if (currentPage >= totalPages) {
//               hasMore = false;
//             } else {
//               currentPage++;
//             }
//           } else {
//             hasMore = false;
//           }
//         }

//         const total = allRedeems.reduce((sum, redeem) => {
//           return sum + (parseInt(redeem.points, 10) || 0);
//         }, 0);

//         setTotalRedeemedPoints(total);
//       } catch (err) {
//         console.error("Error calculating total redeemed points:", err);
//         setTotalRedeemedPoints(0);
//       }
//     };

//     calculateTotalRedeemedPoints();
//   }, [dispatch, user, authLoading]);

//   const handleGetCouponModal = () => {
//     dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
//   };

//   const rewardsActions = [
//     {
//       icon: PointIcon,
//       text: "Points History",
//       onClick: () => navigate("/point-history"),
//     },
//     {
//       icon: GetCouponIcon,
//       text: "Get a coupon",
//       onClick: handleGetCouponModal,
//     },
//     {
//       icon: PointIcon,
//       text: "Request Redeem",
//       onClick: () => navigate("/request-redeem"),
//     },
//   ];

//   const {
//     register,
//     handleSubmit,
//     control,
//     formState: { errors },
//     reset,
//   } = useForm({
//     resolver: yupResolver(schema),
//   });

//   const fields = GetCouponFormFields(register, isRedeeming);

//   const onSubmit = async (data) => {
//     console.log("Form submitted with data:", data);

//     if (!myRewardsDiscount) {
//       dispatch(
//         updateModalType({
//           type: ModalType.ERROR_MODAL,
//           data: { message: "Unable to load coupon information. Please try again." },
//         })
//       );
//       return;
//     }

//     if (!reduxMyRewards?.reward) {
//       dispatch(
//         updateModalType({
//           type: ModalType.ERROR_MODAL,
//           data: { message: "Unable to load your rewards. Please refresh the page." },
//         })
//       );
//       return;
//     }

//     const type = data?.couponType;
//     let points;

//     if (type === "monthly") {
//       points = myRewardsDiscount?.referralPointsForMonthlySubscription;
//     } else if (type === "yearly") {
//       points = myRewardsDiscount?.referralPointsForYearlySubscription;
//     } else {
//       dispatch(
//         updateModalType({
//           type: ModalType.ERROR_MODAL,
//           data: { message: "Please select a valid coupon type." },
//         })
//       );
//       return;
//     }

//     const currentPoints = reduxMyRewards?.reward?.active || 0;
//     if (currentPoints < points) {
//       dispatch(
//         updateModalType({
//           type: ModalType.ERROR_MODAL,
//           data: {
//             message: `You need ${points} points but only have ${currentPoints} points.`,
//           },
//         })
//       );
//       return;
//     }

//     setIsRedeeming(true);

//     try {
//       const requestData = {
//         type: type,
//         points: points,
//         userId: user?.user?.id,
//       };

//       const response = await dispatch(
//         createCoupon({
//           data: requestData,
//           setError: () => {},
//         })
//       );

//       if (response?.payload?.data) {
//         const couponData = response?.payload?.data?.coupon;
//         const couponCode = couponData?.coupon;

//         if (!couponCode) {
//           throw new Error("Coupon code not returned from API");
//         }

//         reset();
//         dispatch(updateModalType({ type: ModalType.NONE }));

//         // ✅ Redux slice already updated active & coupons in myRewards instantly
//         // Just update totalCouponPoints local state to match
//         setTotalCouponPoints((prev) => (prev ?? 0) + points);

//         setTimeout(() => {
//           dispatch(
//             updateModalType({
//               type: ModalType.REDEEM_SUCCESS,
//               data: {
//                 actionType: "COUPON_SUCCESS",
//                 title: "Coupon Generated!",
//                 message: "Coupon generated and added successfully",
//                 couponCode: couponCode,
//                 coupon: couponCode,
//                 couponType: type,
//                 expiryDate: couponData?.expiryDate,
//                 points: points,
//                 status: couponData?.status,
//               },
//             })
//           );
//         }, 200);

//         // Confirm with real API values in background
//         calculateTotalCouponPoints();

//       } else {
//         const errorMessage =
//           response?.payload?.message || "Failed to generate coupon. Please try again.";
//         throw new Error(errorMessage);
//       }
//     } catch (error) {
//       console.error("Coupon generation error:", error);
//       dispatch(
//         updateModalType({
//           type: ModalType.ERROR_MODAL,
//           data: {
//             message: error.message || "Failed to generate coupon. Please try again.",
//           },
//         })
//       );
//     } finally {
//       setIsRedeeming(false);
//     }
//   };

//   // ✅ Use reduxMyRewards directly — updated instantly by the slice on createCoupon.fulfilled
//   const activePoints = reduxMyRewards?.reward?.active || 0;
//   const calculatedTotalEarned =
//     totalCouponPoints !== null && totalRedeemedPoints !== null
//       ? activePoints + totalRedeemedPoints + totalCouponPoints
//       : null;

//   const updatedMyRewards =
//     reduxMyRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
//       ? {
//           ...reduxMyRewards,
//           reward: {
//             ...reduxMyRewards.reward,
//             total: calculatedTotalEarned,
//             coupons: totalCouponPoints,
//             redeemed: totalRedeemedPoints,
//           },
//         }
//       : reduxMyRewards;

//   return {
//     rewardsActions,
//     handleGetCouponModal,
//     fields: fields,
//     onSubmit,
//     control,
//     handleSubmit,
//     errors,
//     loading: loading || isRedeeming,
//     myRewards: updatedMyRewards,
//     isRedeeming,
//   };
// };






import { ModalType } from "../../types/ui";
import { useForm } from "react-hook-form";
import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch, useSelector } from "react-redux";
import { fetchMyRewardsUtil } from "../../utils/utility";
import { PointIcon } from "../../assets/svgs/components/point-icon";
import { updateModalType } from "../../api/slices/globalSlice/global";
import { GetCouponIcon } from "../../assets/svgs/components/get-coupon-icon";
import { GetCouponFormFields } from "../../components/myRewards/get-coupon-fields";
import { readMyRewardsDiscount, createCoupon } from "../../api/slices/myRewards/myRewardsSlice";
import { readCouponHistory } from "../../api/slices/couponHistory/couponHistory";
import { readRedeemHistory } from "../../api/slices/redeemHistory/redeem-history";
import { generateGetCouponValidationSchema } from "../../validation/redeem-points-validation";

export const useMyRewards = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isRedeeming, setIsRedeeming] = useState(false);
  const [totalCouponPoints, setTotalCouponPoints] = useState(null);
  const [totalRedeemedPoints, setTotalRedeemedPoints] = useState(null);
  const [myRewardsDiscount, setMyRewardsDiscount] = useState(null);

  const { loading, myRewards: reduxMyRewards } = useSelector((state) => state.myRewards);
  const { user, loading: authLoading } = useSelector((state) => state.auth);

  const schema = generateGetCouponValidationSchema();

  // ✅ Read directly from Redux store — updates instantly when slice updates
  useEffect(() => {
    if (authLoading || !user?.user?.id) return;
    fetchMyRewardsUtil({ dispatch, user, authLoading, setMyRewards: () => {} });
  }, [dispatch, authLoading, user]);

  useEffect(() => {
    const fetchMyRewardsDiscount = async () => {
      try {
        const response = await dispatch(readMyRewardsDiscount({}));
        if (response?.payload?.data) {
          setMyRewardsDiscount(response?.payload?.data);
        }
      } catch (err) {
        console.error("Error fetching rewards discount:", err);
      }
    };
    fetchMyRewardsDiscount();
  }, [dispatch]);

  const calculateTotalCouponPoints = useCallback(async () => {
    if (authLoading || !user?.user?.id) return;

    try {
      let allCoupons = [];
      let currentPage = 1;
      let hasMore = true;

      while (hasMore) {
        const response = await dispatch(
          readCouponHistory({
            params: {
              uid: user.user.id,
              page: currentPage,
              size: 100,
              order: "desc",
            },
          })
        );

        if (response?.payload?.data && Array.isArray(response.payload.data)) {
          allCoupons = [...allCoupons, ...response.payload.data];
          const pagination = response.payload.pagination;
          const totalPages = Math.ceil(pagination.total / 100);
          if (currentPage >= totalPages) {
            hasMore = false;
          } else {
            currentPage++;
          }
        } else {
          hasMore = false;
        }
      }

      const total = allCoupons.reduce((sum, coupon) => {
        return sum + (parseInt(coupon.points, 10) || 0);
      }, 0);

      setTotalCouponPoints(total);
    } catch (err) {
      console.error("Error calculating total coupon points:", err);
      setTotalCouponPoints(0);
    }
  }, [dispatch, user, authLoading]);

  useEffect(() => {
    calculateTotalCouponPoints();
  }, [calculateTotalCouponPoints]);

  useEffect(() => {
    const calculateTotalRedeemedPoints = async () => {
      if (authLoading || !user?.user?.id) return;

      try {
        let allRedeems = [];
        let currentPage = 1;
        let hasMore = true;

        while (hasMore) {
          const response = await dispatch(
            readRedeemHistory({
              params: {
                uid: user.user.id,
                page: currentPage,
                size: 100,
                sort: "createdAt",
                order: "desc",
              },
            })
          );

          if (response?.payload?.data && Array.isArray(response.payload.data)) {
            allRedeems = [...allRedeems, ...response.payload.data];
            const pagination = response.payload.pagination;
            const totalPages = Math.ceil(pagination.total / 100);
            if (currentPage >= totalPages) {
              hasMore = false;
            } else {
              currentPage++;
            }
          } else {
            hasMore = false;
          }
        }

        const total = allRedeems.reduce((sum, redeem) => {
          return sum + (parseInt(redeem.points, 10) || 0);
        }, 0);

        setTotalRedeemedPoints(total);
      } catch (err) {
        console.error("Error calculating total redeemed points:", err);
        setTotalRedeemedPoints(0);
      }
    };

    calculateTotalRedeemedPoints();
  }, [dispatch, user, authLoading]);

  const handleGetCouponModal = () => {
    dispatch(updateModalType({ type: ModalType.GET_COUPON_MODAL }));
  };

  const rewardsActions = [
    {
      icon: PointIcon,
      text: "Points History",
      onClick: () => navigate("/point-history"),
    },
    {
      icon: GetCouponIcon,
      text: "Get a coupon",
      onClick: handleGetCouponModal,
    },
    {
      icon: PointIcon,
      text: "Request Redeem",
      onClick: () => navigate("/request-redeem"),
    },
  ];

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  const fields = GetCouponFormFields(register, isRedeeming);

  const onSubmit = async (data) => {
    console.log("Form submitted with data:", data);

    if (!myRewardsDiscount) {
      dispatch(
        updateModalType({
          type: ModalType.ERROR_MODAL,
          data: { message: "Unable to load coupon information. Please try again." },
        })
      );
      return;
    }

    if (!reduxMyRewards?.reward) {
      dispatch(
        updateModalType({
          type: ModalType.ERROR_MODAL,
          data: { message: "Unable to load your rewards. Please refresh the page." },
        })
      );
      return;
    }

    const type = data?.couponType;
    let points;

    if (type === "monthly") {
      points = myRewardsDiscount?.referralPointsForMonthlySubscription;
    } else if (type === "yearly") {
      points = myRewardsDiscount?.referralPointsForYearlySubscription;
    } else {
      dispatch(
        updateModalType({
          type: ModalType.ERROR_MODAL,
          data: { message: "Please select a valid coupon type." },
        })
      );
      return;
    }

    const currentPoints = reduxMyRewards?.reward?.active || 0;
    if (currentPoints < points) {
      dispatch(
        updateModalType({
          type: ModalType.ERROR_MODAL,
          data: {
            message: `You need ${points} points but only have ${currentPoints} points.`,
          },
        })
      );
      return;
    }

    setIsRedeeming(true);

    try {
      const requestData = {
        type: type,
        points: points,
        userId: user?.user?.id,
      };

      const response = await dispatch(
        createCoupon({
          data: requestData,
          setError: () => {},
        })
      );

      if (response?.payload?.data) {
        const couponData = response?.payload?.data?.coupon;
        const couponCode = couponData?.coupon;

        if (!couponCode) {
          throw new Error("Coupon code not returned from API");
        }

        reset();
        dispatch(updateModalType({ type: ModalType.NONE }));

        // ✅ Redux slice already updated active & coupons in myRewards instantly
        // Just update totalCouponPoints local state to match
        setTotalCouponPoints((prev) => (prev ?? 0) + points);

        setTimeout(() => {
          dispatch(
            updateModalType({
              type: ModalType.REDEEM_SUCCESS,
              data: {
                actionType: "COUPON_SUCCESS",
                title: "Coupon Generated!",
                message: "Coupon generated and added successfully",
                couponCode: couponCode,
                coupon: couponCode,
                couponType: type,
                expiryDate: couponData?.expiryDate,
                points: points,
                status: couponData?.status,
              },
            })
          );
        }, 200);

        // Confirm with real API values in background
        calculateTotalCouponPoints();

      } else {
        const errorMessage =
          response?.payload?.message || "Failed to generate coupon. Please try again.";
        throw new Error(errorMessage);
      }
    } catch (error) {
      console.error("Coupon generation error:", error);
      dispatch(
        updateModalType({
          type: ModalType.ERROR_MODAL,
          data: {
            message: error.message || "Failed to generate coupon. Please try again.",
          },
        })
      );
    } finally {
      setIsRedeeming(false);
    }
  };

  // ✅ Use reduxMyRewards directly — updated instantly by the slice on createCoupon.fulfilled
  const activePoints = reduxMyRewards?.reward?.active || 0;
  const calculatedTotalEarned =
    totalCouponPoints !== null && totalRedeemedPoints !== null
      ? activePoints + totalRedeemedPoints + totalCouponPoints
      : null;

  const updatedMyRewards =
    reduxMyRewards && totalCouponPoints !== null && totalRedeemedPoints !== null
      ? {
          ...reduxMyRewards,
          reward: {
            ...reduxMyRewards.reward,
            total: calculatedTotalEarned,
            coupons: totalCouponPoints,
            redeemed: totalRedeemedPoints,
          },
        }
      : reduxMyRewards;

  return {
    rewardsActions,
    handleGetCouponModal,
    fields: fields,
    onSubmit,
    control,
    handleSubmit,
    errors,
    loading: loading || isRedeeming,
    myRewards: updatedMyRewards,
    isRedeeming,
  };
};
