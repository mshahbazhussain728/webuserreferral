// // // // // // import { useState, useEffect } from "react";
// // // // // // import { getPageFromURL } from "../../utils/utility";
// // // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // // import { useLocation, useSearchParams } from "react-router-dom";
// // // // // // import { getLastHeading, getPageTitles } from "../../utils/function";
// // // // // // import { readPremiumUsers } from "../../api/slices/premiumUser/premium-user";
// // // // // // import { FiltersDefaultValues } from "../../utils/static";

// // // // // // export const useMonthlyUses = () => {
// // // // // //   const location = useLocation();
// // // // // //   const dispatch = useDispatch();
// // // // // //   const [searchParams, setSearchParams] = useSearchParams(location.search);
// // // // // //   const page = searchParams.get("page");
// // // // // //   const [currentPage, setCurrentPage] = useState(page || 1);
// // // // // //   const [currentPageRows, setCurrentPageRows] = useState([]);
// // // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// // // // // //   const { loading } = useSelector((state) => state.premiumUsers);
// // // // // //   const [filter, setFilter] = useState({
// // // // // //     sort: FiltersDefaultValues.None,
// // // // // //   });

// // // // // //   const sort = searchParams.get("sort");
// // // // // //   const status = getLastHeading(location.search);

// // // // // //   useEffect(() => {
// // // // // //     if (authLoading) return;
// // // // // //     const parsedPage = parseInt(page, 10);

// // // // // //     let resetPage = null;
// // // // // //     if (!isNaN(parsedPage)) {
// // // // // //       setCurrentPage(parsedPage);
// // // // // //     } else {
// // // // // //       resetPage = 1;
// // // // // //       setCurrentPage(1);
// // // // // //     }

// // // // // //     const queryStatus = searchParams.get("status");

// // // // // //     const redeemHistoryRecords = async () => {
// // // // // //       const uid = user?.user?.id;
// // // // // //       if (!uid) return;

// // // // // //       const queryParams = queryStatus || sort;

// // // // // //       if (queryParams !== undefined) {
// // // // // //         const filteredStatus =
// // // // // //           queryStatus === "None"
// // // // // //             ? ""
// // // // // //             : queryStatus === "subscribed"
// // // // // //             ? "active"
// // // // // //             : queryStatus === "cancelled"
// // // // // //             ? "canceled"
// // // // // //             : queryParams;
// // // // // //         const filteredData = {
// // // // // //           uid: uid,
// // // // // //           type: "monthly",
// // // // // //           page: (Number(parsedPage) || resetPage) ?? currentPage,
// // // // // //           size: 10,
// // // // // //         };

// // // // // //         if (filteredStatus && filteredStatus.length > 0) {
// // // // // //           filteredData.status = filteredStatus;
// // // // // //         }

// // // // // //         if (sort) {
// // // // // //           filteredData.sort = sort;
// // // // // //         }

// // // // // //         try {
// // // // // //           const response = await dispatch(
// // // // // //             readPremiumUsers({ data: filteredData })
// // // // // //           );
// // // // // //           if (response?.payload) {
// // // // // //             const data = response.payload;
// // // // // //             setCurrentPageRows(data);
// // // // // //           }
// // // // // //         } catch (err) {
// // // // // //           console.error("Error fetching monthly premium users:", err);
// // // // // //         }
// // // // // //       }
// // // // // //     };

// // // // // //     redeemHistoryRecords();
// // // // // //   }, [location.search, location.key, user, authLoading, sort]);

// // // // // //   useEffect(() => {
// // // // // //     const handlePopState = () => {
// // // // // //       setCurrentPage(getPageFromURL());
// // // // // //     };
// // // // // //     window.addEventListener("popstate", handlePopState);
// // // // // //     return () => window.removeEventListener("popstate", handlePopState);
// // // // // //   }, []);

// // // // // //   const lastHeadingValue =
// // // // // //     status === "Cleared"
// // // // // //       ? "clearDate"
// // // // // //       : status === "Cancelled"
// // // // // //       ? "cancelledDate"
// // // // // //       : "clearanceDate";

// // // // // //   const headings = [
// // // // // //     {
// // // // // //       label: "User details",
// // // // // //       value: "name",
// // // // // //     },
// // // // // //     { label: "Installed", value: "installDate" },
// // // // // //     { label: "Subscribed", value: "subscribedDate" },
// // // // // //     { label: status, value: lastHeadingValue },
// // // // // //   ];

// // // // // //   const { mobilePageTitle, pageTitle } = getPageTitles(location);

// // // // // //   const dummyData = [
// // // // // //     { title: "Total Users", points: currentPageRows?.metrics?.total },
// // // // // //     { title: "This Month", points: currentPageRows?.metrics?.thisMonth },
// // // // // //     { title: "This Week", points: currentPageRows?.metrics?.thisWeek },
// // // // // //     { title: "Revenue", points: currentPageRows?.metrics?.totalrevenue },
// // // // // //   ];

// // // // // //   const totalCount = currentPageRows?.pagination?.total;
// // // // // //   const itemsPerPage = 10;
// // // // // //   const totalItems = totalCount;

// // // // // //   const handlePageChange = (page) => {
// // // // // //     setCurrentPage(page);

// // // // // //     const params = new URLSearchParams(window.location.search);
// // // // // //     params.set("page", page.toString());
// // // // // //     setSearchParams(params);
// // // // // //   };

// // // // // //   const hanldeSortChange = (value) => {
// // // // // //     const params = new URLSearchParams(window.location.search);

// // // // // //     if (value === "None") {
// // // // // //       params.delete("sort");
// // // // // //     } else {
// // // // // //       params.set("sort", value);
// // // // // //     }

// // // // // //     params.set("page", "1");
// // // // // //     setSearchParams(params);
// // // // // //     setCurrentPage(1);
// // // // // //     setFilter((prev) => {
// // // // // //       const updatedFilter = { ...prev, sort: value };
// // // // // //       return updatedFilter;
// // // // // //     });
// // // // // //   };

// // // // // //   return {
// // // // // //     dummyData,
// // // // // //     currentPageRows,
// // // // // //     totalItems,
// // // // // //     totalCount,
// // // // // //     loading,
// // // // // //     itemsPerPage,
// // // // // //     handlePageChange,
// // // // // //     currentPage,
// // // // // //     headings,
// // // // // //     pageTitle,
// // // // // //     mobilePageTitle,
// // // // // //     filter,
// // // // // //     sort,
// // // // // //     hanldeSortChange,
// // // // // //   };
// // // // // // };











// // // // // import { useState, useEffect } from "react";
// // // // // import { getPageFromURL } from "../../utils/utility";
// // // // // import { useDispatch, useSelector } from "react-redux";
// // // // // import { useLocation, useSearchParams } from "react-router-dom";
// // // // // import { getLastHeading, getPageTitles } from "../../utils/function";
// // // // // import { FiltersDefaultValues } from "../../utils/static";

// // // // // export const useMonthlyUses = () => {
// // // // //   const location = useLocation();
// // // // //   const dispatch = useDispatch();
// // // // //   const [searchParams, setSearchParams] = useSearchParams(location.search);
// // // // //   const page = searchParams.get("page");
// // // // //   const [currentPage, setCurrentPage] = useState(page || 1);
// // // // //   const [currentPageRows, setCurrentPageRows] = useState({});
// // // // //   const [loading, setLoading] = useState(false);
// // // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// // // // //   const [filter, setFilter] = useState({
// // // // //     sort: FiltersDefaultValues.None,
// // // // //   });

// // // // //   const sort = searchParams.get("sort");
// // // // //   const status = getLastHeading(location.search);

// // // // //   useEffect(() => {
// // // // //     if (authLoading) return;

// // // // //     const parsedPage = parseInt(page, 10);
// // // // //     let resetPage = null;

// // // // //     if (!isNaN(parsedPage)) {
// // // // //       setCurrentPage(parsedPage);
// // // // //     } else {
// // // // //       resetPage = 1;
// // // // //       setCurrentPage(1);
// // // // //     }

// // // // //     const queryStatus = searchParams.get("status");
// // // // //     const queryParams = queryStatus || sort;

// // // // //     const fetchReferralUsers = async () => {
// // // // //       const uid = user?.user?.id;
// // // // //       if (!uid) return;

// // // // //       if (queryParams === undefined) return;

// // // // //       const filteredStatus =
// // // // //         queryStatus === "None"
// // // // //           ? ""
// // // // //           : queryStatus === "subscribed"
// // // // //           ? "active"
// // // // //           : queryStatus === "cancelled"
// // // // //           ? "canceled"
// // // // //           : queryParams;

// // // // //       const requestBody = {
// // // // //         uid,
// // // // //         type: "monthly",
// // // // //         page: Number(parsedPage) || resetPage || currentPage,
// // // // //         size: 10,
// // // // //       };

// // // // //       if (filteredStatus && filteredStatus.length > 0) {
// // // // //         requestBody.status = filteredStatus;
// // // // //       }

// // // // //       if (sort) {
// // // // //         requestBody.sort = sort;
// // // // //       }

// // // // //       try {
// // // // //         setLoading(true);
// // // // //         const response = await fetch(
// // // // //           "https://referralapis.appistan.co/api/referrals/users/details",
// // // // //           {
// // // // //             method: "POST",
// // // // //             headers: { "Content-Type": "application/json" },
// // // // //             body: JSON.stringify(requestBody),
// // // // //           }
// // // // //         );

// // // // //         if (!response.ok) {
// // // // //           throw new Error(`Request failed with status: ${response.status}`);
// // // // //         }

// // // // //         const json = await response.json();

// // // // //         if (!json.success) {
// // // // //           throw new Error(json.message || "Failed to fetch referral users");
// // // // //         }

// // // // //         // Response shape:
// // // // //         // {
// // // // //         //   metrics: { total, thisWeek, thisMonth, thisYear, totalrevenue, data[] },
// // // // //         //   pagination: { total, page, size, totalPages }
// // // // //         // }
// // // // //         setCurrentPageRows({
// // // // //           metrics: json.metrics,
// // // // //           pagination: json.pagination,
// // // // //         });
// // // // //       } catch (err) {
// // // // //         console.error("Error fetching monthly referral users:", err);
// // // // //       } finally {
// // // // //         setLoading(false);
// // // // //       }
// // // // //     };

// // // // //     fetchReferralUsers();
// // // // //   }, [location.search, location.key, user, authLoading, sort]);

// // // // //   useEffect(() => {
// // // // //     const handlePopState = () => {
// // // // //       setCurrentPage(getPageFromURL());
// // // // //     };
// // // // //     window.addEventListener("popstate", handlePopState);
// // // // //     return () => window.removeEventListener("popstate", handlePopState);
// // // // //   }, []);

// // // // //   const lastHeadingValue =
// // // // //     status === "Cleared"
// // // // //       ? "clearDate"
// // // // //       : status === "Cancelled"
// // // // //       ? "cancelledDate"
// // // // //       : "clearanceDate";

// // // // //   const headings = [
// // // // //     { label: "User details", value: "name" },
// // // // //     { label: "Installed",    value: "installDate" },
// // // // //     { label: "Subscribed",   value: "subscribedDate" },
// // // // //     { label: status,         value: lastHeadingValue },
// // // // //   ];

// // // // //   const { mobilePageTitle, pageTitle } = getPageTitles(location);

// // // // //   const dummyData = [
// // // // //     { title: "Total Users", points: currentPageRows?.metrics?.total },
// // // // //     { title: "This Month",  points: currentPageRows?.metrics?.thisMonth },
// // // // //     { title: "This Week",   points: currentPageRows?.metrics?.thisWeek },
// // // // //     { title: "Revenue",     points: currentPageRows?.metrics?.totalrevenue },
// // // // //   ];

// // // // //   const totalCount   = currentPageRows?.pagination?.total;
// // // // //   const itemsPerPage = 10;
// // // // //   const totalItems   = totalCount;

// // // // //   // Table rows live inside metrics.data
// // // // //   const tableRows = currentPageRows?.metrics?.data ?? [];

// // // // //   const handlePageChange = (page) => {
// // // // //     setCurrentPage(page);
// // // // //     const params = new URLSearchParams(window.location.search);
// // // // //     params.set("page", page.toString());
// // // // //     setSearchParams(params);
// // // // //   };

// // // // //   const hanldeSortChange = (value) => {
// // // // //     const params = new URLSearchParams(window.location.search);

// // // // //     if (value === "None") {
// // // // //       params.delete("sort");
// // // // //     } else {
// // // // //       params.set("sort", value);
// // // // //     }

// // // // //     params.set("page", "1");
// // // // //     setSearchParams(params);
// // // // //     setCurrentPage(1);
// // // // //     setFilter((prev) => ({ ...prev, sort: value }));
// // // // //   };

// // // // //   return {
// // // // //     dummyData,
// // // // //     currentPageRows,
// // // // //     tableRows,
// // // // //     totalItems,
// // // // //     totalCount,
// // // // //     loading,
// // // // //     itemsPerPage,
// // // // //     handlePageChange,
// // // // //     currentPage,
// // // // //     headings,
// // // // //     pageTitle,
// // // // //     mobilePageTitle,
// // // // //     filter,
// // // // //     sort,
// // // // //     hanldeSortChange,
// // // // //   };
// // // // // };










// // // // import { useState, useEffect } from "react";
// // // // import { getPageFromURL } from "../../utils/utility";
// // // // import { useDispatch, useSelector } from "react-redux";
// // // // import { readPremiumUsers } from "../../api/slices/premiumUser/premium-user";
// // // // import { useLocation, useSearchParams } from "react-router-dom";
// // // // import { getLastHeading, getPageTitles } from "../../utils/function";
// // // // import { FiltersDefaultValues } from "../../utils/static";

// // // // export const useMonthlyUses = () => {
// // // //   const location = useLocation();
// // // //   const dispatch = useDispatch();
// // // //   const [searchParams, setSearchParams] = useSearchParams(location.search);
// // // //   const page = searchParams.get("page");
// // // //   const [currentPage, setCurrentPage] = useState(page || 1);
// // // //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// // // //   const { premiumUser, loading } = useSelector((state) => state.premiumUsers);
// // // //   const [filter, setFilter] = useState({ sort: FiltersDefaultValues.None });

// // // //   const sort   = searchParams.get("sort");
// // // //   const status = getLastHeading(location.search);

// // // //   useEffect(() => {
// // // //     if (authLoading) return;

// // // //     const parsedPage = parseInt(page, 10);
// // // //     let resetPage = null;

// // // //     if (!isNaN(parsedPage)) {
// // // //       setCurrentPage(parsedPage);
// // // //     } else {
// // // //       resetPage = 1;
// // // //       setCurrentPage(1);
// // // //     }

// // // //     const fetchUsers = async () => {
// // // //       const uid = user?.user?.id;
// // // //       if (!uid) return;

// // // //       // GET /referrals/users/paid — params passed as query string via get()
// // // //       const filteredData = { uid };
// // // //       if (sort) filteredData.sort = sort;

// // // //       try {
// // // //         await dispatch(readPremiumUsers({ data: filteredData }));
// // // //       } catch (err) {
// // // //         console.error("Error fetching premium users:", err);
// // // //       }
// // // //     };

// // // //     fetchUsers();
// // // //   }, [location.search, location.key, user, authLoading, sort]);

// // // //   useEffect(() => {
// // // //     const handlePopState = () => setCurrentPage(getPageFromURL());
// // // //     window.addEventListener("popstate", handlePopState);
// // // //     return () => window.removeEventListener("popstate", handlePopState);
// // // //   }, []);

// // // //   const lastHeadingValue =
// // // //     status === "Cleared"
// // // //       ? "clearDate"
// // // //       : status === "Cancelled"
// // // //       ? "cancelledDate"
// // // //       : "clearanceDate";

// // // //   const headings = [
// // // //     { label: "User details", value: "name"           },
// // // //     { label: "Installed",    value: "installDate"    },
// // // //     { label: "Subscribed",   value: "subscribedDate" },
// // // //     { label: status,         value: lastHeadingValue },
// // // //   ];

// // // //   const { mobilePageTitle, pageTitle } = getPageTitles(location);

// // // //   // premiumUser shape (set by slice):
// // // //   // {
// // // //   //   data: [ ...users with Subscriptions[] ],
// // // //   //   metrics: { total, thisMonth, thisWeek, totalrevenue },
// // // //   //   pagination: { total, page, size }
// // // //   // }
// // // //   const dummyData = [
// // // //     { title: "Total Users", points: premiumUser?.metrics?.total        || 0 },
// // // //     { title: "This Month",  points: premiumUser?.metrics?.thisMonth    || 0 },
// // // //     { title: "This Week",   points: premiumUser?.metrics?.thisWeek     || 0 },
// // // //     { title: "Revenue",     points: premiumUser?.metrics?.totalrevenue || 0 },
// // // //   ];

// // // //   // tableRows → passed directly to MonthlyPremUsersTableRows
// // // //   // each row has Subscriptions[] so table can read Subscriptions[0].startDate etc.
// // // //   const tableRows  = premiumUser?.data  ?? [];
// // // //   const totalCount = premiumUser?.pagination?.total ?? 0;
// // // //   const itemsPerPage = 10;
// // // //   const totalItems   = totalCount;

// // // //   const handlePageChange = (page) => {
// // // //     setCurrentPage(page);
// // // //     const params = new URLSearchParams(window.location.search);
// // // //     params.set("page", page.toString());
// // // //     setSearchParams(params);
// // // //   };

// // // //   const hanldeSortChange = (value) => {
// // // //     const params = new URLSearchParams(window.location.search);
// // // //     if (value === "None") {
// // // //       params.delete("sort");
// // // //     } else {
// // // //       params.set("sort", value);
// // // //     }
// // // //     params.set("page", "1");
// // // //     setSearchParams(params);
// // // //     setCurrentPage(1);
// // // //     setFilter((prev) => ({ ...prev, sort: value }));
// // // //   };

// // // //   return {
// // // //     dummyData,
// // // //     tableRows,
// // // //     totalItems,
// // // //     totalCount,
// // // //     loading,
// // // //     itemsPerPage,
// // // //     handlePageChange,
// // // //     currentPage,
// // // //     headings,
// // // //     pageTitle,
// // // //     mobilePageTitle,
// // // //     filter,
// // // //     sort,
// // // //     hanldeSortChange,
// // // //   };
// // // // };









// // import { useState, useEffect } from "react";
// // import { getPageFromURL } from "../../utils/utility";
// // import { useDispatch, useSelector } from "react-redux";
// // import { readPremiumUsers } from "../../api/slices/premiumUser/premium-user";
// // import { useLocation, useSearchParams } from "react-router-dom";
// // import { getLastHeading, getPageTitles } from "../../utils/function";
// // import { FiltersDefaultValues } from "../../utils/static";

// // export const useMonthlyUses = () => {
// //   const location = useLocation();
// //   const dispatch = useDispatch();
// //   const [searchParams, setSearchParams] = useSearchParams(location.search);
// //   const page = searchParams.get("page");
// //   const [currentPage, setCurrentPage] = useState(page || 1);
// //   const { user, loading: authLoading } = useSelector((state) => state.auth);
// //   const { premiumUser, loading } = useSelector((state) => state.premiumUsers);
// //   const [filter, setFilter] = useState({ sort: FiltersDefaultValues.None });

// //   const sort   = searchParams.get("sort");
// //   const status = getLastHeading(location.search);

// //   useEffect(() => {
// //     if (authLoading) return;

// //     const parsedPage = parseInt(page, 10);
// //     let resetPage = null;

// //     if (!isNaN(parsedPage)) {
// //       setCurrentPage(parsedPage);
// //     } else {
// //       resetPage = 1;
// //       setCurrentPage(1);
// //     }

// //     const fetchUsers = async () => {
// //       const uid = user?.user?.id;
// //       if (!uid) return;

// //       // GET /referrals/users/paid — uid passed as query param
// //       const filteredData = { uid };
// //       if (sort) filteredData.sort = sort;

// //       try {
// //         await dispatch(readPremiumUsers({ data: filteredData }));
// //       } catch (err) {
// //         console.error("Error fetching premium users:", err);
// //       }
// //     };

// //     fetchUsers();
// //   }, [location.search, location.key, user, authLoading, sort]);

// //   useEffect(() => {
// //     const handlePopState = () => setCurrentPage(getPageFromURL());
// //     window.addEventListener("popstate", handlePopState);
// //     return () => window.removeEventListener("popstate", handlePopState);
// //   }, []);

// //   const lastHeadingValue =
// //     status === "Cleared"
// //       ? "clearDate"
// //       : status === "Cancelled"
// //       ? "cancelledDate"
// //       : "clearanceDate";

// //   // 6 columns matching the 6-column grid in table-rows and table-heading
// //   const headings = [
// //     { label: "User details", value: "name"           },
// //     { label: "Installed",    value: "installDate"    },
// //     { label: "Subscribed",   value: "subscribedDate" },
// //     { label: status,         value: lastHeadingValue },
// //     { label: "Plan Type",    value: "planType"       },
// //     { label: "Status",       value: "status"         },
// //   ];

// //   const { mobilePageTitle, pageTitle } = getPageTitles(location);

// //   // premiumUser shape (set by slice):
// //   // {
// //   //   data: [ ...users with Subscriptions[] ],
// //   //   metrics: { total, thisMonth, thisWeek, totalrevenue },
// //   //   pagination: { total, page, size }
// //   // }
// //   const dummyData = [
// //     { title: "Total Users", points: premiumUser?.metrics?.total        || 0 },
// //     { title: "This Month",  points: premiumUser?.metrics?.thisMonth    || 0 },
// //     { title: "This Week",   points: premiumUser?.metrics?.thisWeek     || 0 },
// //     { title: "Revenue",     points: premiumUser?.metrics?.totalrevenue || 0 },
// //   ];

// //   // tableRows → passed to MonthlyPremUsersTableRows
// //   // each item has Subscriptions[0].planType and Subscriptions[0].status
// //   const tableRows    = premiumUser?.data         ?? [];
// //   const totalCount   = premiumUser?.pagination?.total ?? 0;
// //   const itemsPerPage = 10;
// //   const totalItems   = totalCount;

// //   const handlePageChange = (page) => {
// //     setCurrentPage(page);
// //     const params = new URLSearchParams(window.location.search);
// //     params.set("page", page.toString());
// //     setSearchParams(params);
// //   };

// //   const hanldeSortChange = (value) => {
// //     const params = new URLSearchParams(window.location.search);
// //     if (value === "None") {
// //       params.delete("sort");
// //     } else {
// //       params.set("sort", value);
// //     }
// //     params.set("page", "1");
// //     setSearchParams(params);
// //     setCurrentPage(1);
// //     setFilter((prev) => ({ ...prev, sort: value }));
// //   };

// //   return {
// //     dummyData,
// //     tableRows,
// //     totalItems,
// //     totalCount,
// //     loading,
// //     itemsPerPage,
// //     handlePageChange,
// //     currentPage,
// //     headings,
// //     pageTitle,
// //     mobilePageTitle,
// //     filter,
// //     sort,
// //     hanldeSortChange,
// //   };
// // };





// import { useState, useEffect } from "react";
// import { getPageFromURL } from "../../utils/utility";
// import { useDispatch, useSelector } from "react-redux";
// import { readPremiumUsers } from "../../api/slices/premiumUser/premium-user";
// import { useLocation, useSearchParams } from "react-router-dom";
// import { getLastHeading, getPageTitles } from "../../utils/function";
// import { FiltersDefaultValues } from "../../utils/static";

// export const useMonthlyUses = () => {
//   const location = useLocation();
//   const dispatch = useDispatch();
//   const [searchParams, setSearchParams] = useSearchParams(location.search);
//   const page = searchParams.get("page");
//   const [currentPage, setCurrentPage] = useState(page || 1);
//   const { user, loading: authLoading } = useSelector((state) => state.auth);
//   const { premiumUser, loading } = useSelector((state) => state.premiumUsers);
//   const [filter, setFilter] = useState({ sort: FiltersDefaultValues.None });

//   const sort   = searchParams.get("sort");
//   const status = getLastHeading(location.search);

//   useEffect(() => {
//     if (authLoading) return;

//     const parsedPage = parseInt(page, 10);
//     let resetPage = null;

//     if (!isNaN(parsedPage)) {
//       setCurrentPage(parsedPage);
//     } else {
//       resetPage = 1;
//       setCurrentPage(1);
//     }

//     const fetchUsers = async () => {
//       const uid = user?.user?.id;
//       if (!uid) return;

//       const filteredData = { uid };
//       if (sort) filteredData.sort = sort;

//       try {
//         await dispatch(readPremiumUsers({ data: filteredData }));
//       } catch (err) {
//         console.error("Error fetching premium users:", err);
//       }
//     };

//     fetchUsers();
//   }, [location.search, location.key, user, authLoading, sort]);

//   useEffect(() => {
//     const handlePopState = () => setCurrentPage(getPageFromURL());
//     window.addEventListener("popstate", handlePopState);
//     return () => window.removeEventListener("popstate", handlePopState);
//   }, []);

//   const lastHeadingValue =
//     status === "Cleared"
//       ? "clearDate"
//       : status === "Cancelled"
//       ? "cancelledDate"
//       : "clearanceDate";

//   const headings = [
//     { label: "User details", value: "name"           },
//     { label: "Installed",    value: "installDate"    },
//     { label: "Subscribed",   value: "subscribedDate" },
//     { label: status,         value: lastHeadingValue },
//     { label: "Plan Type",    value: "planType"       },
//     { label: "Status",       value: "status"         },
//   ];

//   const { mobilePageTitle, pageTitle } = getPageTitles(location);

//   // All users — no filter, show both monthly and yearly in table
//   const tableRows    = premiumUser?.data ?? [];
//   const monthlyRows  = tableRows.filter((u) => u?.Subscriptions?.[0]?.planType === "monthly");
//   const yearlyRows   = tableRows.filter((u) => u?.Subscriptions?.[0]?.planType === "yearly");

//   const dummyData = [
//     { title: "Total Users",   points: tableRows.length   },
//     { title: "Monthly Users", points: monthlyRows.length },
//     { title: "Yearly Users",  points: yearlyRows.length  },
//     { title: "Revenue",       points: premiumUser?.metrics?.totalrevenue || 0 },
//   ];

//   const totalCount   = tableRows.length;
//   const itemsPerPage = 10;
//   const totalItems   = totalCount;

//   const handlePageChange = (page) => {
//     setCurrentPage(page);
//     const params = new URLSearchParams(window.location.search);
//     params.set("page", page.toString());
//     setSearchParams(params);
//   };

//   const hanldeSortChange = (value) => {
//     const params = new URLSearchParams(window.location.search);
//     if (value === "None") {
//       params.delete("sort");
//     } else {
//       params.set("sort", value);
//     }
//     params.set("page", "1");
//     setSearchParams(params);
//     setCurrentPage(1);
//     setFilter((prev) => ({ ...prev, sort: value }));
//   };

//   return {
//     dummyData,
//     tableRows,
//     totalItems,
//     totalCount,
//     loading,
//     itemsPerPage,
//     handlePageChange,
//     currentPage,
//     headings,
//     pageTitle,
//     mobilePageTitle,
//     filter,
//     sort,
//     hanldeSortChange,
//   };
// };












import { useState, useEffect } from "react";
import { getPageFromURL } from "../../utils/utility";
import { useDispatch, useSelector } from "react-redux";
import { readPremiumUsers, readReferralCounts } from "../../api/slices/premiumUser/premium-user";
import { useLocation, useSearchParams } from "react-router-dom";
import { getLastHeading, getPageTitles } from "../../utils/function";
import { FiltersDefaultValues } from "../../utils/static";

export const useMonthlyUses = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const [searchParams, setSearchParams] = useSearchParams(location.search);
  const page = searchParams.get("page");
  const [currentPage, setCurrentPage] = useState(page || 1);
  const { user, loading: authLoading } = useSelector((state) => state.auth);
  const { premiumUser, referralCounts, loading } = useSelector(
    (state) => state.premiumUsers
  );
  const [filter, setFilter] = useState({ sort: FiltersDefaultValues.None });

  const sort        = searchParams.get("sort");
  const queryStatus = searchParams.get("status");
  const status      = getLastHeading(location.search);

  // Map URL status → API status value
  const mappedStatus =
    queryStatus === "subscribed" ? "active"
    : queryStatus === "cancelled" ? "canceled"
    : queryStatus === "None" || !queryStatus ? undefined
    : queryStatus;

  // ── API 2: POST /referrals/users/details ─────────────────────────────────
  useEffect(() => {
    if (authLoading) return;

    const parsedPage = parseInt(page, 10);
    let resetPage = null;

    if (!isNaN(parsedPage)) {
      setCurrentPage(parsedPage);
    } else {
      resetPage = 1;
      setCurrentPage(1);
    }

    const fetchUsers = async () => {
      const uid = user?.user?.id;
      if (!uid) return;

      const requestBody = {
        uid,
        type: "monthly",
        page: Number(parsedPage) || resetPage || currentPage,
        size: 10,
      };

      if (mappedStatus) requestBody.status = mappedStatus;
      if (sort)         requestBody.sort   = sort;

      try {
        await dispatch(readPremiumUsers({ data: requestBody }));
      } catch (err) {
        console.error("Error fetching monthly premium users:", err);
      }
    };

    fetchUsers();
  }, [location.search, location.key, user, authLoading, sort, queryStatus]);

  // ── API 1: POST /referrals/details/get ───────────────────────────────────
  useEffect(() => {
    if (authLoading) return;
    const uid = user?.user?.id;
    if (!uid) return;
    dispatch(readReferralCounts({ data: { uid } }));
  }, [user, authLoading]);

  useEffect(() => {
    const handlePopState = () => setCurrentPage(getPageFromURL());
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const lastHeadingValue =
    status === "Cleared" ? "clearDate"
    : status === "Cancelled" ? "cancelledDate"
    : "clearanceDate";

  const headings = [
    { label: "User details", value: "name"           },
    { label: "Installed",    value: "installDate"    },
    { label: "Subscribed",   value: "subscribedDate" },
    { label: status,         value: lastHeadingValue },
    { label: "Plan Type",    value: "planType"       },
    { label: "Status",       value: "status"         },
  ];

  const { mobilePageTitle, pageTitle } = getPageTitles(location);

  // Pick the correct referralCounts category based on URL status:
  // "trial"      → monthlyTrialUsers
  // "subscribed" → monthlySubscribedUsers
  // "cancelled"  → monthlyCanceledUsers
  // default      → monthlyTotal
  const counts =
    queryStatus === "trial"       ? referralCounts?.monthlyTrialUsers
    : queryStatus === "subscribed" ? referralCounts?.monthlySubscribedUsers
    : queryStatus === "cancelled"  ? referralCounts?.monthlyCanceledUsers
    : referralCounts?.monthlyTotal ?? {};

  const dummyData = [
    { title: "Total Users", points: counts?.total     ?? 0 },
    { title: "This Month",  points: counts?.thisMonth ?? 0 },
    { title: "This Week",   points: counts?.thisWeek  ?? 0 },
    { title: "Revenue",     points: counts?.revenue   ?? 0 },
  ];

  const tableRows    = premiumUser?.data            ?? [];
  const totalCount   = premiumUser?.pagination?.total ?? 0;
  const itemsPerPage = 10;
  const totalItems   = totalCount;

  const handlePageChange = (page) => {
    setCurrentPage(page);
    const params = new URLSearchParams(window.location.search);
    params.set("page", page.toString());
    setSearchParams(params);
  };

  const hanldeSortChange = (value) => {
    const params = new URLSearchParams(window.location.search);
    if (value === "None") {
      params.delete("sort");
    } else {
      params.set("sort", value);
    }
    params.set("page", "1");
    setSearchParams(params);
    setCurrentPage(1);
    setFilter((prev) => ({ ...prev, sort: value }));
  };

  return {
    dummyData,
    tableRows,
    totalItems,
    totalCount,
    loading,
    itemsPerPage,
    handlePageChange,
    currentPage,
    headings,
    pageTitle,
    mobilePageTitle,
    filter,
    sort,
    hanldeSortChange,
  };
};