// // // import { formatDate } from "../../../utils/function";
// // // import { getRedeemStatusStyles } from "../../../utils/utility";

// // // export const RedeemHistoryTableRows = ({ data, onPaymentDetails }) => {
// // //   return (
// // //     <div className={`overflow-y-visible flex flex-col gap-y-[10px]`}>
// // //       {data?.map((item, index) => {
// // //         const { bg, text } = getRedeemStatusStyles(item?.status);

// // //         return (
// // //           <div
// // //             key={index}
// // //             onClick={() =>
// // //               onPaymentDetails(
// // //                 item?.createdAt,
// // //                 item?.points,
// // //                 item?.approvedDate,
// // //                 item?.paymentMethod,
// // //                 item?.paymentDate,
// // //                 item?.status
// // //               )
// // //             }
// // //             className="bg-white cursor-pointer hover:bg-tableHoverColor rounded-[5px] py-[26px] px-10 grid grid-cols-[minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_170px)] items-center"
// // //           >
// // //             <span className="text-base font-medium">
// // //               {formatDate(item?.createdAt)}
// // //             </span>

// // //             <span className="text-base font-medium flex items-center justify-center">
// // //               {item?.points}
// // //             </span>

// // //             <div className="flex items-center justify-center">
// // //               <div
// // //                 className={`px-[7.2px] py-[5px] min-w-[77px] max-w-[77px] rounded-[3px] text-center ${bg} ${text}`}
// // //               >
// // //                 <span className={`text-xs font-medium ${bg} ${text}`}>
// // //                   {item?.status}
// // //                 </span>
// // //               </div>
// // //             </div>
// // //           </div>
// // //         );
// // //       })}
// // //     </div>
// // //   );
// // // };




// // import { formatDate } from "../../../utils/function";
// // import { getRedeemStatusStyles } from "../../../utils/utility";

// // export const RedeemHistoryTableRows = ({ data, onPaymentDetails, onChat }) => {
// //   return (
// //     <div className={`overflow-y-visible flex flex-col gap-y-[10px]`}>
// //       {data?.map((item, index) => {
// //         const { bg, text } = getRedeemStatusStyles(item?.status);

// //         return (
// //           <div
// //             key={index}
// //             className="bg-white rounded-[5px] py-[26px] px-10 grid grid-cols-[minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_170px)] items-center"
// //           >
// //             <span 
// //               className="text-base font-medium cursor-pointer hover:text-[#237D93]"
// //               onClick={() =>
// //                 onPaymentDetails(
// //                   item?.createdAt,
// //                   item?.points,
// //                   item?.approvedDate,
// //                   item?.paymentMethod,
// //                   item?.paymentDate,
// //                   item?.status
// //                 )
// //               }
// //             >
// //               {formatDate(item?.createdAt)}
// //             </span>

// //             <span 
// //               className="text-base font-medium flex items-center justify-center cursor-pointer hover:text-[#237D93]"
// //               onClick={() =>
// //                 onPaymentDetails(
// //                   item?.createdAt,
// //                   item?.points,
// //                   item?.approvedDate,
// //                   item?.paymentMethod,
// //                   item?.paymentDate,
// //                   item?.status
// //                 )
// //               }
// //             >
// //               {item?.points}
// //             </span>

// //             <div className="flex items-center justify-center">
// //               <button
// //                 onClick={(e) => {
// //                   e.stopPropagation();
// //                   onChat?.(item);
// //                 }}
// //                 className="px-4 py-2 bg-[#237D93] text-white rounded-md text-sm font-medium hover:bg-[#1a5f6f] transition-colors"
// //               >
// //                 Chat
// //               </button>
// //             </div>

// //             <div 
// //               className="flex items-center justify-center cursor-pointer"
// //               onClick={() =>
// //                 onPaymentDetails(
// //                   item?.createdAt,
// //                   item?.points,
// //                   item?.approvedDate,
// //                   item?.paymentMethod,
// //                   item?.paymentDate,
// //                   item?.status
// //                 )
// //               }
// //             >
// //               <div
// //                 className={`px-[7.2px] py-[5px] min-w-[77px] max-w-[77px] rounded-[3px] text-center ${bg} ${text}`}
// //               >
// //                 <span className={`text-xs font-medium ${bg} ${text}`}>
// //                   {item?.status}
// //                 </span>
// //               </div>
// //             </div>
// //           </div>
// //         );
// //       })}
// //     </div>
// //   );
// // };




// import { formatDate } from "../../../utils/function";
// import { getRedeemStatusStyles } from "../../../utils/utility";

// export const RedeemHistoryTableRows = ({ data, onPaymentDetails, onChat }) => {
//   return (
//     <div className={`overflow-y-visible flex flex-col gap-y-[10px]`}>
//       {data?.map((item, index) => {
//         const { bg, text } = getRedeemStatusStyles(item?.status);

//         return (
//           <div
//             key={index}
//             className="bg-white rounded-[5px] py-[26px] px-10 grid grid-cols-[minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_170px)] items-center"
//           >
//             <span 
//               className="text-base font-medium cursor-pointer hover:text-[#237D93]"
//               onClick={() =>
//                 onPaymentDetails(
//                   item?.createdAt,
//                   item?.points,
//                   item?.approvedDate,
//                   item?.paymentMethod,
//                   item?.paymentDate,
//                   item?.status
//                 )
//               }
//             >
//               {formatDate(item?.createdAt)}
//             </span>

//             <span 
//               className="text-base font-medium flex items-center justify-center cursor-pointer hover:text-[#237D93]"
//               onClick={() =>
//                 onPaymentDetails(
//                   item?.createdAt,
//                   item?.points,
//                   item?.approvedDate,
//                   item?.paymentMethod,
//                   item?.paymentDate,
//                   item?.status
//                 )
//               }
//             >
//               {item?.points}
//             </span>

//             <div className="flex items-center justify-center">
//               <button
//                 onClick={(e) => {
//                   e.stopPropagation();
//                   onChat?.(item);
//                 }}
//                 className="px-4 py-2 bg-[#BABABA] hover:bg-[#009F44] text-white rounded-md text-sm font-medium hover:bg-[#1a5f6f] transition-colors"
//               >
//                 Chat
//               </button>
//             </div>

//             <div 
//               className="flex items-center justify-center cursor-pointer"
//               onClick={() =>
//                 onPaymentDetails(
//                   item?.createdAt,
//                   item?.points,
//                   item?.approvedDate,
//                   item?.paymentMethod,
//                   item?.paymentDate,
//                   item?.status
//                 )
//               }
//             >
//               <div
//                 className={`px-[7.2px] py-[5px] min-w-[77px] max-w-[77px] rounded-[3px] text-center ${bg} ${text}`}
//               >
//                 <span className={`text-xs font-medium ${bg} ${text}`}>
//                   {item?.status}
//                 </span>
//               </div>
//             </div>
//           </div>
//         );
//       })}
//     </div>
//   );
// };




import { formatDate } from "../../../utils/function";
import { getRedeemStatusStyles } from "../../../utils/utility";
import { Link } from "react-router-dom";

export const RedeemHistoryTableRows = ({ data, onPaymentDetails, onChat }) => {
  return (
    <div className={`overflow-y-visible flex flex-col gap-y-[10px]`}>
      {data?.map((item, index) => {
        const { bg, text } = getRedeemStatusStyles(item?.status);

        return (
          <div
            key={index}
            className="bg-white rounded-[5px] py-[26px] px-10 grid grid-cols-[minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_3fr)_minmax(170px,_170px)] items-center"
          >
            <span 
              className="text-base font-medium cursor-pointer hover:text-[#237D93]"
              onClick={() =>
                onPaymentDetails(
                  item?.createdAt,
                  item?.points,
                  item?.approvedDate,
                  item?.paymentMethod,
                  item?.paymentDate,
                  item?.status
                )
              }
            >
              {formatDate(item?.createdAt)}
            </span>

            <span 
              className="text-base font-medium flex items-center justify-center cursor-pointer hover:text-[#237D93]"
              onClick={() =>
                onPaymentDetails(
                  item?.createdAt,
                  item?.points,
                  item?.approvedDate,
                  item?.paymentMethod,
                  item?.paymentDate,
                  item?.status
                )
              }
            >
              {item?.points}
            </span>

            <div className="flex items-center justify-center">
              <Link
                to="/payment-request-chat"
                state={{ redeemItem: item }}
                onClick={(e) => {
                  e.stopPropagation();
                  onChat?.(item);
                }}
                className="px-4 py-2 bg-[#BABABA] hover:bg-[#009F44] text-white rounded-md text-sm font-medium transition-colors inline-block"
              >
                Chat
              </Link>
            </div>

            <div 
              className="flex items-center justify-center cursor-pointer"
              onClick={() =>
                onPaymentDetails(
                  item?.createdAt,
                  item?.points,
                  item?.approvedDate,
                  item?.paymentMethod,
                  item?.paymentDate,
                  item?.status
                )
              }
            >
              <div
                className={`px-[7.2px] py-[5px] min-w-[77px] max-w-[77px] rounded-[3px] text-center ${bg} ${text}`}
              >
                <span className={`text-xs font-medium ${bg} ${text}`}>
                  {item?.status}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};