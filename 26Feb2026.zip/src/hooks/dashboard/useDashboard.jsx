// // // import { useDispatch, useSelector } from "react-redux";
// // // import { ModalType } from "../../types/ui";
// // // import { updateModalType } from "../../api/slices/globalSlice/global";
// // // import { useEffect, useState } from "react";
// // // import {
// // //   readDashboardLinks,
// // //   readDashboardResults,
// // // } from "../../api/slices/dashboard/dashboardSlice";
// // // import { useLocation } from "react-router-dom";

// // // export const useDashboard = () => {
// // //   const dispatch = useDispatch();
// // //   const location = useLocation();
// // //   const [links, setLinks] = useState(null);
// // //   const [results, setResults] = useState(null);
// // //   const { loading } = useSelector((state) => state.dashboard);
// // //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// // //   const queryParams = new URLSearchParams(location.search);
// // //   const status = queryParams.get("status");

// // //   const handleShare = () => {
// // //     dispatch(updateModalType({ type: ModalType.SHARE_MODAL }));
// // //   };

// // //   const handleRefLinkModal = (deviceType) => {
// // //     dispatch(
// // //       updateModalType({
// // //         type: ModalType.REFERRAL_LINK_MODAL,
// // //         data: {
// // //           links,
// // //           linkLoading: loading?.links,
// // //           deviceType,
// // //           onShare: handleShare,
// // //         },
// // //       })
// // //     );
// // //   };

// // //   const handleQRCodeModal = (deviceType) => {
// // //     dispatch(
// // //       updateModalType({
// // //         type: ModalType.REFERRAL_QR_CODE_MODAL,
// // //         data: {
// // //           onShare: handleShare,
// // //           links,
// // //           deviceType,
// // //         },
// // //       })
// // //     );
// // //   };

// // //   const handleRefDiscountCodeModal = (deviceType) => {
// // //     dispatch(
// // //       updateModalType({
// // //         type: ModalType.REFERRAL_DISCOUNT_CODE_MODAL,
// // //         data: {
// // //           onShare: handleShare,
// // //           links,
// // //           deviceType,
// // //         },
// // //       })
// // //     );
// // //   };

// // //   useEffect(() => {
// // //     if (authLoading) return;

// // //     const fetchDashboardResults = async () => {
// // //       const uid = user?.user?.id;
// // //       if (!uid) return;

// // //       try {
// // //         const response = await dispatch(
// // //           readDashboardResults({ data: { uid: uid } })
// // //         );
// // //         if (response?.payload) {
// // //           setResults(response?.payload?.counts);
// // //         }
// // //       } catch (err) {
// // //         console.error("Error fetching dashboard results:", err);
// // //       }
// // //     };

// // //     if (status === "results") {
// // //       fetchDashboardResults();
// // //     }
// // //   }, [dispatch, user, authLoading]);

// // //   useEffect(() => {
// // //     if (status !== "ref-guide") return;

// // //     const fetchDashboardLinks = async () => {
// // //       try {
// // //         const response = await dispatch(readDashboardLinks({}));

// // //         if (response?.payload?.data) {
// // //           setLinks(response?.payload?.data);
// // //         }
// // //       } catch (err) {
// // //         console.error("Error fetching dashboard links:", err);
// // //       }
// // //     };

// // //     if (status === "ref-guide") {
// // //       fetchDashboardLinks();
// // //     }
// // //   }, [dispatch, status]);

// // //   return {
// // //     handleRefLinkModal,
// // //     handleQRCodeModal,
// // //     handleRefDiscountCodeModal,
// // //     results,
// // //     links,
// // //     loading,
// // //   };
// // // };





// // import { useDispatch, useSelector } from "react-redux";
// // import { ModalType } from "../../types/ui";
// // import { updateModalType } from "../../api/slices/globalSlice/global";
// // import { useEffect, useState } from "react";
// // import {
// //   readDashboardLinks,
// //   readDashboardResults,
// // } from "../../api/slices/dashboard/dashboardSlice";
// // import { readPremiumUsers } from "../../api/slices/premiumUser/premium-user";
// // import { useLocation } from "react-router-dom";

// // export const useDashboard = () => {
// //   const dispatch = useDispatch();
// //   const location = useLocation();
// //   const [links, setLinks] = useState(null);
// //   const [results, setResults] = useState(null);
// //   const { loading } = useSelector((state) => state.dashboard);
// //   const { user, loading: authLoading } = useSelector((state) => state.auth);

// //   const queryParams = new URLSearchParams(location.search);
// //   const status = queryParams.get("status");

// //   const handleShare = () => {
// //     dispatch(updateModalType({ type: ModalType.SHARE_MODAL }));
// //   };

// //   const handleRefLinkModal = (deviceType) => {
// //     dispatch(
// //       updateModalType({
// //         type: ModalType.REFERRAL_LINK_MODAL,
// //         data: {
// //           links,
// //           linkLoading: loading?.links,
// //           deviceType,
// //           onShare: handleShare,
// //         },
// //       })
// //     );
// //   };

// //   const handleQRCodeModal = (deviceType) => {
// //     dispatch(
// //       updateModalType({
// //         type: ModalType.REFERRAL_QR_CODE_MODAL,
// //         data: {
// //           onShare: handleShare,
// //           links,
// //           deviceType,
// //         },
// //       })
// //     );
// //   };

// //   const handleRefDiscountCodeModal = (deviceType) => {
// //     dispatch(
// //       updateModalType({
// //         type: ModalType.REFERRAL_DISCOUNT_CODE_MODAL,
// //         data: {
// //           onShare: handleShare,
// //           links,
// //           deviceType,
// //         },
// //       })
// //     );
// //   };

// //   useEffect(() => {
// //     if (authLoading) return;

// //     const fetchDashboardResults = async () => {
// //       const uid = user?.id
// //       if (!uid) return;

// //       try {
// //         // ✅ Step 1: Fetch dashboard counts (points, freeUsers etc.)
// //         const response = await dispatch(
// //           readDashboardResults({ data: { uid: uid } })
// //         );

// //         // ✅ Step 2: Fetch REAL monthly count (same API as table)
// //         const monthlyRes = await dispatch(
// //           readPremiumUsers({
// //             data: { uid, type: "monthly", page: 1, size: 10 },
// //           })
// //         );

// //         // ✅ Step 3: Fetch REAL yearly count (same API as table)
// //         const yearlyRes = await dispatch(
// //           readPremiumUsers({
// //             data: { uid, type: "yearly", page: 1, size: 10 },
// //           })
// //         );

// //         if (response?.payload) {
// //           setResults({
// //             // ✅ Keep original data (points, freeUsers etc.)
// //             ...response?.payload?.counts,

// //             // ✅ Override with REAL counts from pagination (matches table)
// //             monthlyPremium: monthlyRes?.payload?.pagination?.total || 0,
// //             yearlyPremium: yearlyRes?.payload?.pagination?.total || 0,
// //           });
// //         }
// //       } catch (err) {
// //         console.error("Error fetching dashboard results:", err);
// //       }
// //     };

// //     if (status === "results") {
// //       fetchDashboardResults();
// //     }
// //   }, [dispatch, user, authLoading, status]);

// //   useEffect(() => {
// //     if (status !== "ref-guide") return;

// //     const fetchDashboardLinks = async () => {
// //       try {
// //         const response = await dispatch(readDashboardLinks({}));
// //         if (response?.payload?.data) {
// //           setLinks(response?.payload?.data);
// //         }
// //       } catch (err) {
// //         console.error("Error fetching dashboard links:", err);
// //       }
// //     };

// //     fetchDashboardLinks();
// //   }, [dispatch, status]);

// //   return {
// //     handleRefLinkModal,
// //     handleQRCodeModal,
// //     handleRefDiscountCodeModal,
// //     results,
// //     links,
// //     loading,
// //   };
// // };







// import { useDispatch, useSelector } from "react-redux";
// import { ModalType } from "../../types/ui";
// import { updateModalType } from "../../api/slices/globalSlice/global";
// import { useEffect, useState } from "react";
// import {
//   readDashboardLinks,
//   readDashboardResults,
// } from "../../api/slices/dashboard/dashboardSlice";
// import { useLocation } from "react-router-dom";

// export const useDashboard = () => {
//   const dispatch = useDispatch();
//   const location = useLocation();
//   const [links, setLinks] = useState(null);
//   const [results, setResults] = useState(null);
//   const { loading } = useSelector((state) => state.dashboard);
//   const { user, loading: authLoading } = useSelector((state) => state.auth);

//   const queryParams = new URLSearchParams(location.search);
//   const status = queryParams.get("status");

//   const handleShare = () => {
//     dispatch(updateModalType({ type: ModalType.SHARE_MODAL }));
//   };

//   const handleRefLinkModal = (deviceType) => {
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_LINK_MODAL,
//         data: {
//           links,
//           linkLoading: loading?.links,
//           deviceType,
//           onShare: handleShare,
//         },
//       })
//     );
//   };

//   const handleQRCodeModal = (deviceType) => {
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_QR_CODE_MODAL,
//         data: {
//           onShare: handleShare,
//           links,
//           deviceType,
//         },
//       })
//     );
//   };

//   const handleRefDiscountCodeModal = (deviceType) => {
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_DISCOUNT_CODE_MODAL,
//         data: {
//           onShare: handleShare,
//           links,
//           deviceType,
//         },
//       })
//     );
//   };

//   useEffect(() => {
//     if (authLoading) return;

//     const fetchDashboardResults = async () => {
//       const uid = user?.id;
//       if (!uid) return;

//       try {
//         const response = await dispatch(
//           readDashboardResults({ data: { uid } })
//         );

//         console.log("Full payload:", response?.payload);
//         console.log("Counts:", response?.payload?.counts);

//         if (response?.payload?.counts) {
//           setResults({
//             // spread counts: { points, freeUsers, monthlyPremium, yearlyPremium }
//             ...response?.payload?.counts,
//           });
//         }
//       } catch (err) {
//         console.error("Error fetching dashboard results:", err);
//       }
//     };

//     if (status === "results") {
//       fetchDashboardResults();
//     }
//   }, [dispatch, user, authLoading, status]);

//   useEffect(() => {
//     if (status !== "ref-guide") return;

//     const fetchDashboardLinks = async () => {
//       try {
//         const response = await dispatch(readDashboardLinks({}));
//         if (response?.payload?.data) {
//           setLinks(response?.payload?.data);
//         }
//       } catch (err) {
//         console.error("Error fetching dashboard links:", err);
//       }
//     };

//     fetchDashboardLinks();
//   }, [dispatch, status]);

//   return {
//     handleRefLinkModal,
//     handleQRCodeModal,
//     handleRefDiscountCodeModal,
//     results,
//     links,
//     loading,
//   };
// };











import { useDispatch, useSelector } from "react-redux";
import { ModalType } from "../../types/ui";
import { updateModalType } from "../../api/slices/globalSlice/global";
import { useEffect, useState } from "react";
import {
  readDashboardLinks,
  readDashboardResults,
} from "../../api/slices/dashboard/dashboardSlice";
import { useLocation } from "react-router-dom";

export const useDashboard = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const [links, setLinks] = useState(null);
  const [results, setResults] = useState(null);
  const { loading } = useSelector((state) => state.dashboard);
  const { user, loading: authLoading } = useSelector((state) => state.auth);

  const queryParams = new URLSearchParams(location.search);
  const status = queryParams.get("status");

  const handleShare = () => {
    dispatch(updateModalType({ type: ModalType.SHARE_MODAL }));
  };

  // links is now array: [{ id, link, deviceType, discountCode }]
  // Filter by deviceType to get ios/android specific link
  const getLink = (deviceType) =>
    links?.find((l) => l.deviceType === deviceType) || null;

  const handleRefLinkModal = (deviceType) => {
    const deviceLink = getLink(deviceType);
    dispatch(
      updateModalType({
        type: ModalType.REFERRAL_LINK_MODAL,
        data: {
          link:        deviceLink?.link,
          deviceType,
          linkLoading: loading?.links,
          onShare:     handleShare,
        },
      })
    );
  };

  const handleQRCodeModal = (deviceType) => {
    const deviceLink = getLink(deviceType);
    dispatch(
      updateModalType({
        type: ModalType.REFERRAL_QR_CODE_MODAL,
        data: {
          link:     deviceLink?.link,
          deviceType,
          onShare:  handleShare,
        },
      })
    );
  };

  const handleRefDiscountCodeModal = (deviceType) => {
    const deviceLink = getLink(deviceType);
    dispatch(
      updateModalType({
        type: ModalType.REFERRAL_DISCOUNT_CODE_MODAL,
        data: {
          discountCode: deviceLink?.discountCode,
          link:         deviceLink?.link,
          deviceType,
          onShare:      handleShare,
        },
      })
    );
  };

  // ── Fetch dashboard counts ────────────────────────────────────────────────
  useEffect(() => {
    if (authLoading) return;

    const fetchDashboardResults = async () => {
      const uid = user?.id;
      if (!uid) return;

      try {
        const response = await dispatch(
          readDashboardResults({ data: { uid } })
        );

        if (response?.payload?.counts) {
          setResults({ ...response?.payload?.counts });
        }
      } catch (err) {
        console.error("Error fetching dashboard results:", err);
      }
    };

    if (status === "results") {
      fetchDashboardResults();
    }
  }, [dispatch, user, authLoading, status]);

  // ── Fetch app links ───────────────────────────────────────────────────────
  useEffect(() => {
    if (status !== "ref-guide") return;

    const fetchDashboardLinks = async () => {
      try {
        const response = await dispatch(readDashboardLinks({}));
        // API response: { success, message, data: [{ id, link, deviceType, discountCode }] }
        if (response?.payload?.data) {
          setLinks(response?.payload?.data); // store array directly
        }
      } catch (err) {
        console.error("Error fetching dashboard links:", err);
      }
    };

    fetchDashboardLinks();
  }, [dispatch, status]);

  return {
    handleRefLinkModal,
    handleQRCodeModal,
    handleRefDiscountCodeModal,
    results,
    links,
    loading,
  };
};













// import { useDispatch, useSelector } from "react-redux";
// import { ModalType } from "../../types/ui";
// import { updateModalType } from "../../api/slices/globalSlice/global";
// import { useEffect, useState } from "react";
// import {
//   readDashboardLinks,
//   readDashboardResults,
// } from "../../api/slices/dashboard/dashboardSlice";
// import { useLocation } from "react-router-dom";

// const EMPTY_RESULTS = {
//   points: { active: 0, redeemed: 0 },
//   freeUsers: 0,
//   monthlyPremium: 0,
//   yearlyPremium: 0,
// };

// export const useDashboard = () => {
//   const dispatch = useDispatch();
//   const location = useLocation();
//   const [links, setLinks] = useState(null);
//   const [results, setResults] = useState(null);
//   const [resultsLoading, setResultsLoading] = useState(false);

//   const { loading } = useSelector((state) => state.dashboard);
//   const { user, loading: authLoading } = useSelector((state) => state.auth);

//   const queryParams = new URLSearchParams(location.search);
//   const status = queryParams.get("status");

//   const handleShare = () => {
//     dispatch(updateModalType({ type: ModalType.SHARE_MODAL }));
//   };

//   const getLink = (deviceType) =>
//     links?.find((l) => l.deviceType === deviceType) || null;

//   const handleRefLinkModal = (deviceType) => {
//     const deviceLink = getLink(deviceType);
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_LINK_MODAL,
//         data: {
//           link: deviceLink?.link,
//           deviceType,
//           linkLoading: loading?.links,
//           onShare: handleShare,
//         },
//       })
//     );
//   };

//   const handleQRCodeModal = (deviceType) => {
//     const deviceLink = getLink(deviceType);
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_QR_CODE_MODAL,
//         data: {
//           link: deviceLink?.link,
//           deviceType,
//           onShare: handleShare,
//         },
//       })
//     );
//   };

//   const handleRefDiscountCodeModal = (deviceType) => {
//     const deviceLink = getLink(deviceType);
//     dispatch(
//       updateModalType({
//         type: ModalType.REFERRAL_DISCOUNT_CODE_MODAL,
//         data: {
//           discountCode: deviceLink?.discountCode,
//           link: deviceLink?.link,
//           deviceType,
//           onShare: handleShare,
//         },
//       })
//     );
//   };

//   // ── Fetch dashboard counts ────────────────────────────────────────────────
//   useEffect(() => {
//     if (authLoading) return;
//     if (status !== "results") return;

//     const fetchDashboardResults = async () => {
//       const uid = user?.id;

//       if (!uid) {
//         // Not logged in — show zeros immediately, no fetch needed
//         setResults(EMPTY_RESULTS);
//         return;
//       }

//       setResultsLoading(true);

//       try {
//         const response = await dispatch(
//           readDashboardResults({ data: { uid } })
//           // Note: no setError passed — guarded in slice now
//         );

//         const counts = response?.payload?.counts;

//         // If API returned counts use them, otherwise show zeros (new account)
//         setResults(counts ? { ...counts } : EMPTY_RESULTS);
//       } catch (err) {
//         console.error("Dashboard results fetch failed:", err);
//         setResults(EMPTY_RESULTS);
//       } finally {
//         setResultsLoading(false);
//       }
//     };

//     fetchDashboardResults();
//   }, [dispatch, user?.id, authLoading, status]);

//   // ── Fetch app links ───────────────────────────────────────────────────────
//   useEffect(() => {
//     if (status !== "ref-guide") return;

//     const fetchDashboardLinks = async () => {
//       try {
//         const response = await dispatch(readDashboardLinks({}));
//         setLinks(response?.payload?.data ?? []);
//       } catch (err) {
//         console.error("Dashboard links fetch failed:", err);
//         setLinks([]);
//       }
//     };

//     fetchDashboardLinks();
//   }, [dispatch, status]);

//   return {
//     handleRefLinkModal,
//     handleQRCodeModal,
//     handleRefDiscountCodeModal,
//     results,
//     resultsLoading,
//     links,
//     loading,
//   };
// };